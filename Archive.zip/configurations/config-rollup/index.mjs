import { defineConfig } from 'rollup';
import path from 'path';
import fs from 'fs';
import { get, isNil } from 'lodash-es';
import pluginTs from '@rollup/plugin-typescript';
import { dts } from 'rollup-plugin-dts';
import nodeExternals from 'rollup-plugin-node-externals';
import assetResolver from './plugin-asset-resolver.mjs';

const packageJsonPath = path.join(process.cwd(), 'package.json');

const packageJson = JSON.parse(fs.readFileSync(packageJsonPath));

let input = path.join(process.cwd(), 'src/index.ts');

if (!isNil(packageJson.exports)) {
    input = Object.values(packageJson.exports).reduce((acc, chunk) => {
        const importVal = chunk.import;
    
        if (!isNil(importVal)) {
            let source = importVal
                .replace("/dist/", "/src/")
                .replace(".mjs", ".ts");

            const huh = path.join(process.cwd(), source);

            if (!fs.existsSync(huh)) {
                source = source.replace(".ts", ".tsx");
            }

            if (!fs.existsSync(path.join(process.cwd(), source))) {
                throw `File, ${importVal}, from package.json exports was not found with extensions ts or tsx`;
            }

            const entry = source.replace(/\.\/src\/|\.tsx|\.ts/g, "")
            
            acc[entry] = source;
        }
    
        return acc;
    }, {});
}

export default function buildConfig() {
    return defineConfig([
        {
            input,
            output: [
                {
                    dir: 'dist',
                    format: 'es',
                    entryFileNames: '[name].mjs',
                    preserveModules: true,
                },
            ],
            plugins: [
                nodeExternals(),
                assetResolver({ include: ['.png$'] }),
                pluginTs(),
            ],
        },
        {
            input,
            output: [
                {
                    dir: 'dist',
                    format: 'es',
                },
            ],
            plugins: [
                nodeExternals(),
                dts(),
            ],
        },
    ]);
}
