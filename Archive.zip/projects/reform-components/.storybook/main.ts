/** @type { import('@storybook/react-webpack5').StorybookConfig } */
const config = {
  "stories": [
    '../src/**/_stories/*index.stories.ts'
  ],
  "addons": [
    "@storybook/addon-webpack5-compiler-swc",
    "@storybook/addon-docs",
    ({
          name: "@storybook/addon-styling-webpack",

          options: {
              rules: [
                  {
                      test: /\.(css|scss)$/,
                      sideEffects: true,
                      use: [
                          require.resolve("style-loader"),
                          {
                              loader: require.resolve("css-loader"),
                              options: {},
                          },
                          require.resolve("sass-loader"),
                      ],
                  },
              ],
          }
      }),
  ],
  "framework": {
    "name": "@storybook/react-webpack5",
    "options": {}
  }
};
export default config;
