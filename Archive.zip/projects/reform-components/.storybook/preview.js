/** @type { import('@storybook/react-webpack5').Preview } */
import '../src/styles/index.scss';

const preview = {
  parameters: {
    controls: {
      matchers: {
       color: /(background|color)$/i,
       date: /Date$/i,
      },
    },
  },
};

export default preview;