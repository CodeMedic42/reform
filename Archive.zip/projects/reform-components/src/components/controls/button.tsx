import React from 'react';
import classNames from 'classnames';
import Control from './support/control';
import { isNil } from 'lodash-es';

export interface ButtonProps extends React.ComponentPropsWithoutRef<'button'> {
	className?: string,
	children: React.ReactNode;
}

function Button(props: ButtonProps) {
	const {
		className,
		children,
		type,
		...rest
	} = props;

	return (
		<Control<'button'>
			ControlComponent='button'
			className={classNames('re-button', className)}
			type={!isNil(type) ? type : 'button'}
			{...rest}
		>
			{children}
		</Control>
	);
}

export default Button;