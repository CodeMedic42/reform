import Form from '..';

export default {
	title: 'Form',
	component: Form,
};

export { default as form } from './form';
