import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import forEach from 'lodash-es/forEach';
import map from 'lodash-es/map';
import isNaN from 'lodash-es/isNaN';
import isUndefined from 'lodash-es/isUndefined';
import reduce from 'lodash-es/reduce';
import isFunction from 'lodash-es/isFunction';
import split from 'lodash-es/split';
import isNil from 'lodash-es/isNil';
import isArray from 'lodash-es/isArray';
import upperFirst from 'lodash-es/upperFirst';
import reactElementToJSXString from 'react-element-to-jsx-string';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faChevronUp} from '@audacious/icons/solid/faChevronUp';
import {faChevronDown} from '@audacious/icons/solid/faChevronDown';
import './styles.scss';
import SpecimenDish from './specimen-dish';

const TAB_SIZE = '    ';

function formatScope(node, tab = '') {
    let buildStr = '';

    if (node.nodeName === '#text') {
        return `${tab}${node.wholeText}\n`;
    }

    if (!isNil(node.innerHTML) && node.innerHTML.length > 0) {
        const parts = split(node.outerHTML, node.innerHTML);

        buildStr += `${tab}${parts[0]}\n`;

        forEach(node.childNodes, childNode => {
            buildStr += formatScope(childNode, `${tab}${TAB_SIZE}`);
        });

        buildStr += `${tab}${parts[1]}\n`;
    } else {
        buildStr += `${tab}${node.outerHTML}\n`;
    }

    return buildStr;
}

function stringifyState(state) {
    return JSON.stringify(
        state,
        (key, value) => {
            if (isUndefined(value)) {
                return 'Undefined';
            }

            if (isNaN(value)) {
                return 'NaN';
            }

            if (value === Infinity) {
                return 'Infinity';
            }

            if (value === -Infinity) {
                return '-Infinity';
            }

            return value;
        },
        4,
    );
}

class Scope extends React.Component {
    constructor(props) {
        super(props);

        this.specimenRef = React.createRef();
        this.htmlViewRef = React.createRef();
        this.jsxViewRef = React.createRef();
        this.stateViewRef = React.createRef();

        this.jsxButtonRef = React.createRef();
        this.htmlButtonRef = React.createRef();
        this.stateButtonRef = React.createRef();
        this.triangleRef = React.createRef();

        this.handleShowJsx = this.handleShowJsx.bind(this);
        this.handleShowHtml = this.handleShowHtml.bind(this);
        this.handleShowState = this.handleShowState.bind(this);
        this.handleHideAll = this.handleHideAll.bind(this);
        this.handleShowToggle = this.handleShowToggle.bind(this);

        const { jsxViewEnabled, htmlViewEnabled, initialState } = props;

        let view = null;

        if (jsxViewEnabled) {
            view = 'jsx';
        } else if (htmlViewEnabled) {
            view = 'html';
        }

        this.state = {
            view,
            show: true,
            specimenState: !isNil(initialState) ? initialState : {},
        };
    }

    componentDidMount() {
        this.renderCode();

        this.moveTriangle();

        this.observer = new MutationObserver(() => {
            this.renderCode();
        });

        const config = { attributes: true, childList: true, subtree: true };

        this.observer.observe(this.specimenRef.current, config);
    }

    componentDidUpdate() {
        this.renderCode();

        this.moveTriangle();
    }

    componentWillUnmount() {
        if (!isNil(this.observer)) {
            this.observer.disconnect();
        }
    }

    moveTriangle() {
        const { specimenOnly } = this.props;

        const { view } = this.state;

        if (specimenOnly) {
            return;
        }

        let button = null;

        if (view === 'jsx') {
            button = this.jsxButtonRef.current;
        } else if (view === 'html') {
            button = this.htmlButtonRef.current;
        } else if (view === 'state') {
            button = this.stateButtonRef.current;
        }

        if (isNil(button)) {
            return;
        }

        const buttonParent = button.parentElement;

        const buttonRect = button.getBoundingClientRect();
        const buttonParentRect = buttonParent.getBoundingClientRect();

        const parentLeftPadding = parseFloat(
            window
                .getComputedStyle(buttonParent, null)
                .getPropertyValue('padding-left'),
        );

        const left =
            buttonRect.left - buttonParentRect.left - parentLeftPadding;

        const buttonHalfWidth = buttonRect.width / 2;

        const triangleReact = this.triangleRef.current.getBoundingClientRect();

        const triangleHalfWidth = triangleReact.width / 2;

        this.triangleRef.current.style.left = `${left +
            buttonHalfWidth +
            triangleHalfWidth}px`;
    }

    handleShowJsx() {
        this.setState({
            view: 'jsx',
        });
    }

    handleShowHtml() {
        this.setState({
            view: 'html',
        });
    }

    handleShowState() {
        this.setState({
            view: 'state',
        });
    }

    handleHideAll() {
        this.setState({
            view: null,
        });
    }

    handleShowToggle() {
        const { show } = this.state;

        this.setState({
            show: !show,
        });
    }

    renderCode() {
        const { jsxViewEnabled, htmlViewEnabled, specimenOnly } = this.props;

        const { view } = this.state;

        if (specimenOnly) {
            return;
        }

        if (htmlViewEnabled && view === 'html') {
            const htmlText = reduce(
                this.specimenRef.current.childNodes[0].childNodes,
                (acc, childNode) => `${acc}${formatScope(childNode)}`,
                '',
            );

            this.htmlViewRef.current.textContent = htmlText;

            window.Prism.highlightElement(this.htmlViewRef.current);
        }

        if (jsxViewEnabled) {
            if (view === 'jsx') {
                window.Prism.highlightElement(this.jsxViewRef.current);
            } else if (view === 'state') {
                window.Prism.highlightElement(this.stateViewRef.current);
            }
        }
    }

    renderJsx(specimen) {
        const { jsxViewEnabled } = this.props;

        if (!jsxViewEnabled) {
            return null;
        }

        // let { specimen } = this.state;

        const { view } = this.state;

        let content = null;

        const options = {
            showDefaultProps: false,
            maxInlineAttributesLineLength: 200,
            tabStop: 4,
            filterProps: ['ref']
        };

        try {
            // There is a bug in reactElementToJSXString where if it
            // tries to process a date object which is invalid it throws
            // an unhandled error
            if (isArray(specimen)) {
                content = map(specimen, child => {
                    return `${reactElementToJSXString(child, options)}\n`;
                });
            } else {
                content = reactElementToJSXString(specimen, options);
            }
        } catch (error) {
            console.error(error.message);

            content = '';
        }

        return (
            <pre
                className={classnames('scope-view scope-view-jsx', {
                    show: view === 'jsx',
                })}
            >
                <code ref={this.jsxViewRef} className="language-jsx">
                    {content}
                </code>
            </pre>
        );
    }

    renderState() {
        const { jsxViewEnabled, children } = this.props;

        if (!jsxViewEnabled || !isFunction(children)) {
            return null;
        }

        const { view, specimenState } = this.state;

        return (
            <pre
                className={classnames('scope-view scope-view-state', {
                    show: view === 'state',
                })}
            >
                <code ref={this.stateViewRef} className="language-json">
                    {stringifyState(specimenState)}
                </code>
            </pre>
        );
    }

    renderHtml() {
        const { htmlViewEnabled } = this.props;

        if (!htmlViewEnabled) {
            return null;
        }

        const { view } = this.state;

        return (
            <pre
                className={classnames('scope-view scope-view-jsx', {
                    show: view === 'html',
                })}
            >
                <code ref={this.htmlViewRef} className="language-html" />
            </pre>
        );
    }

    renderViewControls() {
        const { view } = this.state;
        const { jsxViewEnabled, htmlViewEnabled, children } = this.props;

        const jsxButton = jsxViewEnabled ? (
            <button
                ref={this.jsxButtonRef}
                type="button"
                className={classnames('scope-view-button', {
                    selected: view === 'jsx',
                })}
                onClick={this.handleShowJsx}
            >
                JSX
            </button>
        ) : null;

        const htmlButton = htmlViewEnabled ? (
            <button
                ref={this.htmlButtonRef}
                type="button"
                className={classnames('scope-view-button', {
                    selected: view === 'html',
                })}
                onClick={this.handleShowHtml}
            >
                HTML
            </button>
        ) : null;

        const stateButton =
            jsxViewEnabled && isFunction(children) ? (
                <button
                    ref={this.stateButtonRef}
                    type="button"
                    className={classnames('scope-view-button', {
                        selected: view === 'state',
                    })}
                    onClick={this.handleShowState}
                >
                    State
                </button>
            ) : null;

        let triangle = null;

        if (!isNil(view)) {
            triangle = <div ref={this.triangleRef} className="triangle" />;
        }

        return (
            <div className="scope-view-controls">
                {jsxButton}
                {htmlButton}
                {stateButton}
                <button
                    type="button"
                    className={classnames('scope-view-button', {
                        selected: isNil(view),
                    })}
                    onClick={this.handleHideAll}
                >
                    None
                </button>
                {triangle}
            </div>
        );
    }

    renderHeader() {
        const {
            title,
        } = this.props;

        const { show } = this.state;

        if (isNil(title) || title.length <= 0) {
            return null;
        }

        return (
            <header>
                <button type="button" onClick={this.handleShowToggle}>
                    <FontAwesomeIcon
                        icon={show ? faChevronDown : faChevronUp}
                    />
                    {upperFirst(title)}
                </button>
            </header>
        );
    }

    render() {
        const {
            id,
            className,
            controls,
            specimenOnly,
            specimenViewStyle,
            children,
            SpecimenContainer,
            dark,
            fillViewport,
        } = this.props;

        const { show, specimenState } = this.state;

        let specimenControls = !isNil(controls) ? (
            <div className="scope-specimen-controls">{controls}</div>
        ) : null;

        let specimen = children;

        if (isFunction(children)) {
            specimen = children(specimenState, newSpecimenState => {
                this.setState({
                    specimenState: {
                        ...this.state.specimenState,
                        ...newSpecimenState,
                    },
                });
            });
        }

        let specimenElement = specimen;

        if (!isNil(SpecimenContainer)) {
            specimenElement = (
                <SpecimenContainer
                    className={classnames({
                        'gutter-vertical': specimenOnly,
                    })}
                >
                    {specimen}
                </SpecimenContainer>
            );
        }

        const specimenView = (
            <div
                ref={this.specimenRef}
                className={classnames('scope-specimen')}
                style={specimenViewStyle}
            >
                {specimenElement}
            </div>
        );

        if (specimenOnly) {
            return specimenView;
        }

        return (
            <div id={id} className={classnames('scope', className, { dark, 'fill-viewport': fillViewport })}>
                {this.renderHeader()}
                <main className={classnames({ show })}>
                    {specimenControls}
                    {specimenView}
                    {this.renderViewControls()}
                    {this.renderHtml()}
                    {this.renderJsx(specimen)}
                    {this.renderState()}
                </main>
            </div>
        );
    }
}

Scope.propTypes = {
    id: PropTypes.string,
    className: PropTypes.string,
    SpecimenContainer: PropTypes.elementType,
    title: PropTypes.string,
    controls: PropTypes.oneOfType([
        PropTypes.node,
        PropTypes.arrayOf(PropTypes.node),
    ]),
    jsxViewEnabled: PropTypes.bool,
    htmlViewEnabled: PropTypes.bool,
    initialState: PropTypes.object,
    specimenViewStyle: PropTypes.object,
    children: PropTypes.oneOfType([
        PropTypes.node,
        PropTypes.arrayOf(PropTypes.node),
        PropTypes.func,
    ]),
    specimenOnly: PropTypes.bool,
    dark: PropTypes.bool,
    fillViewport: PropTypes.bool,
};

Scope.defaultProps = {
    SpecimenContainer: SpecimenDish,
    controls: null,
    jsxViewEnabled: true,
    htmlViewEnabled: true,
    initialState: null,
    specimenOnly: false,
    dark: false,
    fillViewport: false,
};

export default Scope;
