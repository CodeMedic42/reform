import React from 'react';
import propTypes from 'prop-types';

function SpecimenDish(props) {
    const { children } = props;

    return <div className="specimen-dish">{children}</div>;
}

SpecimenDish.propTypes = {
    children: propTypes.any
};

export default SpecimenDish;
