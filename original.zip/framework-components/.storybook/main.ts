const config = {
  stories: [
      '../src/**/*.stories.ts*'
  ],
  addons: [
      "@storybook/addon-webpack5-compiler-swc",
      "@storybook/addon-onboarding",
      "@chromatic-com/storybook",
      "@storybook/addon-links",
      "@storybook/addon-essentials",
      "@storybook/addon-interactions",
      ({
          name: "@storybook/addon-styling-webpack",

          options: {
              rules: [
                  {
                      test: /\.(css|scss)$/,
                      sideEffects: true,
                      use: [
                          require.resolve("style-loader"),
                          {
                              loader: require.resolve("css-loader"),
                              options: {},
                          },
                          require.resolve("sass-loader"),
                      ],
                  },
              ],
          }
      }),
  ],
  typescript: {
    reactDocgen: false,
  },
  framework: {
    name: "@storybook/react-webpack5",
    options: {},
  },
};

export default config;
