import React from 'react';
import classnames from 'classnames';
import '../src/styles/index.scss';

export const parameters = {
    options: {
        showPanel: false,
    },
    controls: { expanded: true },
    viewport: {
        viewports: {
            sm: {
                name: 'Small, Mobile',
                styles: {
                    width: '460px',
                    height: '820px',
                },
            },
            md: {
                name: 'Medium, Tablet',
                styles: {
                    width: '600px',
                    height: '820px',
                },
            },
            lg: {
                name: 'Large, Desktop',
                styles: {
                    width: '992px',
                    height: '820px',
                },
            },
            xl: {
                name: 'Extra Large, Desktop',
                styles: {
                    width: '1200px',
                    height: '820px',
                },
            },
            '2xl': {
                name: '2XL, Desktop',
                styles: {
                    width: '1600px',
                    height: '820px',
                },
            },
        },
    },
};

export const globalTypes = {
    scopeVisibility: {
        name: 'Scope Visibility',
        description: 'Scope Visibility',
        defaultValue: 'Show Scopes',
        toolbar: {
            icon: 'eye',
            items: [
                { value: 'showScopes', title: 'Show Scopes', icon: 'eye' },
                { value: 'hideScopes', title: 'Hide Scopes', icon: 'eyeclose' },
                {
                    value: 'hideScopeViews',
                    title: 'Hide Scope Views',
                    icon: 'subtract',
                },
            ],
        },
    },
};

export const decorators = [
    (Story, context) => {
        const { scopeVisibility } = context.globals;

        return (
            <div
                className={classnames({
                    'hide-scope': scopeVisibility === 'hideScopes',
                    'hide-scope-view': scopeVisibility === 'hideScopeViews',
                })}
            >
                <Story />
            </div>
        );
    },
];
  