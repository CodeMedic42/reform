# Ai Component Library

This is a library of common components for AI.

## Install

To use this library install it using

```bash
npm install @audacious/components
```

## Storybook

This library is supported with Storybook. This interface can be used to browse the various use cases for each component.

DEV: https://storybook.dev-ainqapps.com

PROD: https://storybook.test-ainqapps.com

## Color

There are two groups of colors, pallette colors and scheme colors.

### Pallette Colors

Pallette colors are general colors for styling elements. These colors are available with various components.

The available colors are

- Blue
- Cyan
- Green
- Grey
- Navy
- Orange
- Purple
- Red
- Yellow

### Scheme Colors

Scheme colors are functional colors which have both meaning and interactive properties. These colors are use with elements which gain focus and can respond to events like hover. These colors are used with various components.

The available colors are

- Primary
- Secondary
- Info
- Success
- Warn
- Danger

### Scheme Colors

## Components

| Component                                                                                          | Description |
| -------------------------------------------------------------------------------------------------- | ----------- |
| [Accordion](/modules/framework-components/src/components/accordion/README.md)                      | ---         |
| [ActionSelector](/modules/framework-components/src/components/action-selector/README.md)           | ---         |
| [AlertMessage](/modules/framework-components/src/components/alert-message/README.md)               | ---         |
| [Avatar](/modules/framework-components/src/components/avatar/README.md)                            | ---         |
| [BackDrop](/modules/framework-components/src/components/backdrop/README.md)                        | ---         |
| [Badge](/modules/framework-components/src/components/badge/README.md)                              | ---         |
| [Button](/modules/framework-components/src/components/button/README.md)                            | ---         |
| [ButtonGroup](/modules/framework-components/src/components/button-group/README.md)                 | ---         |
| [Card](/modules/framework-components/src/components/card/README.md)                                | ---         |
| [CheckInput](/modules/framework-components/src/components/check-input/README.md)                   | ---         |
| [Chip](/modules/framework-components/src/components/chip/README.md)                                | ---         |
| [DateInput](/modules/framework-components/src/components/date-input/README.md)                     | ---         |
| [Dialog](/modules/framework-components/src/components/dialog/README.md)                            | ---         |
| [Document](/modules/framework-components/src/components/document/README.md)                        | ---         |
| [Dot](/modules/framework-components/src/components/dot/README.md)                                  | ---         |
| [DropDown](/modules/framework-components/src/components/drop-down/README.md)                       | ---         |
| [FileDrop](/modules/framework-components/src/components/file-drop/README.md)                       | ---         |
| [Grid](/modules/framework-components/src/components/grid/README.md)                                | ---         |
| [Icon](/modules/framework-components/src/components/icon/README.md)                                | ---         |
| [IconButton](/modules/framework-components/src/components/icon-button/README.md)                   | ---         |
| [InputMessages](/modules/framework-components/src/components/input-messages/README.md)             | ---         |
| [Link](/modules/framework-components/src/components/link/README.md)                                | ---         |
| [MaskInput](/modules/framework-components/src/components/mask-input/README.md)                     | ---         |
| [Menu](/modules/framework-components/src/components/menu/README.md)                                | ---         |
| [MultiSelectInput](/modules/framework-components/src/components/multi-select-input/README.md)      | ---         |
| [NotificationMessage](/modules/framework-components/src/components/notification-message/README.md) | ---         |
| [NumericInput](/modules/framework-components/src/components/numeric-input/README.md)               | ---         |
| [OrderableList](/modules/framework-components/src/components/orderable-list/README.md)             | ---         |
| [Page](/modules/framework-components/src/components/page/README.md)                                | ---         |
| [PageNotification](/modules/framework-components/src/components/page-notification/README.md)       | ---         |
| [Pagination](/modules/framework-components/src/components/pagination/README.md)                    | ---         |
| [PDFViewer](/modules/framework-components/src/components/pdf-viewer/README.md)                     | ---         |
| [Popover](/modules/framework-components/src/components/popover/README.md)                          | ---         |
| [RadioInputGroup](/modules/framework-components/src/components/radio-input-group/README.md)        | ---         |
| [ResolutionBinding](/modules/framework-components/src/components/resolution-binding/README.md)     | ---         |
| [SelectInput](/modules/framework-components/src/components/select-input/README.md)                 | ---         |
| [Spinner](/modules/framework-components/src/components/spinner/README.md)                          | ---         |
| [SwitchInput](/modules/framework-components/src/components/switch-input/README.md)                 | ---         |
| [TabBar](/modules/framework-components/src/components/tab-bar/README.md)                           | ---         |
| [TabGroup](/modules/framework-components/src/components/tab-group/README.md)                       | ---         |
| [Table](/modules/framework-components/src/components/table/README.md)                              | ---         |
| [TableMessage](/modules/framework-components/src/components/table-message/README.md)               | ---         |
| [Text](/modules/framework-components/src/components/text/README.md)                                | ---         |
| [TextAreaInput](/modules/framework-components/src/components/text-area-input/README.md)            | ---         |
| [TextInput](/modules/framework-components/src/components/text-input/README.md)                     | ---         |
| [TextList](/modules/framework-components/src/components/text-list/README.md)                       | ---         |
| [ToolTip](/modules/framework-components/src/components/tooltip/README.md)                          | ---         |
| [Tray](/modules/framework-components/src/components/tray/README.md)                                | ---         |
| [Typography](/modules/framework-components/src/components/typography/README.md)                    | ---         |
| [ValueField](/modules/framework-components/src/components/value-field/README.md)                   | ---         |
