// @ts-nocheck
import isNil from 'lodash-es/isNil';
/*
hidden
hidden-gt-sm
hidden-gt-md
hidden-gt-lg
hidden-gt-xl
hidden-lt-md
hidden-lt-lg
hidden-lt-xl
hidden-lt-2xl
*/

// Force
export default function hiddenBuilder(reflexSizes = {}, condition = null) {
	if (condition === false) {
		return '';
	}

	const { gt, lt } = reflexSizes;

	const gtEmpty = isNil(gt) || gt.length <= 0;
	const ltEmpty = isNil(lt) || lt.length <= 0;

	if (!gtEmpty && !ltEmpty) {
		return `hidden-gt-${gt} hidden-lt-${lt}`;
	}

	if (!gtEmpty) {
		return `hidden-gt-${gt}`;
	}

	if (!ltEmpty) {
		return `hidden-lt-${lt}`;
	}

	return 'hidden';
}
