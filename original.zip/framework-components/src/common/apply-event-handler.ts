// @ts-nocheck
function applyEventHandler(target, eventName, handler, options) {
	target.addEventListener(eventName, handler, options);

	return () => {
		target.removeEventListener(eventName, handler);
	};
}

export default applyEventHandler;
