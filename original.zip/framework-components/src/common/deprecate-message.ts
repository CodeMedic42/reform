// @ts-nocheck
import isNil from 'lodash-es/isNil';

const messages = {};

export default function deprecateMessage(messageId, message) {
	if (isNil(messages[messageId])) {
		// eslint-disable-next-line no-console
		console.warn(message);

		messages[messageId] = true;
	}
}
