// @ts-nocheck
export default function preventDefault(event) {
	event.preventDefault();
}
