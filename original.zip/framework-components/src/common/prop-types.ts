// @ts-nocheck
import PropTypes from 'prop-types';

PropTypes.icon = PropTypes.shape({
	// eslint-disable-next-line react/forbid-prop-types
	icon: PropTypes.arrayOf(PropTypes.any).isRequired,
	prefix: PropTypes.string.isRequired,
	iconName: PropTypes.string.isRequired,
});

PropTypes.pageNavMenuOption = PropTypes.shape({
	id: PropTypes.string,
	// eslint-disable-next-line react/forbid-prop-types
	icon: PropTypes.any,
	label: PropTypes.string,
});

PropTypes.pageNavMenuOptions = PropTypes.arrayOf(PropTypes.pageNavMenuOption);

PropTypes.applicationMenuItem = PropTypes.shape({
	label: PropTypes.string,
	href: PropTypes.string,
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
});

export default PropTypes;
