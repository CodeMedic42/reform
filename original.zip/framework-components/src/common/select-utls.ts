// @ts-nocheck
import isNil from 'lodash-es/isNil';
import get from 'lodash-es/get';
import toLower from 'lodash-es/toLower';
import isString from 'lodash-es/isString';
import isFunction from 'lodash-es/isFunction';
import isNumber from 'lodash-es/isNumber';

export function getId(option, keyPath) {
	if (isNil(option)) {
		return null;
	}

	if (isString(option) || isNumber(option)) {
		return option;
	}

	if (isNil(keyPath)) {
		throw new Error(
			'keyPath is required when not using strings for values.',
		);
	}

	let key = null;

	if (isString(keyPath)) {
		if (keyPath.length <= 0) {
			throw new Error('keyPath cannot be empty.');
		}

		key = get(option, keyPath);
	} else {
		key = keyPath(option);
	}

	if (isString(key) || isNumber(key)) {
		return key;
	}

	throw new Error('Key must be a string or number');
}

export function getOptionText(option, optionTextPath) {
	let text = option;

	if (!isString(option) && !isNumber(option)) {
		if (isNil(optionTextPath)) {
			throw new Error(
				'optionTextPath is required when not using strings for options.',
			);
		}

		if (isString(optionTextPath)) {
			if (optionTextPath.length <= 0) {
				throw new Error('selectedTextPath cannot be empty.');
			}

			text = get(option, optionTextPath);
		}
	}

	if (isFunction(optionTextPath)) {
		text = optionTextPath(option);
	}

	if ((isString(text) && text.length > 0) || isNumber(text)) {
		return text;
	}

	throw new Error('Option text must be an non empty string or number');
}

export function beforeInsertOption(option, optionTextPath) {
	return {
		value: option,
		text: getOptionText(option, optionTextPath),
	};
}

export function buildFinalOptions(
	filter,
	hideSelected,
	customValueSetting,
	optionsContext,
) {
	let filterMatched = false;

	let checkValue = filter;
	let filterCheck = () => false;

	if (customValueSetting === 'sensitive') {
		filterCheck = (item) => item.getValue('text') === checkValue;
	} else if (customValueSetting === 'insensitive') {
		checkValue = toLower(filter);

		filterCheck = (item) => toLower(item.getValue('text')) === checkValue;
	}

	const items = optionsContext.reduce((acc, item) => {
		const priority = item.getFilterPriority();
		const selected = item.hasTag('selected');

		filterMatched = filterMatched || filterCheck(item);

		if (priority > 0 && !(hideSelected && selected)) {
			acc.push(item);
		}

		return acc;
	}, []);

	return {
		filterMatched,
		items,
	};
}

export function shouldUpdate(previousProps, nextProps) {
	return (
		previousProps.id !== nextProps.id ||
		previousProps.className !== nextProps.className ||
		previousProps.options !== nextProps.options ||
		previousProps.placeholder !== nextProps.placeholder ||
		previousProps.title !== nextProps.title ||
		previousProps.label !== nextProps.label ||
		previousProps['aria-label'] !== nextProps['aria-label'] ||
		previousProps['aria-labelledby'] !== nextProps['aria-labelledby'] ||
		previousProps['aria-describedby'] !== nextProps['aria-describedby'] ||
		previousProps?.messages?.general !== nextProps?.messages?.general ||
		previousProps?.messages?.invalid !== nextProps?.messages?.invalid ||
		previousProps.invalid !== nextProps.invalid ||
		previousProps.hidden !== nextProps.hidden ||
		previousProps.size !== nextProps.size ||
		previousProps.nullable !== nextProps.nullable ||
		previousProps.searchMinChar !== nextProps.searchMinChar ||
		previousProps.disabled !== nextProps.disabled ||
		previousProps.listItemBorder !== nextProps.listItemBorder ||
		previousProps.dockItemsRight !== nextProps.dockItemsRight ||
		previousProps.minDrawerWidth !== nextProps.minDrawerWidth ||
		previousProps.allowCustomValue !== nextProps.allowCustomValue ||
		previousProps.noOptionsMessage !== nextProps.noOptionsMessage ||
		previousProps.useFilterMessage !== nextProps.useFilterMessage ||
		previousProps.enableSort !== nextProps.enableSort ||
		previousProps.enableExternalFilter !== nextProps.enableExternalFilter ||
		previousProps.keyPath !== nextProps.keyPath ||
		previousProps.hideSelected !== nextProps.hideSelected ||
		previousProps.onChangeMeta !== nextProps.onChangeMeta ||
		previousProps.onFilterChangeMeta !== nextProps.onFilterChangeMeta ||
		previousProps.value !== nextProps.value
	);
}
