// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import SelectInput from '../../components/select-input';

const colors = [
	{
		text: 'Primary',
		key: 'primary',
	},
	{
		text: 'Secondary',
		key: 'secondary',
	},
	{
		text: 'Info',
		key: 'info',
	},
	{
		text: 'Success',
		key: 'success',
	},
	{
		text: 'Warn',
		key: 'warn',
	},
	{
		text: 'Danger',
		key: 'danger',
	},
];

const colorsWithDefault = [
	{
		text: 'Default',
		key: 'default',
	},
	...colors,
];

function ColorSelector({ color, onChange, withDefault }) {
	return (
		<SelectInput
			id="color-value"
			label="Color"
			value={color}
			onChange={onChange}
			options={withDefault ? colorsWithDefault : colors}
		/>
	);
}

ColorSelector.propTypes = {
	color: PropTypes.string,
	onChange: PropTypes.func.isRequired,
	withDefault: PropTypes.bool,
};

ColorSelector.defaultProps = {
	color: null,
	withDefault: false,
};

export default ColorSelector;
