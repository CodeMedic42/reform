// @ts-nocheck
import split from 'lodash-es/split';
import toFinite from 'lodash-es/toFinite';

function colorToHex(color) {
	const hexadecimal = toFinite(color).toString(16);

	return hexadecimal.length === 1 ? `0${hexadecimal}` : hexadecimal;
}

export default function convertRGBtoHex(...args) {
	let [red, green, blue] = args;

	if (args.length === 1) {
		const value = red.substring(4, 14);

		[red, green, blue] = split(value, ', ');
	}

	return `#${colorToHex(red)}${colorToHex(green)}${colorToHex(blue)}`;
}
