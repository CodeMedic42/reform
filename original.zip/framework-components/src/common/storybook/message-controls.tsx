/* eslint-disable react/require-default-props */
// @ts-nocheck
import React, { useState, useCallback } from 'react';
import split from 'lodash-es/split';
import isNil from 'lodash-es/isNil';
import PropTypes from 'prop-types';
import TextAreaInput from '../../components/text-area-input';
import { Row, Column } from '../../components/grid';

function MessageControls(props) {
	const {
		onGeneralMessageChange,
		onSuccessMessageChange,
		onInvalidMessageChange,
		children,
	} = props;

	const [generalValue, setGeneralValue] = useState(null);
	const [successValue, setSuccessValue] = useState(null);
	const [invalidValue, setInvalidValue] = useState(null);

	const handleGeneralChange = useCallback((newValue) => {
		setGeneralValue(newValue);

		const messages = !isNil(newValue) ? split(newValue, '\n') : [];

		onGeneralMessageChange(messages);
	});

	const handleSuccessChange = useCallback((newValue) => {
		setSuccessValue(newValue);

		const messages = !isNil(newValue) ? split(newValue, '\n') : [];

		onSuccessMessageChange(messages);
	});

	const handleInvalidChange = useCallback((newValue) => {
		setInvalidValue(newValue);

		const messages = !isNil(newValue) ? split(newValue, '\n') : [];

		onInvalidMessageChange(messages);
	});

	return (
		<>
			<Row gutter>
				<Column width="fill">
					<TextAreaInput
						label="General Messages"
						value={generalValue}
						onChange={handleGeneralChange}
					/>
				</Column>
				<Column width="fill">
					<TextAreaInput
						label="Success Messages"
						value={successValue}
						onChange={handleSuccessChange}
					/>
				</Column>
				<Column width="fill">
					<TextAreaInput
						label="Invalid Messages"
						value={invalidValue}
						onChange={handleInvalidChange}
					/>
				</Column>
			</Row>
			{children}
		</>
	);
}

MessageControls.propTypes = {
	onGeneralMessageChange: PropTypes.func,
	onSuccessMessageChange: PropTypes.func,
	onInvalidMessageChange: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	children: PropTypes.any,
};



export default MessageControls;
