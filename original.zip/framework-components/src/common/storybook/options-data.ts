// @ts-nocheck
import map from 'lodash-es/map';
import reduce from 'lodash-es/reduce';

const abbreviated = [
	{
		text: 'Bear Claw',
		key: 'bearClaw',
		selectedText: 'BC',
	},
	{
		text: 'Apple-Crumb',
		key: 'appleCrumb',
		selectedText: 'AC',
	},
	{
		text: 'Jelly',
		key: 'jelly',
		selectedText: 'JL',
	},
	{
		text: 'Powdered',
		key: 'powdered',
		selectedText: 'PD',
	},
	{
		text: 'Glazed',
		key: 'glazed',
		selectedText: 'GL',
	},
	{
		text: 'Cinnamon-Sugar',
		key: 'cinnamonSugar',
		selectedText: 'CS',
	},
	{
		text: 'Blueberry',
		key: 'blueberry',
		selectedText: 'BB',
	},
	{
		text: 'Chocolate Kreme',
		key: 'chocolateKreme',
		selectedText: 'CK',
	},
	{
		text: 'Bavarian Kreme',
		key: 'bavarianKreme',
		selectedText: 'BV',
	},
	{
		text: 'Boston Kreme',
		key: 'bostonKreme',
		selectedText: 'BK',
	},
	{
		text: 'Old-Fashioned',
		key: 'oldFashioned',
		selectedText: 'OF',
	},
	{
		text: 'Sour Cream',
		key: 'sourCream',
		selectedText: 'SC',
	},
	{
		text: 'Cruller',
		key: 'cruller',
		selectedText: 'CR',
	},
	{
		text: 'Chocolate Glazed',
		key: 'chocolateGlazed',
		selectedText: 'CG',
	},
	{
		text: 'Strawberry.Frosted.Creme.Filled.with.Extra.Sprinkles',
		key: 'strawberryFrosted',
		selectedText: 'CG',
	},
];

const options = map(abbreviated, (option) => {
	const { selectedText, ...rest } = option;

	return rest;
});

const textOnly = map(abbreviated, (option) => {
	const { text } = option;

	return text;
});

const lookUp = reduce(
	abbreviated,
	(acc, option) => {
		acc[option.key] = option;

		return acc;
	},
	{},
);

export { options, abbreviated, textOnly, lookUp };
