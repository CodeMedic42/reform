// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import SelectInput from '../../components/select-input';

const variants = [
	{
		text: 'Fill',
		key: 'fill',
	},
	{
		text: 'Outline',
		key: 'outline',
	},
	{
		text: 'Opaque',
		key: 'opaque',
	},
	{
		text: 'Fill Dark',
		key: 'fill-dark',
	},
	{
		text: 'None',
		key: 'none',
	},
];

const variantsWithDefault = [
	{
		text: 'Default',
		key: 'default',
	},
	...variants,
];

function SchemeVariantSelector({ variant, onChange, withDefault }) {
	return (
		<SelectInput
			id="scheme-variant-value"
			label="Variant"
			value={variant}
			onChange={onChange}
			options={withDefault ? variantsWithDefault : variants}
		/>
	);
}

SchemeVariantSelector.propTypes = {
	variant: PropTypes.string,
	onChange: PropTypes.func.isRequired,
	withDefault: PropTypes.bool,
};

SchemeVariantSelector.defaultProps = {
	variant: null,
	withDefault: false,
};

export default SchemeVariantSelector;
