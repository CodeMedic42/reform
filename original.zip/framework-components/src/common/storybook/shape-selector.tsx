// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import SelectInput from '../../components/select-input';

const shapes = [
	{
		text: 'Circle',
		key: 'circle',
	},
	{
		text: 'Square',
		key: 'square',
	},
];

const shapesWithDefault = [
	{
		text: 'Default',
		key: 'default',
	},
	...shapes,
];

function ShapeSelector({ shape, onChange, withDefault }) {
	return (
		<SelectInput
			id="shape-value"
			label="Shape"
			value={shape}
			onChange={onChange}
			options={withDefault ? shapesWithDefault : shapes}
		/>
	);
}

ShapeSelector.propTypes = {
	shape: PropTypes.string,
	onChange: PropTypes.func.isRequired,
	withDefault: PropTypes.bool,
};

ShapeSelector.defaultProps = {
	shape: null,
	withDefault: false,
};

export default ShapeSelector;
