// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import SelectInput from '../../components/select-input';

const sizes = [
	{
		text: 'Extra Small',
		key: 'xs',
	},
	{
		text: 'Small',
		key: 'sm',
	},
	{
		text: 'Medium',
		key: 'md',
	},
	{
		text: 'Large',
		key: 'lg',
	},
	{
		text: 'Extra Large',
		key: 'xl',
	},
];

function ColorSelector({ size, onChange }) {
	return (
		<SelectInput
			id="size-value"
			label="Size"
			value={size}
			onChange={onChange}
			options={sizes}
			nullable={false}
		/>
	);
}

ColorSelector.propTypes = {
	size: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
};

export default ColorSelector;
