// @ts-nocheck
import Accordion from '.';

export default {
	title: 'Layout/Accordion',
	component: Accordion,
};

export { default as basic } from './stories/basic';
export { default as sizes } from './stories/sizes';
export { default as colors } from './stories/colors';
