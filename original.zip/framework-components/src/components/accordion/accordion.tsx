// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';
import { faAngleUp } from '@audacious/icons/solid/faAngleUp';
import { faAngleDown } from '@audacious/icons/solid/faAngleDown';
import {
	colorPropType,
	shadePropType,
	getColorInfo,
} from '../../common/color-list';
import IconBox from '../icon-box';
import SubHeading from '../typography/sub-heading';

function handleMouseDown(event) {
	if (event.detail > 1) {
		event.preventDefault();
	}
}

class Accordion extends PureComponent {
	constructor(props) {
		super(props);

		this.state = {
			open: false,
		};

		this.handleKeyDown = this.handleKeyDown.bind(this);
		this.handleClick = this.handleClick.bind(this);
	}

	handleKeyDown(event) {
		// call onClick on enter key down
		if (event.which === 13) {
			this.handleClick(event);
		}
	}

	handleClick(event) {
		const { onClick, onClickMeta } = this.props;
		const { open } = this.state;

		this.setState({ open: !open });

		if (isNil(onClick)) {
			return;
		}

		onClick({
			event,
			meta: onClickMeta,
			open: !open,
		});
	}

	render() {
		const {
			id,
			className,
			children,
			heading,
			color,
			shade,
			size,
			borderType,
			showCarat,
			showDivider,
		} = this.props;

		const { open } = this.state;

		const { colorClasses } = getColorInfo({
			color,
			shade,
			style: 'fill',
			enableBackground: true,
		});

		const finalSize = isNil(size) ? 'md' : size;

		return (
			<div
				id={id}
				className={classnames(
					'ai-accordion',
					colorClasses,
					`size-${finalSize}`,
					`accordion-border-${borderType}`,
					className,
					{
						'accordion-carat': showCarat,
						'accordion-divider': showDivider,
						'no-color': colorClasses === null,
						'accordion-open': open,
					},
				)}
			>
				<div
					className="accordion-heading"
					tabIndex={0}
					role="button"
					onMouseDown={handleMouseDown}
					onKeyDown={this.handleKeyDown}
					onClick={this.handleClick}
				>
					{isString(heading) ? (
						<SubHeading
							className="accordion-heading-text"
							level="4"
						>
							{heading}
						</SubHeading>
					) : (
						heading
					)}
					{showCarat ? (
						<IconBox
							className="accordion-arrow"
							icon={open ? faAngleUp : faAngleDown}
							size={size}
						/>
					) : null}
				</div>
				{open ? <div className="accordion-body">{children}</div> : null}
			</div>
		);
	}
}

Accordion.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	heading: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	color: colorPropType,
	shade: shadePropType,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	borderType: PropTypes.oneOf(['shadow', 'solid']),
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	showCarat: PropTypes.bool,
	showDivider: PropTypes.bool,
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
};

Accordion.defaultProps = {
	id: null,
	className: null,
	heading: null,
	color: null,
	shade: 'lighter',
	size: 'md',
	borderType: 'shadow',
	children: null,
	showCarat: true,
	showDivider: false,
	onClick: null,
	onClickMeta: null,
};

export default Accordion;
