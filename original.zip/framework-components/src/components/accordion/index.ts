// @ts-nocheck
import Accordion from './accordion';

export default Accordion;
