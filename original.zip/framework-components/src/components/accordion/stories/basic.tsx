// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Accordion from '..';
import Scope from '../../../../.storybook/components/scope';
import Button from '../../button';
import Chip from '../../chip';
import TextInput from '../../text-input';
import { Text } from '../../typography';
import Heading from '../../typography/heading';
import SubHeading from '../../typography/sub-heading';

function accordionScope(title, showCarat, showDivider, borderType = 'shadow') {
	return (
		<Scope title={title}>
			<Accordion
				heading="Accordion Heading"
				showCarat={showCarat}
				showDivider={showDivider}
				borderType={borderType}
			>
				<Text weight="normal">Accordion Body</Text>
			</Accordion>
		</Scope>
	);
}

function example() {
	const [value, setValue] = React.useState('Value');
	const [items, setItems] = React.useState([]);

	return (
		<>
			{accordionScope('Show Carat', true, false)}
			{accordionScope('Show Divider', false, true)}
			{accordionScope('Solid Border', false, false, 'solid')}
			{accordionScope(
				'Carat, Divider and Solid Border',
				true,
				true,
				'solid',
			)}
			<Scope title="Complex Body">
				<Accordion
					heading={
						<Heading level="4">
							This accordion has a complex body and a Text
							component passed into the heading. You can pass a
							string or component into the heading prop. You can
							open or close accordions by clicking the heading or
							tabbing to it and pressing enter. Once opened you
							can tab through controls inside the accordion. This
							accordion has a long heading to show how it
							overflows.
						</Heading>
					}
				>
					<div style={{ background: 'aliceblue', padding: '10px' }}>
						<SubHeading level="4">Complex Accordion.</SubHeading>
						<div style={{ padding: '50px 0' }}>
							<div style={{ 'padding-bottom': '50px' }}>
								<TextInput
									label="Text Input"
									value={value}
									onChange={setValue}
								/>
							</div>
							<div>
								<Button
									variant="fill"
									color="primary"
									onClick={() => {
										setItems([...items, value]);
									}}
								>
									Submit
								</Button>
							</div>
							{map(items, (item) => (
								<div style={{ 'padding-top': '30px' }}>
									<Chip color="info" size="lg">
										{item}
									</Chip>
								</div>
							))}
						</div>
					</div>
				</Accordion>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
