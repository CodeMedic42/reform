// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Accordion from '..';
import Scope from '../../../../.storybook/components/scope';
import { colorOrder, paletteShades } from '../../../common/color-list';

function accordionColor(color, shade) {
	return (
		<span
			key={`${color}${shade}`}
			className="gutter-vertical"
			style={{
				display: 'inline-block',
				width: '33%',
				verticalAlign: 'top',
			}}
		>
			<Accordion
				className="gutter-horizontal"
				color={color}
				shade={shade}
				heading={shade || color}
				showCarat
			>
				<span>Accordion Body</span>
			</Accordion>
		</span>
	);
}

function example() {
	return (
		<>
			<Scope title="Accordion Colors">
				{map(colorOrder, (color) => accordionColor(color))}
			</Scope>
			<Scope title="Accordion Shades">
				{map(paletteShades, (shade) => accordionColor('grey', shade))}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Colors',
};

export default example;
