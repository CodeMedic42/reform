// @ts-nocheck
import React from 'react';
import Accordion from '..';
import { Row, Column } from '../../grid';
import Scope from '../../../../.storybook/components/scope';

function accordionSize(size, showDivider, showCarat) {
	return (
		<Column width="fill">
			<Accordion
				heading={size}
				size={size}
				showDivider={showDivider}
				showCarat={showCarat}
			>
				<p
					style={{
						width: '100%',
						height: '50px',
						lineHeight: '50px',
						textAlign: 'center',
						margin: 0,
						background: '#f0f0f0',
					}}
				>
					{size}
				</p>
			</Accordion>
		</Column>
	);
}

function sizeScope(name, showDivider, showCarat) {
	return (
		<Scope title={name}>
			<Row gutter>
				{accordionSize('xs', showDivider, showCarat)}
				{accordionSize('sm', showDivider, showCarat)}
				{accordionSize('md', showDivider, showCarat)}
				{accordionSize('lg', showDivider, showCarat)}
				{accordionSize('xl', showDivider, showCarat)}
			</Row>
		</Scope>
	);
}

function example() {
	return (
		<>
			{sizeScope('Sizes', false, true)}
			{sizeScope('Sizes with Divider', true, true)}
			{sizeScope('Sizes without Carat', false, false)}
		</>
	);
}

example.story = {
	name: 'Sizes',
};

export default example;
