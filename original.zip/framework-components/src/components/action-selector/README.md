# ActionSelector

This component is used to create an element which is used to perform selected actions.

## Use

```jsx
<ActionSelector />
```

## Props

| Property         | Type                               | Required | Default  | Description                                                                                                                     |
| ---------------- | ---------------------------------- | -------- | -------- | ------------------------------------------------------------------------------------------------------------------------------- |
| id               | String                             | No       | null     | The id to apply to the root element                                                                                             |
| className        | String                             | No       | null     | Any additional class names provided here will be added to the root element                                                      |
| label            | String                             | No       | null     | A label applied to the control.                                                                                                 |
| value            | String \|\| Number                 | No       | null     | The selected value                                                                                                              |
| variant          | 'fill' \|\| 'outline'\|\| 'opaque' | No       | 'opaque' | The button variant to use for the anchor                                                                                        |
| color            | Schema Colors                      | No       | null     | The color scheme to use when rendering the button. If not provided then will inherit the color being use by any parent element. |
| textWhenOpen     | String                             | No       | null     | Will use this text when the tray is open.                                                                                       |
| options          | object                             | No       | null     | The options to show in the tray.                                                                                                |
| optionTextPath   | String                             | No       | null     | The key of a string property in options which is used to display in the tray and for the selected option                        |
| keyPath          | String                             | No       | null     | The key of a property in options which is used as the value when the option is selected.                                        |
| selectedTextPath | String                             | No       | null     | The key of a string in options which is used when the option is selected.                                                       |
| title            | String                             | No       | null     | Standard title attribute.                                                                                                       |
| aria-label       | String                             | No       | null     | Standard aria-label attribute.                                                                                                  |
| disabled         | Bool                               | No       | null     | Standard disabled attribute.                                                                                                    |
| minDrawerWidth   | 'anchor' \|\| Number               | No       | null     | The min width px the tray should adhere to. If 'anchor' is used then the width of the anchor is used.                           |

size: PropTypes.oneOf(['2xs', 'xs', 'sm', 'md', 'lg']),
hidden: PropTypes.bool,
'aria-labelledby': PropTypes.string,
'aria-describedby': PropTypes.string,
onChange: PropTypes.func,
onChangeMeta: PropTypes.any,
onFocus: PropTypes.func,
onBlur: PropTypes.func,
hideSelected: PropTypes.bool,

    minDrawerWidth: PropTypes.oneOfType([
    	PropTypes.number,
    	PropTypes.oneOf(['anchor']),
    ]),
    allowCustomValue: PropTypes.oneOfType([
    	PropTypes.bool,
    	PropTypes.oneOf(['sensitive', 'insensitive']),
    ]),
    noOptionsMessage: PropTypes.string,
    useFilterMessage: PropTypes.string,
    enableSort: PropTypes.bool,
    enableExternalFilter: PropTypes.bool,
    selectedTextPath: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
    // eslint-disable-next-line react/no-unused-prop-types
    keyPath: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
    // eslint-disable-next-line react/no-unused-prop-types
    optionTextPath: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
