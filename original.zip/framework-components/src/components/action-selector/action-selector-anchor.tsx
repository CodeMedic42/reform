// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import { faCaretDown } from '@audacious/icons/solid/faCaretDown';
import { faCaretUp } from '@audacious/icons/solid/faCaretUp';
import Button from '../button';
import { schemeColorPropType } from '../../common/color-list';
import applyAnchorBinding from '../drop-down/anchor-binding';

class ActionSelectorAnchor extends PureComponent {
	render() {
		const {
			id,
			className,
			disabled,
			title,
			open,
			value,
			color,
			size,
			variant,
			placeholder,
			textWhenOpen,
			'aria-describedby': describedBy,
			'aria-labelledby': labelledBy,
		} = this.props;

		let selectedText = '';

		if (open && !isNil(textWhenOpen)) {
			selectedText = textWhenOpen;
		} else if (!isNil(value) && value.length > 0) {
			selectedText = value;
		} else if (!isNil(placeholder) && placeholder.length > 0) {
			selectedText = placeholder;
		}

		return (
			<Button
				id={id}
				className={classnames(
					'anchor-control',
					'action-selector-anchor',
					className,
					{ focus: open },
				)}
				color={color}
				rightIcon={open ? faCaretUp : faCaretDown}
				disabled={disabled}
				value={value}
				title={title}
				aria-describedby={describedBy}
				aria-labelledby={labelledBy}
				size={size}
				variant={variant}
			>
				{selectedText}
			</Button>
		);
	}
}

ActionSelectorAnchor.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	value: PropTypes.string,
	disabled: PropTypes.bool,
	'aria-labelledby': PropTypes.string,
	'aria-describedby': PropTypes.string,
	title: PropTypes.string,
	open: PropTypes.bool,
	color: schemeColorPropType,
	size: PropTypes.string.isRequired,
	variant: PropTypes.oneOf([null, 'fill', 'outline', 'opaque']),
	textWhenOpen: PropTypes.string,
	// eslint-disable-next-line react/require-default-props
	placeholder: PropTypes.string,
};

ActionSelectorAnchor.defaultProps = {
	id: null,
	className: null,
	value: null,
	disabled: false,
	'aria-labelledby': null,
	'aria-describedby': null,
	title: null,
	open: false,
	color: null,
	variant: 'opaque',
	textWhenOpen: null,
};

export default applyAnchorBinding(ActionSelectorAnchor, {
	displayName: 'ActionSelectorAnchor',
});
