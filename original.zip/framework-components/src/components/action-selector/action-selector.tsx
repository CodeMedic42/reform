// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Select, {
	propTypes as selectPropTypes,
	defaultProps as selectDefaultProps,
} from '../select';
import ActionSelectorAnchor from './action-selector-anchor';
import { schemeColorPropType } from '../../common/color-list';

function ActionSelector(props) {
	const { className, variant, color, textWhenOpen, ...rest } = props;

	return (
		<Select
			{...rest}
			className={classnames(className, 'ai-action-selector')}
			nullable={false}
			Anchor={ActionSelectorAnchor}
			anchorProps={{
				color,
				variant,
				textWhenOpen,
			}}
		/>
	);
}

ActionSelector.propTypes = {
	...selectPropTypes,
	value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	variant: PropTypes.oneOf(['fill', 'outline', 'opaque']),
	color: schemeColorPropType,
	textWhenOpen: PropTypes.string,
};

ActionSelector.defaultProps = {
	...selectDefaultProps,
	value: null,
	variant: 'opaque',
	textWhenOpen: null,
};

export default memo(ActionSelector);
