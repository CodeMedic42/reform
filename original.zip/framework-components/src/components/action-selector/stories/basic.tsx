// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import ActionSelector from '..';
import { options } from '../../../common/storybook/options-data';

const actionOptions = ['Received Time', 'Event Time'];

const initial = { value: 'Event Time' };

function example() {
	return (
		<>
			<Scope title="Basic" initialState={initial}>
				{(state, setState) => (
					<ActionSelector
						value={state.value}
						options={actionOptions}
						onChange={(value) => setState({ value })}
					/>
				)}
			</Scope>
			<Scope
				title="Show text in anchor when open with placeholder"
				initialState={{ value: null }}
			>
				{(state, setState) => (
					<ActionSelector
						value={state.value}
						options={actionOptions}
						textWhenOpen="Order by"
						onChange={(value) => setState({ value })}
						placeholder="Placeholder"
					/>
				)}
			</Scope>
			<Scope
				title="Option objects with key and text"
				initialState={{
					value: 'glazed',
				}}
			>
				{(state, setState) => (
					<ActionSelector
						value={state.value}
						options={options}
						onChange={(value) => setState({ value })}
					/>
				)}
			</Scope>
			<Scope
				title="List item border"
				initialState={{
					value: 'glazed',
				}}
			>
				{(state, setState) => (
					<ActionSelector
						value={state.value}
						options={options}
						onChange={(value) => setState({ value })}
						listItemBorder
					/>
				)}
			</Scope>
			<Scope title="Dock list items right" initialState={initial}>
				{(state, setState) => (
					<ActionSelector
						value={state.value}
						options={actionOptions}
						onChange={(value) => setState({ value })}
						minDrawerWidth={null}
						dockRight
					/>
				)}
			</Scope>
			<Scope title="Disabled" initialState={initial}>
				{(state, setState) => (
					<ActionSelector
						value={state.value}
						options={actionOptions}
						onChange={(value) => setState({ value })}
						disabled
					/>
				)}
			</Scope>
			<Scope title="Hidden" initialState={initial}>
				{(state, setState) => (
					<ActionSelector
						value={state.value}
						options={actionOptions}
						onChange={(value) => setState({ value })}
						hidden
					/>
				)}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
