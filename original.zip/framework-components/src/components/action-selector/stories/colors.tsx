// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Scope from '../../../../.storybook/components/scope';
import ActionSelector from '..';
import { schemeColorOrder } from '../../../common/color-list';

const options = [
	{
		text: 'Apple',
		key: 'apple',
	},
	{
		text: 'Orange',
		key: 'orange',
	},
	{
		text: 'Banana',
		key: 'banana',
	},
];

const selectColorsOptions = [
	{
		color: 'secondary',
		text: 'Fill',
		key: 'fill',
	},
	{
		color: 'warn',
		text: 'Yellow',
		key: 'yellow',
	},
	{
		color: 'success',
		text: 'Green',
		key: 'green',
	},
];

function renderScope(color) {
	return (
		<Scope
			key={color || 'default'}
			title={color || 'default'}
			initialState={{
				value: 'apple',
			}}
		>
			{(state, setState) => (
				<ActionSelector
					value={state.value}
					options={options}
					onChange={(value) => setState({ value })}
					color={color}
				/>
			)}
		</Scope>
	);
}

function example() {
	return (
		<>
			{map([null, ...schemeColorOrder], renderScope)}
			<Scope
				title="Selected Color"
				initialState={{
					value: 'fill',
				}}
			>
				{(state, setState) => (
					<ActionSelector
						value={state.value}
						options={selectColorsOptions}
						onChange={(value) => setState({ value })}
					/>
				)}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Colors',
};

export default example;
