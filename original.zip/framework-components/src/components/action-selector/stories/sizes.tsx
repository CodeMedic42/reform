// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import ActionSelector from '..';

const actionOptions = ['Received Time', 'Event Time'];

const initial = { value: 'Event Time' };

function renderSize(title, size) {
	return (
		<Scope title={title} initialState={initial}>
			{(state, setState) => (
				<ActionSelector
					value={state.value}
					options={actionOptions}
					onChange={(value) => setState({ value })}
					size={size}
				/>
			)}
		</Scope>
	);
}

function example() {
	return (
		<>
			{renderSize('Extra Extra Small', '2xs')}
			{renderSize('Extra Small', 'xs')}
			{renderSize('Small', 'sm')}
			{renderSize('Medium', 'md')}
			{renderSize('Large', 'lg')}
		</>
	);
}

example.story = {
	name: 'Sizes',
};

export default example;
