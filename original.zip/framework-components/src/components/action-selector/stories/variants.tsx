// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import ActionSelector from '..';

const actionOptions = ['Received Time', 'Event Time'];

const initial = { value: 'Event Time' };

function renderSize(title, variant) {
	return (
		<Scope title={title} initialState={initial}>
			{(state, setState) => (
				<ActionSelector
					value={state.value}
					options={actionOptions}
					onChange={(value) => setState({ value })}
					variant={variant}
				/>
			)}
		</Scope>
	);
}

function example() {
	return (
		<>
			{renderSize('Opaque', 'opaque')}
			{renderSize('Outlined', 'outline')}
			{renderSize('Filled', 'fill')}
		</>
	);
}

example.story = {
	name: 'Variants',
};

export default example;
