// @ts-nocheck
import AlertMessage from '.';

export default {
	title: 'Messaging/Alert Message',
	component: AlertMessage,
};

export { default as properties } from './stories/preview';
