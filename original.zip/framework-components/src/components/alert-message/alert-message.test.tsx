// @ts-nocheck
// eslint-disable-next-line import/no-extraneous-dependencies
import { expect, jest } from '@jest/globals';
import React from 'react';
import isNil from 'lodash-es/isNil';
import forEach from 'lodash-es/forEach';
import { faXmark } from '@audacious/icons/solid/faXmark';
import AlertMessage from '.';
import Button from '../button';

const staticClasses = ['ai-alert-message', 'sch-lite', 'ai-scheme', 'sch-br'];

function attributeTest(targetNode, expectedAttributes = []) {
	const attributesLength = expectedAttributes.length + 1; // Start at one because className probably exists.

	forEach(expectedAttributes, (attribute) => {
		const { name, value } = attribute;

		expect(targetNode.getAttribute(name)).toEqual(value);
	});

	expect(targetNode.attributes.length).toEqual(
		attributesLength,
		'Attributes length incorrect',
	);
}

function expectActionButtonToNotExist(wrapper) {
	const button = wrapper.find(Button);
	expect(button.length).toBe(0);
}

function getMessageIcon(wrapper) {
	return wrapper.findWhere((n) => {
		const name = n.name();
		const { className } = n.props();

		const correctClassName = !isNil(className)
			? className.includes('alert-message-icon')
			: false;

		return name === 'Icon' && correctClassName;
	});
}

function expectMessageIconToNotExist(wrapper) {
	const icon = getMessageIcon(wrapper);

	expect(icon.length).toBe(0);
}

function expectMessageIconToBe(wrapper, iconProp) {
	const icon = getMessageIcon(wrapper);

	expect(icon.length).toBe(1);

	const iconProps = icon.props();
	expect(iconProps).toHaveProperty('className', 'alert-message-icon');
	expect(iconProps).toHaveProperty('icon', iconProp);
}

function expectMessageHeadingToNotExist(wrapper) {
	const heading = wrapper.find('.alert-message-heading');
	expect(heading).not.toEqual(undefined);
}

function expectMessageHeadingToBe(wrapper, expectedHeading) {
	const headingNode = wrapper.find('div.alert-message-heading');
	expect(headingNode.length).toBe(1);
	expect(headingNode.text()).toEqual(expectedHeading);
}

function expectMessageClearButtonToNotExist(wrapper) {
	const clearButton = wrapper.find('button.alert-message-clear-btn');
	expect(clearButton.length).toBe(0);
}

function expectMessageToBe(wrapper, expectedMessage) {
	const messageNode = wrapper.find('.alert-message-text');

	expect(messageNode.length).toBe(1);
	expect(messageNode.text()).toEqual(expectedMessage);
}

function expectMessageActionToBe(wrapper, sizeProp, colorProp, actionProp) {
	const actionButton = wrapper.find(Button);
	expect(actionButton.length).toBe(1);

	const buttonProps = actionButton.props();
	expect(buttonProps).toHaveProperty(
		'className',
		'alert-message-action-btn',
	);
	expect(buttonProps).toHaveProperty('size', sizeProp);
	expect(buttonProps).toHaveProperty('variant', 'fill');
	expect(buttonProps).toHaveProperty('color', colorProp);
	expect(buttonProps).toHaveProperty('onClick', actionProp.onClick);
	expect(buttonProps).toHaveProperty('onClickMeta', actionProp.onClickMeta);
	expect(buttonProps).toHaveProperty('children', actionProp.label);

	actionButton.simulate('click');
	expect(actionProp.onClick.mock.calls.length).toBe(1);
	expect(actionProp.onClick.mock.calls[0][0].event).not.toEqual(undefined);
	expect(actionProp.onClick.mock.calls[0][0].meta).toEqual(
		actionProp.onClickMeta,
	);
}

function expectMessageClearButtonToBe(wrapper, onClearProp, onClearMetaProp) {
	const clearButton = wrapper.find('button.alert-message-clear-btn');
	expect(clearButton.length).toBe(1);

	clearButton.simulate('click');
	expect(onClearProp.mock.calls.length).toBe(1);
	expect(onClearProp.mock.calls[0][0].event).not.toEqual(undefined);
	expect(onClearProp.mock.calls[0][0].meta).toEqual(onClearMetaProp);
}

function expectRootToBe(
	wrapper,
	sizeProp,
	{ additionalClasses = [], additionalAttributes = [] } = {},
) {
	const rootNode = wrapper.getDOMNode();

	expect(rootNode.nodeName).toEqual('DIV');

	expect([...rootNode.classList])
		.toEqual(expect.arrayContaining([
			...staticClasses,
			`size-${sizeProp}`,
			...additionalClasses,
		]));

	attributeTest(rootNode, additionalAttributes);
}

describe('Components', () => {
	describe('AlertMessage', () => {
		it('No props', () => {
			const wrapper = global.mountTo(<AlertMessage />);

			expectRootToBe(wrapper, 'md');

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With id prop', () => {
			const idProp = 'idTest';

			const wrapper = global.mountTo(<AlertMessage id={idProp} />);

			expectRootToBe(wrapper, 'md', {
				additionalAttributes: [{ name: 'id', value: idProp }],
			});

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With className prop', () => {
			const classNameProp = 'classNameTest';

			const wrapper = global.mountTo(<AlertMessage className={classNameProp} />);

			expectRootToBe(wrapper, 'md', {
				additionalClasses: [classNameProp],
			});

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With icon prop', () => {
			const iconProp = faXmark;

			const wrapper = global.mountTo(<AlertMessage icon={iconProp} />);

			expectRootToBe(wrapper, 'md');

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToBe(wrapper, iconProp);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With heading prop', () => {
			const headingProp = 'Test heading';

			const wrapper = global.mountTo(<AlertMessage heading={headingProp} />);

			expectRootToBe(wrapper, 'md');

			expectMessageHeadingToBe(wrapper, headingProp);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With message prop', () => {
			const messageProp = 'Test message';

			const wrapper = global.mountTo(<AlertMessage message={messageProp} />);

			expectRootToBe(wrapper, 'md');

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, messageProp);

			expectMessageIconToNotExist(wrapper);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With children prop', () => {
			const messageProp = 'Test message';

			const wrapper = global.mountTo(<AlertMessage>{messageProp}</AlertMessage>);

			expectRootToBe(wrapper, 'md');

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, messageProp);

			expectMessageIconToNotExist(wrapper);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With color prop', () => {
			const colorProp = 'primary';

			const wrapper = global.mountTo(<AlertMessage color={colorProp} />);

			expectRootToBe(wrapper, 'md', {
				additionalClasses: [`sch-${colorProp}`],
			});

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With action prop', () => {
			const actionProp = {
				label: 'Test Action',
				onClick: jest.fn(),
				onClickMeta: 'metaTest',
			};
			const colorProp = 'primary';

			const wrapper = global.mountTo(
				<AlertMessage action={actionProp} color={colorProp} />,
			);

			expectRootToBe(wrapper, 'md', {
				additionalClasses: [`sch-${colorProp}`],
			});

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectMessageActionToBe(wrapper, 'md', colorProp, actionProp);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With onClear prop', () => {
			const onClearProp = jest.fn();
			const onClearMetaProp = 'metaTest';

			const wrapper = global.mountTo(
				<AlertMessage
					onClear={onClearProp}
					onClearMeta={onClearMetaProp}
				/>,
			);

			expectRootToBe(wrapper, 'md');

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectActionButtonToNotExist(wrapper);

			expectMessageClearButtonToBe(wrapper, onClearProp, onClearMetaProp);
		});

		it('With null size prop', () => {
			const sizeProp = null;
			const actionProp = {
				label: 'Test Action',
				onClick: jest.fn(),
				onClickMeta: 'metaTest',
			};

			const wrapper = global.mountTo(
				<AlertMessage size={sizeProp} action={actionProp} />,
			);

			expectRootToBe(wrapper, 'md');

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectMessageActionToBe(wrapper, 'md', null, actionProp);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With xs size prop', () => {
			const sizeProp = 'xs';
			const actionProp = {
				label: 'Test Action',
				onClick: jest.fn(),
				onClickMeta: 'metaTest',
			};

			const wrapper = global.mountTo(
				<AlertMessage size={sizeProp} action={actionProp} />,
			);

			expectRootToBe(wrapper, sizeProp);

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectMessageActionToBe(wrapper, 'sm', null, actionProp);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With sm size prop', () => {
			const sizeProp = 'sm';
			const actionProp = {
				label: 'Test Action',
				onClick: jest.fn(),
				onClickMeta: 'metaTest',
			};

			const wrapper = global.mountTo(
				<AlertMessage size={sizeProp} action={actionProp} />,
			);

			expectRootToBe(wrapper, sizeProp);

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectMessageActionToBe(wrapper, 'md', null, actionProp);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With md size prop', () => {
			const sizeProp = 'md';
			const actionProp = {
				label: 'Test Action',
				onClick: jest.fn(),
				onClickMeta: 'metaTest',
			};

			const wrapper = global.mountTo(
				<AlertMessage size={sizeProp} action={actionProp} />,
			);

			expectRootToBe(wrapper, sizeProp);

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectMessageActionToBe(wrapper, 'md', null, actionProp);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With lg size prop', () => {
			const sizeProp = 'lg';
			const actionProp = {
				label: 'Test Action',
				onClick: jest.fn(),
				onClickMeta: 'metaTest',
			};

			const wrapper = global.mountTo(
				<AlertMessage size={sizeProp} action={actionProp} />,
			);

			expectRootToBe(wrapper, sizeProp);

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectMessageActionToBe(wrapper, 'md', null, actionProp);

			expectMessageClearButtonToNotExist(wrapper);
		});

		it('With xl size prop', () => {
			const sizeProp = 'xl';
			const actionProp = {
				label: 'Test Action',
				onClick: jest.fn(),
				onClickMeta: 'metaTest',
			};

			const wrapper = global.mountTo(
				<AlertMessage size={sizeProp} action={actionProp} />,
			);

			expectRootToBe(wrapper, sizeProp);

			expectMessageHeadingToNotExist(wrapper);

			expectMessageToBe(wrapper, '');

			expectMessageIconToNotExist(wrapper);

			expectMessageActionToBe(wrapper, 'lg', null, actionProp);

			expectMessageClearButtonToNotExist(wrapper);
		});
	});
});
