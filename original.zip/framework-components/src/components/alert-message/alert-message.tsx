/* eslint-disable jsx-a11y/control-has-associated-label */
// @ts-nocheck
import React, { memo, useCallback, useMemo } from 'react';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import { faXmark } from '@audacious/icons/solid/faXmark';
import Icon from '../icon';
import Button from '../button';
import SubHeading from '../typography/sub-heading';
import PropTypes from '../../common/prop-types';
import {
	schemeColorPropType,
	getSchemeColorClasses,
} from '../../common/color-list';

function AlertMessage(props) {
	const {
		id,
		className,
		icon,
		heading,
		message,
		color,
		action,
		children,
		onClear,
		onClearMeta,
		size = 'md',
		...rest
	} = props;

	const handleClearClick = useCallback(
		(event) => {
			onClear({
				event,
				meta: onClearMeta,
			});
		},
		[onClear, onClearMeta],
	);

	const sizes = useMemo(() => {
		let buttonSize = 'md';
		let headingLevel = '3';

		if (size === 'xs') {
			buttonSize = 'sm';
			headingLevel = '4';
		} else if (size === 'sm') {
			buttonSize = 'md';
			headingLevel = '4';
		} else if (size === 'lg') {
			buttonSize = 'md';
			headingLevel = '2';
		} else if (size === 'xl') {
			buttonSize = 'lg';
			headingLevel = '1';
		}

		return {
			alertSize: !isNil(size) ? size : 'md',
			buttonSize,
			headingLevel,
		};
	}, [size]);

	const colorClasses = getSchemeColorClasses({
		colorRequired: false,
		color,
		style: 'lite',
		enableBorder: true,
	});

	return (
		<div
			{...rest}
			id={id}
			className={classnames(
				'ai-alert-message',
				`size-${sizes.alertSize}`,
				className,
				colorClasses,
			)}
		>
			{!isNil(icon) ? (
				<Icon
					className="alert-message-icon"
					icon={icon}
					color={color}
				/>
			) : null}
			<div className="alert-message-content">
				{!isNil(heading) ? (
					<SubHeading
						className="alert-message-heading"
						level={sizes.headingLevel}
						responsive
					>
						{heading}
					</SubHeading>
				) : null}
				<div className="alert-message-text">
					{!isNil(message) ? message : children}
				</div>
				{!isNil(action) ? (
					<Button
						className="alert-message-action-btn"
						size={sizes.buttonSize}
						color={color}
						variant="fill"
						onClick={action.onClick}
						onClickMeta={action.onClickMeta}
					>
						{action.label}
					</Button>
				) : null}
			</div>
			{!isNil(onClear) ? (
				<button
					className={classnames(
						'alert-message-clear-btn',
						'sch-lite',
						'sch-br',
					)}
					type="button"
					onClick={handleClearClick}
				>
					<Icon icon={faXmark} size="sm" />
				</button>
			) : null}
		</div>
	);
}

AlertMessage.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	icon: PropTypes.icon,
	heading: PropTypes.string,
	message: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
		PropTypes.string,
	]),
	color: schemeColorPropType,
	action: PropTypes.shape({
		label: PropTypes.string.isRequired,
		onClick: PropTypes.func.isRequired,
		onClickMeta: PropTypes.any,
	}),
	onClear: PropTypes.func,
	onClearMeta: PropTypes.any,
	size: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
		PropTypes.string,
	]),
};

AlertMessage.defaultProps = {
	id: null,
	className: null,
	icon: null,
	heading: null,
	action: null,
	onClear: null,
	onClearMeta: null,
	size: 'md',
	color: null,
	message: null,
	children: null,
};

export default memo(AlertMessage);
