// @ts-nocheck
import Avatar from '.';

export default {
	title: 'Labeling/Avatar',
	component: Avatar,
};

export { default as colors } from './stories/colors';
