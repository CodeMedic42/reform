// @ts-nocheck
import React, { memo, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import {
	colorPropType,
	getColorInfo,
	shadePropType,
} from '../../common/color-list';

function Avatar(props) {
	const {
		id,
		className,
		color,
		shade,
		size,
		onClick,
		onClickMeta,
		children,
		asButton,
		enableBorder,
		'aria-label': ariaLabel,
	} = props;

	const colorClasses = useMemo(
		() =>
			getColorInfo({
				color,
				shade,
				style: 'fill',
				enableBackground: true,
				enableBorder,
				borderWidth: 2,
			}).colorClasses,
		[color, shade],
	);

	let Root = 'span';
	let handleClick = null;

	if (asButton) {
		Root = 'button';

		if (!isNil(onClick)) {
			handleClick = useCallback(
				(event) => {
					onClick({ event, meta: onClickMeta });
				},
				[onClick, onClickMeta],
			);
		}
	}

	return (
		<Root
			id={id}
			className={classnames(
				'ai-avatar',
				colorClasses,
				`size-${!isNil(size) ? size : 'md'}`,
				className,
			)}
			onClick={handleClick}
			aria-label={ariaLabel}
		>
			{children}
		</Root>
	);
}

Avatar.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	color: colorPropType.isRequired,
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
	shade: shadePropType,
	asButton: PropTypes.bool,
	enableBorder: PropTypes.bool,
	'aria-label': PropTypes.string,
};

Avatar.defaultProps = {
	id: null,
	className: null,
	children: null,
	shade: 'lighter',
	size: 'md',
	onClick: null,
	onClickMeta: null,
	asButton: false,
	enableBorder: false,
	'aria-label': null,
};

export default memo(Avatar);
