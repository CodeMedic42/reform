// @ts-nocheck
import Avatar from './avatar';

export default Avatar;
