/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
// @ts-nocheck
import React, { PureComponent } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';

class Backdrop extends PureComponent {
	constructor(props) {
		super(props);

		this.handleClick = this.handleClick.bind(this);
		this.handleAnimationEnd = this.handleAnimationEnd.bind(this);

		const { enableAnimation } = props;

		this.state = {
			render: !enableAnimation,
		};
	}

	componentDidMount() {
		const { enabled, position } = this.props;

		if (!enabled || position !== 'fixed') {
			return;
		}

		this.mounted = true;
		Backdrop.mountedCount += 1;
		Backdrop.disableScroll();
	}

	componentDidUpdate() {
		const { enabled, position } = this.props;

		if (position !== 'fixed') {
			if (this.mounted) {
				this.mounted = false;

				Backdrop.mountedCount -= 1;

				if (Backdrop.mountedCount <= 0) {
					Backdrop.enableScroll();
				}
			}

			return;
		}

		if (enabled && !this.mounted) {
			this.mounted = true;

			Backdrop.mountedCount += 1;

			Backdrop.disableScroll();
		} else if (!enabled && this.mounted) {
			this.mounted = false;

			Backdrop.mountedCount -= 1;

			if (Backdrop.mountedCount <= 0) {
				Backdrop.enableScroll();
			}
		}
	}

	componentWillUnmount() {
		if (this.mounted) {
			this.mounted = false;

			Backdrop.mountedCount -= 1;

			if (Backdrop.mountedCount <= 0) {
				Backdrop.enableScroll();
			}
		}
	}

	handleClick(event) {
		const { onClick, onClickMeta } = this.props;

		if (isNil(onClick)) {
			return;
		}

		onClick({
			event,
			meta: onClickMeta,
		});
	}

	handleAnimationEnd() {
		const { enabled } = this.props;

		const { render } = this.state;

		if (enabled) {
			if (!render) {
				this.setState({
					render: true,
				});
			}
		} else if (render) {
			this.setState({
				render: false,
			});
		}
	}

	render() {
		const { id, className, enabled, variant, enableAnimation, position } =
			this.props;

		const { render } = this.state;

		const rendered = render && enableAnimation;

		const variantClass = !isNil(variant) ? variant : 'dark';

		const backdrop = (
			<div
				id={id}
				className={classnames(
					className,
					'ai-backdrop',
					`position-${position}`,
					variantClass,
					{
						'backdrop-enabled': enabled || rendered,
						'backdrop-set': enabled,
						'backdrop-remove': !enabled && rendered,
						'enable-animation': enableAnimation,
					},
				)}
				onClick={this.handleClick}
				onAnimationEnd={this.handleAnimationEnd}
			/>
		);

		if (position === 'fixed') {
			return ReactDOM.createPortal(backdrop, window.document.body);
		}

		return backdrop;
	}
}

Backdrop.mountedCount = 0;
Backdrop.prevented = false;
Backdrop.backupScroll = null;
Backdrop.backupPosition = null;
Backdrop.backupWidth = null;
Backdrop.backupBoxSizing = null;
Backdrop.scrollDisabled = false;
Backdrop.mountedBackdrops = [];

Backdrop.disableScroll = () => {
	if (Backdrop.scrollDisabled) {
		return;
	}

	Backdrop.scrollDisabled = true;

	document.documentElement.style.overflow = 'hidden';

	window.dispatchEvent(new Event('resize'));
};

Backdrop.enableScroll = () => {
	if (!Backdrop.scrollDisabled) {
		return;
	}

	Backdrop.scrollDisabled = false;

	document.documentElement.style.overflow = '';

	window.dispatchEvent(new Event('resize'));
};

Backdrop.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
	enabled: PropTypes.bool,
	variant: PropTypes.oneOf(['lite', 'dark']),
	enableAnimation: PropTypes.bool,
	position: PropTypes.oneOf(['fixed', 'absolute']).isRequired,
};

Backdrop.defaultProps = {
	id: null,
	className: null,
	onClick: null,
	onClickMeta: null,
	enabled: true,
	variant: 'dark',
	enableAnimation: false,
};

export default Backdrop;
