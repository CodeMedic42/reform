/* eslint-disable react/jsx-curly-brace-presence */
// @ts-nocheck
import React from 'react';
import Button from '../../button';
import Backdrop from '..';

function example(props) {
	return (
		<div
			style={{
				position: 'absolute',
				padding: 50,
				top: 0,
				left: 0,
				bottom: 0,
				right: 0,
				boxSizing: 'border-box',
			}}
		>
			<div
				style={{
					position: 'relative',
					height: '100%',
					width: '100%',
					padding: 50,
					boxSizing: 'border-box',
				}}
			>
				<Button>{"Can't Click Me!"}</Button>
				<div style={{ height: 1000, width: '100%' }} />
				<Backdrop {...props} />
			</div>
		</div>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		onClick: { table: { disable: true } },
		onClickMeta: { table: { disable: true } },
		enabled: {
			control: 'boolean',
		},
		variant: {
			options: ['lite', 'dark'],
			control: { type: 'select' },
			description: 'The style to render the button as.',
		},
		enableAnimation: {
			control: 'boolean',
		},
		position: {
			options: ['fixed', 'absolute'],
			control: { type: 'select' },
			description: 'The style to render the button as.',
		},
	},
	args: {
		position: 'absolute',
		enabled: true,
		variant: 'dark',
		enableAnimation: false,
	},
};

export default example;
