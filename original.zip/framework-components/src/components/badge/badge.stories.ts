// @ts-nocheck
import Badge from '.';

export default {
	title: 'Labeling/Badge',
	component: Badge,
};

export { default as basics } from './stories/basic';
