// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isString from 'lodash-es/isString';
import {
	schemeColorPropType,
	getSchemeColorClasses,
} from '../../common/color-list';

class Badge extends React.PureComponent {
	render() {
		const { id, className, value, color, children, position } = this.props;

		let contentElement = null;

		if (isString(value)) {
			const colorClasses = getSchemeColorClasses({
				colorRequired: false,
				color,
				style: 'fill',
			});

			contentElement = (
				<span
					className={classnames(
						'ai-badge-value',
						'ai-badge-tag',
						colorClasses,
						`position-${position}`,
					)}
				>
					{value}
				</span>
			);
		} else {
			contentElement = (
				<span
					className={classnames(
						'ai-badge-value',
						`position-${position}`,
					)}
				>
					{value}
				</span>
			);
		}

		return (
			<span id={id} className={classnames('ai-badge', className)}>
				{children}
				{contentElement}
			</span>
		);
	}
}

Badge.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	children: PropTypes.oneOfType([PropTypes.node]),
	value: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	color: schemeColorPropType,
	position: PropTypes.oneOf([
		'top-left',
		'top-right',
		'bottom-left',
		'bottom-right',
	]),
};

Badge.defaultProps = {
	id: null,
	className: null,
	children: null,
	value: null,
	color: 'primary',
	position: 'top-right',
};

export default Badge;
