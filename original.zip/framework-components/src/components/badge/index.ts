// @ts-nocheck
import Badge from './badge';

export default Badge;
