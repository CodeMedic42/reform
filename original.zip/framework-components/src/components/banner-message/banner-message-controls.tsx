// @ts-nocheck
import React, { memo } from 'react';
import isNil from 'lodash-es/isNil';
import { faXmarkLarge } from '@audacious/icons/solid/faXmarkLarge';
import { faCaretUp } from '@audacious/icons/solid/faCaretUp';
import { faCaretDown } from '@audacious/icons/solid/faCaretDown';
import IconButton from '../icon-button';
import Button from '../button';
import PropTypes from '../../common/prop-types';

function BannerMessageControls(props) {
	const {
		additionalMessageLabel,
		additionalMessageOpen,
		onAdditionalMessageToggle,
		actionButtonLabel,
		actionButtonOnClick,
		actionButtonOnClickMeta,
		clearButtonOnClick,
		clearButtonOnClickMeta,
	} = props;

	const actionControl = !isNil(actionButtonOnClick) ? (
		<Button
			className="banner-message-action-btn"
			size="xs"
			variant="fill"
			onClick={actionButtonOnClick}
			onClickMeta={actionButtonOnClickMeta}
		>
			{actionButtonLabel}
		</Button>
	) : null;

	const additionalMessageControl = !isNil(additionalMessageLabel) ? (
		<Button
			className="banner-message-action-btn"
			size="xs"
			variant="opaque"
			onClick={onAdditionalMessageToggle}
			rightIcon={additionalMessageOpen ? faCaretUp : faCaretDown}
		>
			{additionalMessageLabel}
		</Button>
	) : null;

	const clearControl = !isNil(clearButtonOnClick) ? (
		<IconButton
			className="banner-message-remove-btn"
			icon={faXmarkLarge}
			size="2xs"
			onClick={clearButtonOnClick}
			onClickMeta={clearButtonOnClickMeta}
		/>
	) : null;

	if (
		isNil(actionControl) &&
		isNil(additionalMessageControl) &&
		isNil(clearControl)
	) {
		return null;
	}

	return (
		<div className="controls-container">
			{additionalMessageControl}
			{actionControl}
			{clearControl}
		</div>
	);
}

BannerMessageControls.propTypes = {
	additionalMessageOpen: PropTypes.bool.isRequired,
	onAdditionalMessageToggle: PropTypes.func.isRequired,
	additionalMessageLabel: PropTypes.string,
	actionButtonLabel: PropTypes.string,
	actionButtonOnClick: PropTypes.func,
	actionButtonOnClickMeta: PropTypes.any,
	clearButtonOnClick: PropTypes.func,
	clearButtonOnClickMeta: PropTypes.any,
};

BannerMessageControls.defaultProps = {
	additionalMessageLabel: null,
	actionButtonLabel: null,
	actionButtonOnClick: null,
	actionButtonOnClickMeta: null,
	clearButtonOnClick: null,
	clearButtonOnClickMeta: null,
};

export default memo(BannerMessageControls);
