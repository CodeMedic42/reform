// @ts-nocheck
import BannerMessage from '.';

export default {
	title: 'Messaging/Banner Message',
	component: BannerMessage,
};

export { default as properties } from './stories/preview';
