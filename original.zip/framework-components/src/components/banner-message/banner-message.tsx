// @ts-nocheck
import React, { memo, useState, useCallback } from 'react';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';
import { faCircleExclamation } from '@audacious/icons/regular/faCircleExclamation';
import { faCircleInfo } from '@audacious/icons/regular/faCircleInfo';
import { faCircleCheck } from '@audacious/icons/regular/faCircleCheck';
import { faTriangleExclamation } from '@audacious/icons/regular/faTriangleExclamation';
import Text from '../typography/text';
import Icon from '../icon';
import PropTypes from '../../common/prop-types';
import {
	schemeColorPropType,
	getSchemeColorClasses,
} from '../../common/color-list';
import BannerMessageControls from './banner-message-controls';

function BannerMessage(props) {
	const {
		id,
		className,
		message,
		color,
		center,
		showIcon,
		additionalMessageLabel,
		additionalMessageText,
		actionButtonLabel,
		actionButtonOnClick,
		actionButtonOnClickMeta,
		clearButtonOnClick,
		clearButtonOnClickMeta,
		...rest
	} = props;

	const [additionalMessageOpen, setShowAdditionalMessage] = useState(false);

	const handleAdditionalMessageToggle = useCallback(() => {
		setShowAdditionalMessage(!additionalMessageOpen);
	}, [additionalMessageOpen]);

	const colorClasses = getSchemeColorClasses({
		colorRequired: false,
		color,
		style: 'lite',
	});

	const additionalMessageContent =
		!isNil(additionalMessageText) && additionalMessageOpen ? (
			<div className="additional-content">
				<Text
					className="banner-message-additional-content-body"
					size="xl"
				>
					{additionalMessageText}
				</Text>
			</div>
		) : null;

	let icon = null;

	if (showIcon) {
		if (color === 'success') {
			icon = faCircleCheck;
		} else if (color === 'warn') {
			icon = faTriangleExclamation;
		} else if (color === 'danger') {
			icon = faCircleExclamation;
		} else {
			icon = faCircleInfo;
		}
	}

	return (
		<div
			{...rest}
			id={id}
			className={classnames(
				'ai-banner-message',
				className,
				colorClasses,
				{
					center,
					'show-icon': !isNil(icon),
				},
			)}
		>
			<div className="constraint-container">
				{!isNil(icon) ? (
					<Icon
						className="banner-message-icon"
						icon={icon}
						color={color}
					/>
				) : null}
				<div className="content-container">
					<div className="main-content">
						<div className="flexing-container">
							<div className="text-container">
								{isString(message) ? (
									<Text size="md">{message}</Text>
								) : (
									message
								)}
							</div>
							<BannerMessageControls
								additionalMessageLabel={additionalMessageLabel}
								actionButtonLabel={actionButtonLabel}
								actionButtonOnClick={actionButtonOnClick}
								actionButtonOnClickMeta={
									actionButtonOnClickMeta
								}
								clearButtonOnClick={clearButtonOnClick}
								clearButtonOnClickMeta={clearButtonOnClickMeta}
								additionalMessageOpen={additionalMessageOpen}
								onAdditionalMessageToggle={
									handleAdditionalMessageToggle
								}
							/>
						</div>
					</div>
					{additionalMessageContent}
				</div>
			</div>
		</div>
	);
}

BannerMessage.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	message: PropTypes.node,
	color: schemeColorPropType,
	center: PropTypes.bool,
	showIcon: PropTypes.bool,
	additionalMessageLabel: PropTypes.string,
	additionalMessageText: PropTypes.string,
	actionButtonLabel: PropTypes.string,
	actionButtonOnClick: PropTypes.func,
	actionButtonOnClickMeta: PropTypes.any,
	clearButtonOnClick: PropTypes.func,
	clearButtonOnClickMeta: PropTypes.any,
};

BannerMessage.defaultProps = {
	id: null,
	className: null,
	color: null,
	message: null,
	center: false,
	showIcon: false,
	additionalMessageLabel: null,
	additionalMessageText: null,
	actionButtonLabel: null,
	actionButtonOnClick: null,
	actionButtonOnClickMeta: null,
	clearButtonOnClick: null,
	clearButtonOnClickMeta: null,
};

export default memo(BannerMessage);
