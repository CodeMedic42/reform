// @ts-nocheck
import BannerMessage from './banner-message';

export default BannerMessage;
