// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
// import MaskedInput from 'react-text-mask/dist/reactTextMask.js';
import MaskedInput from '../text-mask';

import BaseCursorInput, {
	propTypes as baseCursorInputPropTypes,
	defaultProps as baseCursorInputDefaultProps,
} from './base-cursor-input';
import InputBase from './input-base';

class BaseMaskInput extends React.PureComponent {
	constructor(props) {
		super(props);

		this.getInputElement = this.getInputElement.bind(this);
		this.focus = this.focus.bind(this);

		this.inputRef = React.createRef();
	}

	componentDidMount() {
		const { focusOnMount } = this.props;

		if (focusOnMount && this.inputRef && this.inputRef.current) {
			this.focus();
		}
	}

	getInputElement() {
		return this.inputRef.current.inputElement;
	}

	focus() {
		const { disabled } = this.props;

		if (disabled) {
			return;
		}

		this.getInputElement().focus();
	}

	render() {
		const {
			id,
			value,
			disabled,
			onChange,
			onClear,
			size,
			rightIcon,
			placeholder,
			title,
			name,
			onFocus,
			onBlur,
			onKeyPress,
			onKeyDown,
			onKeyUp,
			minLength,
			maxLength,
			required,
			autoComplete,
			'aria-label': ariaLabel,
			showFocused,
			leftIcon,
			pattern,
			mask,
			showMask,
			guide,
			keepCharPositions,
			'aria-labelledby': labelledBy,
			'aria-describedby': describedBy,
			type,
		} = this.props;

		return (
			<BaseCursorInput
				id={id}
				value={value}
				valueType="string"
				disabled={disabled}
				onChange={onChange}
				onClear={onClear}
				size={size}
				leftIcon={leftIcon}
				rightIcon={rightIcon}
			>
				{({ value: baseValue, onChange: baseOnChange }) => (
					<InputBase
						ref={this.inputRef}
						Component={MaskedInput}
						id={id}
						value={baseValue}
						onChange={baseOnChange}
						type={type}
						className={classnames({
							focus: showFocused,
							'has-value': !isNil(baseValue),
						})}
						placeholder={placeholder}
						title={title}
						disabled={disabled}
						name={name}
						onFocus={onFocus}
						onBlur={onBlur}
						onKeyPress={onKeyPress}
						onKeyDown={onKeyDown}
						onKeyUp={onKeyUp}
						minLength={minLength}
						maxLength={maxLength}
						required={required}
						pattern={pattern}
						autoComplete={autoComplete}
						aria-label={ariaLabel}
						aria-labelledby={labelledBy}
						aria-describedby={describedBy}
						mask={mask}
						showMask={showMask}
						guide={guide}
						keepCharPositions={keepCharPositions}
					/>
				)}
			</BaseCursorInput>
		);
	}
}

BaseMaskInput.propTypes = {
	...baseCursorInputPropTypes,
	placeholder: PropTypes.string,
	minLength: PropTypes.number,
	maxLength: PropTypes.number,
	required: PropTypes.bool,
	pattern: PropTypes.instanceOf(RegExp),
	title: PropTypes.string,
	'aria-labelledby': PropTypes.string,
	'aria-describedby': PropTypes.string,
	'aria-label': PropTypes.string,
	name: PropTypes.string,
	focusOnMount: PropTypes.bool,
	onFocus: PropTypes.func,
	onBlur: PropTypes.func,
	onKeyPress: PropTypes.func,
	onKeyDown: PropTypes.func,
	onKeyUp: PropTypes.func,
	autoComplete: PropTypes.oneOf(['on', 'off']),
	showFocused: PropTypes.bool,
	messages: PropTypes.shape({
		general: PropTypes.arrayOf(PropTypes.string),
		invalid: PropTypes.arrayOf(PropTypes.string),
	}),
	guide: PropTypes.bool,
	keepCharPositions: PropTypes.bool,
	mask: PropTypes.oneOfType([
		PropTypes.func,
		PropTypes.arrayOf(
			PropTypes.oneOfType([
				PropTypes.string,
				PropTypes.instanceOf(RegExp),
			]),
		),
	]).isRequired,
	showMask: PropTypes.bool,
};

BaseMaskInput.defaultProps = {
	...baseCursorInputDefaultProps,
	required: null,
	placeholder: null,
	title: null,
	minLength: null,
	maxLength: null,
	pattern: null,
	'aria-labelledby': null,
	'aria-describedby': null,
	'aria-label': null,
	name: null,
	focusOnMount: false,
	onFocus: null,
	onBlur: null,
	onKeyPress: null,
	onKeyDown: null,
	onKeyUp: null,
	autoComplete: 'off',
	showFocused: false,
	messages: null,
	guide: false,
	keepCharPositions: false,
	showMask: null,
};

export default BaseMaskInput;
