// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import isNil from 'lodash-es/isNil';
import toString from 'lodash-es/toString';

function getValue(value) {
	if (isNil(value)) {
		return '';
	}

	return toString(value);
}

class InputBaseForwarded extends React.PureComponent {
	constructor(props) {
		super(props);

		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(event) {
		const {
			target: { value },
		} = event;

		const { onChange } = this.props;

		onChange(value.length > 0 ? value : null);
	}

	render() {
		const { onChange, value, forwardedRef, Component, ...rest } =
			this.props;

		return (
			<Component
				ref={forwardedRef}
				value={getValue(value)}
				onChange={this.handleChange}
				{...rest}
			/>
		);
	}
}

InputBaseForwarded.propTypes = {
	onChange: PropTypes.func.isRequired,
	value: PropTypes.string,
	// eslint-disable-next-line react/forbid-prop-types
	forwardedRef: PropTypes.object,
	// eslint-disable-next-line react/forbid-prop-types
	Component: PropTypes.any.isRequired,
};

InputBaseForwarded.defaultProps = {
	forwardedRef: null,
	value: null,
};

const InputBase = React.forwardRef((props, ref) => (
	<InputBaseForwarded {...props} forwardedRef={ref} />
));

InputBase.displayName = 'InputBase';

export default InputBase;
