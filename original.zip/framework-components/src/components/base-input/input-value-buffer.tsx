// @ts-nocheck
import { PureComponent } from 'react';
import noop from 'lodash-es/noop';
import PropTypes from 'prop-types';

class InputValueBuffer extends PureComponent {
    constructor(props) {
        super(props);

        this.handleChange = this.handleChange.bind(this);

        const { value } = props;

        this.state = {
            value,
        };
    }

    static getDerivedStateFromProps(nextProps, currentState) {
        const { value: nextValue } = nextProps;

        if (nextValue === currentState.value) {
            return null;
        }

        return {
            value: nextValue,
        };
    }

    handleChange(newValue) {
        const { onChange } = this.props;

        const { value: currentValue } = this.state;

        if (currentValue === newValue) {
            return;
        }

        this.setState({
            value: newValue
        });

        onChange(newValue);
    }

    render() {
        const { children } = this.props;

        const { value } = this.state;

        return children({
            value,
            onChange: this.handleChange,
        });
    }
}

InputValueBuffer.propTypes = {
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    onChange: PropTypes.func,
    children: PropTypes.func.isRequired,
};

InputValueBuffer.defaultProps = {
    value: null,
    onChange: noop,
};

export default InputValueBuffer;
