// @ts-nocheck
import ButtonGroup from '.';

export default {
	title: 'Layout/Button Group',
	component: ButtonGroup,
	// argTypes: { onClick: { action: 'clicked' } },
};

export { default as basic } from './stories/basic';
