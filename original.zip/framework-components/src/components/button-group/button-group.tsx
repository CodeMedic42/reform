// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';

class ButtonGroup extends PureComponent {
	render() {
		const { className, children } = this.props;

		let { orientation } = this.props;

		orientation = !isNil(orientation) ? orientation : 'horizontal';

		return (
			<div
				className={classnames(
					'ai-button-group',
					orientation,
					className,
				)}
			>
				{children}
			</div>
		);
	}
}

ButtonGroup.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	orientation: PropTypes.oneOf(['horizontal', 'vertical']),
};

ButtonGroup.defaultProps = {
	className: null,
	children: null,
	orientation: 'horizontal',
};

export default ButtonGroup;
