# Button

Styles a button element using the AI stylesheet.

## Properties

### Required

| Property | Type   | Description                 |
| -------- | ------ | --------------------------- |
| id       | String | The id of the main element. |

### Optional

| Property         | Type                                                           | Default  | Description                                                                            |
| ---------------- | -------------------------------------------------------------- | -------- | -------------------------------------------------------------------------------------- |
| className        | String                                                         | null     | Any additional class names provide here will be added to the button                    |
| type             | One of 'button', 'submit'                                      | 'button' | The type of button.                                                                    |
| disabled         | Boolean                                                        | false    | This prop will disable the button.                                                     |
| aria-label       | String                                                         | null     | Sets the aria-label on the button. It is recommended to provide this value.            |
| title            | String                                                         | null     | Set the title on the button.                                                           |
| aria-describedby | String                                                         | null     | If there is any extra text describing the button this can be used for a screen reader. |
| color            | One of 'basic', 'primary', 'info', 'success', 'warn', 'danger' | primary  | This will set the color palette for the button using css.                              |
| variant          | One of 'fill', 'outline', 'opaque'                             | fill     | This will set the style of the component.                                              |
| onClick          | Function                                                       | null     | a callback to be used to handle click events.                                          |
| children         | Node or Array of Nodes                                         | null     | Sets the contents of the button.                                                       |
