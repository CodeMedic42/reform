// @ts-nocheck
import Button from '.';

export default {
	title: 'Controls/Button',
	component: Button,
};

export { default as preview } from './stories/preview';
export { default as colors } from './stories/colors';
export { default as darkColors } from './stories/dark-colors';
export { default as colorsInherit } from './stories/colors-inherit';
export { default as sizes } from './stories/sizes';
export { default as misc } from './stories/misc';
