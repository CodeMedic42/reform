// @ts-nocheck
import React, { PureComponent } from 'react';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import {
	schemeColorPropType,
	getSchemeColorClasses,
} from '../../common/color-list';
import Icon from '../icon';
import PropTypes from '../../common/prop-types';

class Button extends PureComponent {
	constructor(props) {
		super(props);

		this.buttonRef = React.createRef();

		this.focus = this.focus.bind(this);
		this.handleClick = this.handleClick.bind(this);
	}

	componentDidMount() {
		const { focusOnMount } = this.props;

		if (focusOnMount) {
			this.focus();
		}
	}

	handleClick(event) {
		const { onClick, onClickMeta } = this.props;

		if (isNil(onClick)) {
			return;
		}

		onClick({
			event,
			meta: onClickMeta,
		});
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	getRootNode() {
		return this.buttonRef.current;
	}

	focus() {
		const { current } = this.buttonRef;

		if (isNil(current)) {
			// eslint-disable-next-line no-console
			console.warn('Attempting to focus on an unmounted component');

			return;
		}

		current.focus();
	}

	renderLeftIcon() {
		const { leftIcon } = this.props;

		if (isNil(leftIcon)) {
			return null;
		}

		return <Icon icon={leftIcon} />;
	}

	renderRightIcon() {
		const { rightIcon } = this.props;

		if (isNil(rightIcon)) {
			return null;
		}

		return <Icon icon={rightIcon} />;
	}

	render() {
		const {
			id,
			className,
			variant,
			color,
			children,
			hidden,
			rounded,
			size,
			type,
			noPadding,
			dockSide,
			asAnchor,
			href,
			target,
			useDark,
			leftIcon,
			rightIcon,
			onClick,
			onClickMeta,
			focusOnMount,
			...rest
		} = this.props;

		const sizeClass = !isNil(size) ? `size-${size}` : 'size-md';
		const dockClass = !isNil(dockSide) ? `dock-${dockSide}` : null;

		const colorClasses = getSchemeColorClasses({
			colorRequired: false,
			color,
			style: !isNil(variant) ? variant : 'fill',
		});

		const content = (
			<>
				{this.renderLeftIcon()}
				<span>{children}</span>
				{this.renderRightIcon()}
			</>
		);

		const props = {
			ref: this.buttonRef,
			id,
			className: classnames(
				'ai-btn',
				'no-select',
				'sch-control',
				sizeClass,
				colorClasses,
				dockClass,
				className,
				{
					hidden,
					'border-radius-lg': rounded,
					'border-radius-sm': !rounded,
					dark: useDark,
					'no-padding': noPadding,
				},
			),
			onClick: this.handleClick,
			...rest,
		};

		if (asAnchor) {
			return (
				<a {...props} href={href} target={target}>
					{content}
				</a>
			);
		}

		const typeProp = !isNil(type) ? type : 'button';

		return (
			// eslint-disable-next-line react/button-has-type
			<button {...props} type={typeProp}>
				{content}
			</button>
		);
	}
}

Button.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	type: PropTypes.string,
	color: schemeColorPropType,
	variant: PropTypes.oneOf(['none', 'fill', 'outline', 'opaque']),
	useDark: PropTypes.bool,
	size: PropTypes.oneOf(['xl', 'lg', 'md', 'sm', 'xs', '2xs']),
	hidden: PropTypes.bool,
	onClick: PropTypes.func,
	onClickMeta: PropTypes.any,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	rounded: PropTypes.bool,
	leftIcon: PropTypes.icon,
	rightIcon: PropTypes.icon,
	noPadding: PropTypes.bool,
	dockSide: PropTypes.oneOf(['left', 'right', 'top', 'bottom']),
	asAnchor: PropTypes.bool,
	href: PropTypes.string,
	target: PropTypes.string,
	focusOnMount: PropTypes.bool,
};

Button.defaultProps = {
	id: null,
	type: 'button',
	className: null,
	variant: 'fill',
	color: null,
	hidden: false,
	onClick: null,
	onClickMeta: null,
	children: null,
	rounded: false,
	size: 'md',
	leftIcon: null,
	rightIcon: null,
	noPadding: false,
	dockSide: null,
	asAnchor: false,
	href: null,
	target: null,
	useDark: false,
	focusOnMount: false,
};

export default Button;
