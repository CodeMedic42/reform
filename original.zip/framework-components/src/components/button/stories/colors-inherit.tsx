// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import { faCircleXmark } from '@audacious/icons/solid/faCircleXmark';
import Scope from '../../../../.storybook/components/scope';
import Button from '..';
import { Row, Column } from '../../grid';

function renderColumn(color, useIcon, disabled, variant) {
	return (
		<Column width="content" key={variant}>
			<Button
				color={color}
				variant={variant}
				leftIcon={useIcon ? faCircleXmark : null}
				disabled={disabled}
			>
				{variant}
			</Button>
		</Column>
	);
}

function renderRow(color, useIcon, disabled) {
	return (
		<Row gutter>
			{map(['none', 'fill', 'outline', 'opaque'], (variant) =>
				renderColumn(color, useIcon, disabled, variant),
			)}
		</Row>
	);
}

function example() {
	return (
		<>
			<Scope title="Inherit Primary">
				<div className="page-content sch-primary">
					{renderRow(null, false, false)}
					{renderRow(null, true, false)}
					{renderRow(null, false, true)}
					{renderRow(null, true, true)}
				</div>
			</Scope>
			<Scope title="Override Primary => Warn">
				<div className="page-content sch-primary">
					{renderRow('warn', false, false)}
					{renderRow('warn', true, false)}
					{renderRow('warn', false, true)}
					{renderRow('warn', true, true)}
				</div>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Colors Inherit',
	parameters: {
		controls: { disable: true },
	},
};

export default example;
