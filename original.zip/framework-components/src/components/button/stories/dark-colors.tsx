// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import { faCircleXmark } from '@audacious/icons/solid/faCircleXmark';
import Scope from '../../../../.storybook/components/scope';
import Button from '..';
import { Row, Column } from '../../grid';

function renderColumn(color, useIcon, disabled, variant) {
	return (
		<Column width="content" key={variant}>
			<Button
				color={color}
				variant={variant}
				leftIcon={useIcon ? faCircleXmark : null}
				disabled={disabled}
				useDark
			>
				{variant}
			</Button>
		</Column>
	);
}

function renderRow(color, useIcon, disabled) {
	return (
		<Row gutter>
			{map(['none', 'fill', 'outline', 'opaque'], (variant) =>
				renderColumn(color, useIcon, disabled, variant),
			)}
		</Row>
	);
}

function renderColorScope(color) {
	return (
		<Scope
			key={color || 'Default Color'}
			title={color || 'Default Color'}
			dark
		>
			<div className="page-content">
				{renderRow(color, false, false)}
				{renderRow(color, true, false)}
				{renderRow(color, false, true)}
				{renderRow(color, true, true)}
			</div>
		</Scope>
	);
}

function example() {
	return (
		<>
			{map(
				[
					null,
					'primary',
					'secondary',
					'info',
					'success',
					'warn',
					'danger',
				],
				renderColorScope,
			)}
		</>
	);
}

example.story = {
	name: 'Dark Colors',
	parameters: {
		controls: { disable: true },
	},
};

export default example;
