// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import Button from '..';

function example() {
	return (
		<>
			<Scope title="Rounded">
				<Button rounded>Rounded</Button>
			</Scope>
			<Scope title="Rotate">
				<Button id="simple" dockSide="top">
					Button
				</Button>
				<Button id="simple" dockSide="bottom">
					Button
				</Button>
				<Button id="simple" dockSide="left">
					Button
				</Button>
				<Button id="simple" dockSide="right">
					Button
				</Button>
			</Scope>
			<Scope title="As Anchor">
				<Button asAnchor href="www.apple.com">
					Rounded
				</Button>
			</Scope>
			<Scope title="Hidden">
				<Button hidden>Hidden</Button>
			</Scope>
			<Scope title="Disabled" disabled>
				<Button disabled>Hidden</Button>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Miscellaneous',
	parameters: {
		controls: { disable: true },
	},
};

export default example;
