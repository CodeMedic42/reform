// @ts-nocheck
import React from 'react';
import { faUser } from '@audacious/icons/solid/faUser';
import { schemeColorOrder } from '../../../common/color-list';
import Scope from '../../../../.storybook/components/scope';
import Button from '..';

function example(props) {
	return (
		<Scope fillViewport>
			<Button {...props} />
		</Scope>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		type: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		children: {
			control: 'text',
		},
		disabled: {
			control: 'boolean',
		},
		hidden: {
			control: 'boolean',
		},
		onClick: { table: { disable: true } },
		asAnchor: {
			control: 'boolean',
			description:
				'Will render with an anchor element rather than a button.',
		},
		href: {
			control: 'text',
			if: { arg: 'asAnchor', truthy: true },
			description:
				'The href for the anchor. Will not be used if asAnchor is false.',
		},
		target: {
			control: 'text',
			if: { arg: 'asAnchor', truthy: true },
			description:
				'The target for the anchor. Will not be used if asAnchor is false.',
		},
		dockSide: {
			options: ['left', 'right', 'top', 'bottom'],
			control: { type: 'select' },
			description:
				'Will render the button as a docked element. Dev must position the button accordingly.',
		},
		size: {
			options: ['xl', 'lg', 'md', 'sm', 'xs', '2xs'],
			control: { type: 'select' },
		},
		color: {
			options: schemeColorOrder,
			control: { type: 'select' },
			description:
				'The scheme colors. pallette colors are not supported. If not set with inherit the scheme of its parent elements.',
		},
		variant: {
			options: ['none', 'fill', 'outline', 'opaque'],
			control: { type: 'select' },
			description: 'The style to render the button as.',
		},
		useDark: {
			control: 'boolean',
			description: 'Use the dark variant of the selected color scheme.',
		},
		rounded: {
			control: 'boolean',
			description: 'Will round out the borders to the max.',
		},
		onClickMeta: { table: { disable: true } },
		leftIcon: {
			options: { Unset: undefined, FaUser: faUser },
			control: 'select',
			description:
				'Will render the given icon to the left of the provided children property.',
		},
		rightIcon: {
			options: { Unset: undefined, FaUser: faUser },
			control: 'select',
			description:
				'Will render the given icon to the right of the provided children property.',
		},
		noPadding: { table: { disable: true } },
	},
	args: {
		children: 'Button',
		disabled: false,
		hidden: false,
		asAnchor: false,
		href: undefined,
		target: undefined,
		useDark: false,
		rounded: false,
	}
};

export default example;
