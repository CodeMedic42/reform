// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import { faCircleXmark } from '@audacious/icons/solid/faCircleXmark';
import Scope from '../../../../.storybook/components/scope';
import Button from '..';
import { Row, Column } from '../../grid';

function renderSizeScope(size) {
	return (
		<Scope key={size} title={size}>
			<Row gutter>
				<Column width="content">
					<Button variant="fill" size={size} color="primary">
						<span>Fill</span>
					</Button>
				</Column>
				<Column width="content">
					<Button size={size} variant="outline" color="primary">
						<span>Outline</span>
					</Button>
				</Column>
				<Column width="content">
					<Button size={size} variant="opaque" color="primary">
						<span>Opaque</span>
					</Button>
				</Column>
			</Row>
			<Row gutter>
				<Column width="content">
					<Button
						variant="fill"
						size={size}
						color="primary"
						leftIcon={faCircleXmark}
					>
						<span>Fill</span>
					</Button>
				</Column>
				<Column width="content">
					<Button
						size={size}
						variant="outline"
						color="primary"
						leftIcon={faCircleXmark}
					>
						<span>Outline</span>
					</Button>
				</Column>
				<Column width="content">
					<Button
						size={size}
						variant="opaque"
						color="primary"
						leftIcon={faCircleXmark}
					>
						<span>Opaque</span>
					</Button>
				</Column>
			</Row>
			<Row gutter>
				<Column width="content">
					<Button
						variant="fill"
						size={size}
						color="primary"
						rightIcon={faCircleXmark}
					>
						<span>Fill</span>
					</Button>
				</Column>
				<Column width="content">
					<Button
						size={size}
						variant="outline"
						color="primary"
						rightIcon={faCircleXmark}
					>
						<span>Outline</span>
					</Button>
				</Column>
				<Column width="content">
					<Button
						size={size}
						variant="opaque"
						color="primary"
						rightIcon={faCircleXmark}
					>
						<span>Opaque</span>
					</Button>
				</Column>
			</Row>
		</Scope>
	);
}

function example() {
	return (
		<>
			{map(['2xs', 'xs', 'sm', 'md', 'lg', 'xl'], (size) =>
				renderSizeScope(size),
			)}
		</>
	);
}

example.story = {
	name: 'Sizes',
	parameters: {
		controls: { disable: true },
	},
};

export default example;
