// @ts-nocheck
import Card from '.';

export default {
	title: 'Layout/Card',
	component: Card,
};

export { default as sizes } from './stories/sizes';
export { default as interactive } from './stories/interactive';
export { default as palletteColors } from './stories/pallette-colors';
export { default as schemeColors } from './stories/scheme-colors';
export { default as messages } from './stories/messages';
