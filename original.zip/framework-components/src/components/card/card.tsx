/* eslint-disable jsx-a11y/no-noninteractive-tabindex */
/* eslint-disable jsx-a11y/no-static-element-interactions */
// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import {
	colorPropType,
	shadePropType,
	getColorInfo,
} from '../../common/color-list';
import InputMessages from '../input-messages/input-messages';

class Card extends PureComponent {
	constructor(props) {
		super(props);

		this.handleKeyDown = this.handleKeyDown.bind(this);
		this.handleClick = this.handleClick.bind(this);
	}

	handleKeyDown(event) {
		// call onClick on enter key down
		if (event.which === 13) {
			this.handleClick(event);
		}
	}

	handleClick(event) {
		const { onClick, onClickMeta } = this.props;

		if (isNil(onClick)) {
			return;
		}

		onClick({
			event,
			meta: onClickMeta,
		});
	}

	render() {
		const {
			id,
			className,
			children,
			color,
			shade,
			enableBorder,
			size,
			onClick,
			messages,
			'aria-describedBy': ariaDescribedBy,
		} = this.props;

		const { colorClasses } = getColorInfo({
			color,
			shade,
			style: 'lite',
			enableBorder,
			enableBackground: true,
		});

		const finalSize = size === null ? 'md' : size;

		let messagesElement = null;
		let describedBy = ariaDescribedBy;

		if (!isNil(messages)) {
			const descriptionId = `${id}-description`;

			if (!isNil(ariaDescribedBy) && ariaDescribedBy.length > 0) {
				describedBy = `${ariaDescribedBy} ${descriptionId}`;
			} else if (messages) {
				describedBy = descriptionId;
			}

			messagesElement = (
				<InputMessages id={descriptionId} messages={messages} />
			);
		}

		return (
			<>
				<div
					id={id}
					className={classnames(
						'ai-card',
						colorClasses,
						`size-${finalSize}`,
						className,
						{
							'sch-control': onClick !== null,
						},
					)}
					tabIndex={onClick ? 0 : -1}
					role={onClick ? 'button' : null}
					onKeyDown={onClick ? this.handleKeyDown : null}
					onClick={this.handleClick}
					aria-describedby={describedBy}
				>
					{children}
				</div>
				{messagesElement}
			</>
		);
	}
}

Card.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	color: colorPropType,
	shade: shadePropType,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	enableBorder: PropTypes.bool,
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
	messages: PropTypes.shape({
		general: PropTypes.arrayOf(PropTypes.string),
		success: PropTypes.arrayOf(PropTypes.string),
		invalid: PropTypes.arrayOf(PropTypes.string),
	}),
	'aria-describedBy': PropTypes.string,
};

Card.defaultProps = {
	id: null,
	className: null,
	color: null,
	shade: 'lighter',
	size: 'md',
	children: null,
	onClick: null,
	onClickMeta: null,
	enableBorder: false,
	messages: null,
	'aria-describedBy': null,
};

export default Card;
