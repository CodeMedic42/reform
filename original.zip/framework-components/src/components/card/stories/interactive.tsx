/* eslint-disable no-alert */
// @ts-nocheck
import React from 'react';
import Card from '..';
import Button from '../../button';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [expanded, setExpanded] = React.useState(false);

	const toggleExpanded = () => {
		setExpanded(!expanded);
	};

	return (
		<>
			<Scope title="Interactive Cards">
				<Card onClick={() => alert('clicked')}>Interactive Card</Card>
			</Scope>
			<Scope title="Expandable Card">
				<Card onClick={expanded ? null : toggleExpanded}>
					<div
						style={{
							height: expanded ? '250px' : '40px',
							width: expanded ? '300px' : 'auto',
							position: 'relative',
						}}
					>
						{expanded ? (
							<>
								<p>
									Expanded. This card is not clickable when
									expanded. Click Done to collapse the card.
								</p>
								<div
									style={{
										position: 'absolute',
										bottom: 0,
									}}
								>
									<Button
										id="simple"
										color="secondary"
										variant="fill"
										onClick={toggleExpanded}
									>
										Done
									</Button>
								</div>
							</>
						) : (
							'Collapsed. Click to expand.'
						)}
					</div>
				</Card>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Interactive',
};

export default example;
