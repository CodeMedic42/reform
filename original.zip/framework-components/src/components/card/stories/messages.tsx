// @ts-nocheck
import React, { useState } from 'react';
import isEmpty from 'lodash-es/isEmpty';
import Card from '..';
import Scope from '../../../../.storybook/components/scope';
import MessageControls from '../../../common/storybook/message-controls';

function example() {
	const [generalMessages, setGeneralMessages] = useState([]);
	const [successMessages, setSuccessMessages] = useState([]);
	const [invalidMessages, setInvalidMessages] = useState([]);

	const renderControls = () => (
		<MessageControls
			onGeneralMessageChange={setGeneralMessages}
			onSuccessMessageChange={setSuccessMessages}
			onInvalidMessageChange={setInvalidMessages}
		/>
	);

	let messages = null;

	if (
		!isEmpty(generalMessages) ||
		!isEmpty(successMessages) ||
		!isEmpty(invalidMessages)
	) {
		messages = {
			general: generalMessages,
			success: successMessages,
			invalid: invalidMessages,
		};
	}

	return (
		<Scope title="Messages" controls={renderControls()}>
			<Card id="example" messages={messages}>
				Text
			</Card>
		</Scope>
	);
}

example.story = {
	name: 'Messages',
};

export default example;
