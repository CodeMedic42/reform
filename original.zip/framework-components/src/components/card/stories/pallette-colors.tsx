/* eslint-disable no-alert */
// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Card from '..';
import { Row, Column } from '../../grid';
import Scope from '../../../../.storybook/components/scope';
import { paletteColorOrder, paletteShades } from '../../../common/color-list';

function onClick() {
	alert('Clicked');
}

function renderRow(color, interactive, enableBorder) {
	return (
		<Row gutter="8">
			{map(paletteShades, (shade) => (
				<Column key={shade} width="content">
					<Card
						color={color}
						shade={shade}
						enableBorder={enableBorder}
						onClick={interactive ? onClick : null}
					>
						{interactive ? 'Interactive' : shade}
					</Card>
				</Column>
			))}
		</Row>
	);
}

function example() {
	return (
		<>
			{map(paletteColorOrder, (color) => (
				<Scope key={color} title={color}>
					{renderRow(color, false, false)}
					{renderRow(color, false, true)}
					{renderRow(color, true, false)}
					{renderRow(color, true, true)}
				</Scope>
			))}
		</>
	);
}

example.story = {
	name: 'Pallette Colors',
};

export default example;
