/* eslint-disable no-alert */
// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Card from '..';
import { Row, Column } from '../../grid';
import Scope from '../../../../.storybook/components/scope';
import { schemeColorOrder } from '../../../common/color-list';

function onClick() {
	alert('Clicked');
}

function renderColumn(color, interactive, enableBorder) {
	return (
		<Column width="content">
			<Card
				color={color}
				enableBorder={enableBorder}
				onClick={interactive ? onClick : null}
			>
				{interactive ? 'Interactive' : 'Simple'}
			</Card>
		</Column>
	);
}

function renderRow(color, interactive) {
	return (
		<Row gutter="8">
			{renderColumn(color, interactive, false)}
			{renderColumn(color, interactive, true)}
		</Row>
	);
}

function example() {
	return (
		<>
			{map(schemeColorOrder, (color) => (
				<Scope key={color} title={color}>
					{renderRow(color, false)}
					{renderRow(color, true)}
				</Scope>
			))}
		</>
	);
}

example.story = {
	name: 'Scheme Colors',
};

export default example;
