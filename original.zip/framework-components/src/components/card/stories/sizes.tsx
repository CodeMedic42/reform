// @ts-nocheck
import React from 'react';
import Card from '..';
import { Row, Column } from '../../grid';
import Scope from '../../../../.storybook/components/scope';

function cardSize(size) {
	return (
		<Column
			width="content"
			style={{
				width: '180px',
			}}
		>
			<Card size={size}>
				<p
					style={{
						width: '50px',
						height: '50px',
						lineHeight: '50px',
						textAlign: 'center',
						margin: 0,
						background: '#f0f0f0',
					}}
				>
					{size}
				</p>
			</Card>
		</Column>
	);
}

function example() {
	return (
		<Scope title="Sizes (Responsive Padding)">
			<Row gutter>
				{cardSize('xs')}
				{cardSize('sm')}
				{cardSize('md')}
				{cardSize('lg')}
				{cardSize('xl')}
			</Row>
		</Scope>
	);
}

example.story = {
	name: 'Sizes',
};

export default example;
