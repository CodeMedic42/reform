# CCD View

This is a modal dialog used to render clinical documents in PULSE and PROMPT. It takes the document as an HTML string, converts it to React components and adds event listeners. It also has print functionality and uses the PDFViewer to display embedded pdfs.
