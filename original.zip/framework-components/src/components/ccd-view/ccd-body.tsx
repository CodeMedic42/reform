// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import isNil from 'lodash-es/isNil';
import isEmpty from 'lodash-es/isEmpty';
import { faPrint } from '@audacious/icons/solid/faPrint';
import IconButton from '../icon-button';
import TableMessage from '../table-message';
import Button from '../button';
import printDocument from './print-document';
import parseHTML from './parse-ccd-html';

function renderErrorBody(headerText, bodyText, onClose) {
	return (
		<div className="document-error-body">
			<TableMessage
				header={headerText}
				body={bodyText}
				footer={
					<Button
						color="secondary"
						size="sm"
						variant="fill"
						onClick={onClose}
					>
						Close
					</Button>
				}
			/>
		</div>
	);
}

class CCDBody extends React.PureComponent {
	constructor(props) {
		super(props);

		this.handlePrint = this.handlePrint.bind(this);
		this.renderFooter = this.renderFooter.bind(this);
	}

	handlePrint() {
		const { documentMeta } = this.props;

		printDocument(documentMeta?.name);
	}

	renderFooter() {
		const { documentMeta, documentHtml, userName } = this.props;

		if (isNil(documentMeta) || isNil(documentHtml)) {
			return null;
		}

		return (
			<div className="doc-footer">
				<div className="doc-footer-item">
					<div className="doc-footer-item-title">Document Title:</div>
					<div className="doc-footer-item-value">
						{documentMeta.name}
					</div>
				</div>
				<div className="doc-footer-item">
					<div className="doc-footer-item-title">Source:</div>
					<div className="doc-footer-item-value">
						<div className="doc-footer-value-main">
							{documentMeta.sourceFacility}
						</div>
						<div className="doc-footer-value-sub">
							{documentMeta.sourceDepartment}
						</div>
					</div>
				</div>
				<div className="doc-footer-item">
					<div className="doc-footer-item-title">Service Time:</div>
					<div className="doc-footer-item-value">
						<div className="doc-footer-value-main">
							{documentMeta.serviceStartTime}
						</div>
						<div className="doc-footer-value-sub">
							{documentMeta.serviceStopTime}
						</div>
					</div>
				</div>
				<div className="doc-footer-item">
					<div className="doc-footer-item-title">Author:</div>
					<div className="doc-footer-item-value">
						<div className="doc-footer-value-main">
							{documentMeta.authorName}
						</div>
						<div className="doc-footer-value-sub">
							{documentMeta.authorDetail}
						</div>
					</div>
				</div>
				<div className="doc-footer-item">
					<div className="doc-footer-item-title">
						Author Institution:
					</div>
					<div className="doc-footer-item-value">
						{documentMeta.authorInstitution}
					</div>
				</div>
				<div className="doc-footer-item">
					<div className="doc-footer-item-title">Type:</div>
					<div className="doc-footer-item-value">
						{documentMeta.documentType}
					</div>
				</div>
				<div className="doc-footer-item footer-user-name">
					<div className="doc-footer-item-title">User Name:</div>
					<div className="doc-footer-item-value">{userName}</div>
				</div>
			</div>
		);
	}

	render() {
		const {
			documentHtml,
			documentMeta,
			allowPrint,
			retrievalFailed,
			onClose,
		} = this.props;

		if (retrievalFailed) {
			return renderErrorBody(
				'Something went wrong...',
				'Please try again.',
				onClose,
			);
		}

		if (isNil(documentHtml)) {
			return null;
		}

		let parsedCCD;
		let parseFailed = false;

		try {
			parsedCCD = parseHTML(documentHtml, documentMeta.name, allowPrint);
		} catch (e) {
			parseFailed = true;
		}

		if (parseFailed || isEmpty(parsedCCD)) {
			return renderErrorBody(
				'Invalid document',
				'The document cannot be read',
				onClose,
			);
		}

		return (
			<>
				{allowPrint ? (
					<IconButton
						id="doc-print-button"
						className="document-print-button"
						onClick={this.handlePrint}
						aria-label="Print Document"
						icon={faPrint}
						size="md"
					/>
				) : null}
				<div id="ccd-view-body">
					<div id="ccd-doc-container">{parsedCCD}</div>
					{this.renderFooter()}
				</div>
			</>
		);
	}
}

CCDBody.propTypes = {
	documentHtml: PropTypes.string,
	documentMeta: PropTypes.objectOf(PropTypes.string),
	userName: PropTypes.string,
	allowPrint: PropTypes.bool,
	retrievalFailed: PropTypes.bool,
	onClose: PropTypes.func.isRequired,
};

CCDBody.defaultProps = {
	documentHtml: null,
	documentMeta: null,
	userName: null,
	allowPrint: true,
	retrievalFailed: false,
};

export default CCDBody;
