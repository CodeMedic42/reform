// @ts-nocheck
import CCDView from '.';

export default {
	title: 'Miscellaneous/CCD View',
	component: CCDView,
};

export { default as preview } from './stories/preview';
export { default as pdfDocument } from './stories/pdf-document';
