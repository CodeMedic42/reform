// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import isNil from 'lodash-es/isNil';
import forEach from 'lodash-es/forEach';
import replace from 'lodash-es/replace';
import Dialog from '../dialog';
import Document, { DocumentBody } from '../document';
import CCDBody from './ccd-body';

class CCDView extends React.PureComponent {
	constructor(props) {
		super(props);

		this.attachListeners = this.attachListeners.bind(this);
	}

	componentDidMount() {
		this.attachListeners();
	}

	componentDidUpdate() {
		this.attachListeners();
	}

	attachListeners() {
		const { open, documentHtml } = this.props;

		if (open === false || isNil(documentHtml)) {
			return;
		}

		const linkElements = window.document.querySelectorAll(
			'[enable-disable-links]',
		);
		const collapsibleElements = window.document.querySelectorAll(
			'.section-angle-icon, .section-link',
		);
		const returnToTopElements =
			window.document.querySelectorAll('[data-return-top]');

		const scrollContainer = document.getElementById('ccd-view-modal');

		// TODO: possible memory leak. Depends on how html-react-parser replaces elements.

		// Attach listners to enable and disable links
		forEach(linkElements, (linkElement) => {
			linkElement.addEventListener('click', (event) => {
				const activeLinks =
					document.getElementsByClassName('active-link');

				forEach(activeLinks, (activeLink) => {
					activeLink.classList.remove('active-link');
				});

				event.currentTarget.classList.add('active-link');

				// prevent changing the url and instead scroll the target into view
				event.preventDefault();

				let hrefString = event.target.getAttribute('href');
				if (hrefString.length && hrefString[0] === '#') {
					hrefString = hrefString.slice(1);
					const targetElements =
						document.getElementsByName(hrefString);
					if (targetElements && targetElements.length) {
						targetElements[0].scrollIntoView();
					}
				}
			});
		});

		// Attach listners to collapse and expand data sections
		forEach(collapsibleElements, (collapsibleElement) => {
			collapsibleElement.classList.remove('fa-angle-down');

			collapsibleElement.addEventListener('click', (event) => {
				let sectionTitle =
					event.currentTarget.getAttribute('data-collapsible');
				let angleIcon = event.currentTarget;

				if (!isNil(sectionTitle)) {
					// If this is the title element, get the angle icon
					angleIcon = document.getElementById(`icon${sectionTitle}`);
				} else {
					// If this is the angle icon, get the title from the id
					sectionTitle = replace(angleIcon.id, 'icon', '');
				}

				const section = document.getElementById(sectionTitle);

				if (section.classList.contains('collapse-hide')) {
					section.classList.remove('collapse-hide');
					angleIcon.classList.remove('collapsed-icon');
				} else {
					section.classList.add('collapse-hide');
					angleIcon.classList.add('collapsed-icon');
				}

				// prevent changing the url
				event.preventDefault();
			});
		});

		forEach(returnToTopElements, (element) => {
			element.addEventListener('click', (event) => {
				if (!isNil(scrollContainer)) {
					scrollContainer.scrollTop = 0;
				}

				// prevent changing the url and instead scroll the target into view
				event.preventDefault();
			});
		});
	}

	render() {
		const {
			open,
			documentHtml,
			documentMeta,
			userName,
			allowPrint,
			retrievalFailed,
			onClose,
		} = this.props;

		return (
			<Dialog
				id="ccd-view-modal"
				className="document-view-container"
				open={open}
				variant="modal"
				size="xl"
				isLoading={isNil(documentHtml) && !retrievalFailed}
				onClose={onClose}
				enableCloseBackdrop
				enableCloseButton
			>
				<Document size="xs">
					<DocumentBody>
						<CCDBody
							documentHtml={documentHtml}
							documentMeta={documentMeta}
							userName={userName}
							allowPrint={allowPrint}
							retrievalFailed={retrievalFailed}
							onClose={onClose}
						/>
					</DocumentBody>
				</Document>
			</Dialog>
		);
	}
}

CCDView.propTypes = {
	documentHtml: PropTypes.string,
	documentMeta: PropTypes.objectOf(PropTypes.string),
	userName: PropTypes.string,
	open: PropTypes.bool,
	allowPrint: PropTypes.bool,
	retrievalFailed: PropTypes.bool,
	onClose: PropTypes.func.isRequired,
};

CCDView.defaultProps = {
	documentHtml: null,
	documentMeta: null,
	userName: '',
	open: false,
	retrievalFailed: false,
	allowPrint: true,
};

export default CCDView;
