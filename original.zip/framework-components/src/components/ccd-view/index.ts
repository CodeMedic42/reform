// @ts-nocheck
import CCDView from './ccd-view';

export default CCDView;
