// @ts-nocheck
import React from 'react';
import classnames from 'classnames';
import replace from 'lodash-es/replace';
import parse, { domToReact } from 'html-react-parser';
import isNil from 'lodash-es/isNil';
import reduce from 'lodash-es/reduce';
import { faAngleDown } from '@audacious/icons/solid/faAngleDown';
import PdfViewer from '../pdf-viewer';
import IconButton from '../icon-button';

export default function parseHTML(documentHtml, documentName, allowPrint) {
	if (isNil(documentHtml)) {
		return null;
	}

	// This inscrutable line of code was added because errors where being put on the console due to newline characters in the raw html text.
	// These new line characters were showing up after element markup. An example is "<table>\n".
	// However there is the possibility of newline characters which are not causing problems.
	// This line of code will only select the following text ">\n", which should be any newline character following a ">" character.
	// It will then replace this with just the ">", thus removing the newline character and fixing the error messages.
	const cleaned = replace(documentHtml, />\n/gm, '>');

	// Filter out top-level tags from transformed HTML

	let pdfCount = 0;

	const options = {
		// eslint-disable-next-line consistent-return
		replace: ({ name, attribs, children }) => {
			if (name === 'head') {
				return <span />;
			}

			if (name === 'html' || name === 'body') {
				return <div>{domToReact(children, options)}</div>;
			}

			if (attribs && attribs.id === 'b64encodedPlainText') {
				return (
					<div className="b64-decoded-document-text">
						{atob(children[0].data)}
					</div>
				);
			}

			if (name === 'i') {
				return (
					<IconButton
						id={attribs.id}
						className={classnames(
							attribs.class,
							'section-angle-icon',
						)}
						aria-label="Expand or collapse section"
						icon={faAngleDown}
						size="xs"
					/>
				);
			}

			if (
				name === 'div' &&
				!isNil(attribs) &&
				attribs.id === 'b64encodedPDF'
			) {
				const data = reduce(
					children,
					(acc, child) => `${acc}${child.data}`,
					'',
				);
				const file = {
					name: 'report.pdf',
					data: atob(data.replace(/\s/g, '')),
				};

				const pdfProps = {
					singlePage: false,
					className: 'pdf-viewer',
					useSvg: true,
					defaultScale: PdfViewer.SCALE.FIT_TO_SCREEN,
					noScroll: true,
					toolbar: {
						enabled: false,
						options: {
							paging: {
								enabled: true,
								options: {
									step: true,
									goto: true,
								},
							},
							zoom: true,
							print: false,
							download: false,
						},
					},
				};

				pdfCount += 1;

				return allowPrint ? (
					<>
						<div className="download-pdf-container">
							<a
								href={`data:application/pdf;base64,${data}`}
								className="download-pdf-link"
								download={`${documentName}-${pdfCount}.pdf`}
							>
								Download PDF
							</a>
						</div>
						<PdfViewer {...pdfProps} file={file} />
					</>
				) : (
					<PdfViewer {...pdfProps} file={file} />
				);
			}
		},
	};

	return parse(cleaned, options);
}
