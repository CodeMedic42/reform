// @ts-nocheck
function getPrintString(documentName) {
	return `
	<html>
	<head>
	<title>
	${documentName}
	</title>
	<style>
	
	body {
	font-family: sans-serif;
	}

	.section-angle-icon {
	visibility: hidden;
	display: none;
	}
	
	a {
	color: #000;
	}
	
	.document-header-container {
	margin-bottom: 16px;
	}
	
	.header-patientname {
	color: 000#;
	font-size: 18px;
	font-weight: 600;
	}
	
	.header-doc-generated {
	float: right;
	}
	
	.li-inline-block {
	padding: 7px;
	display: inline-block;
	}
	
	.circle {
	float: right;
	}
	
	.return-link {
	display: none;
	}
	
	.b64-decoded-document-text {
	white-space: pre-wrap;
	padding: 0 7px 15px 20px;
	}
	
	.download-pdf-container {
	display: none;
	}
	
	.ainq-pdf-container {
	padding-top: 16px;
	}
	
	.ainq-pdf-document {
	display: none;
	}
	
	td {
	padding: 5px;
	vertical-align: top;
	color: rgb(77, 77, 77);
	font-size: 13px;
	font-weight: normal;
	letter-spacing: 0;
	line-height: 18px;
	}
	
	th {
	vertical-align: bottom;
	text-align: left;
	padding-top: 10px;
	padding-bottom: 10px;
	color: rgb(0, 0, 0);
	font-size: 13px;
	font-weight: 600;
	height: 18px;
	width: 100px;
	letter-spacing: 0;
	}
	
	.row-bottom-boarder,
	td {
	border-bottom: 1px solid #e0e0e0;
	}
	
	tr:last-child td {
	border-bottom: 0;
	}
	
	.doc-footer {
	border-top: 1px solid black;
	padding-top: 8px;
	width: 100%;
	}
	
	.doc-footer-item {
	display: flex;
	border-bottom: 1px solid #e0e0e0;
	padding-top: 5px;
	padding-bottom: 5px;
	}
	
	.doc-footer-item-title {
	font-weight: bold;
	width: 150px;
	font-size: 16px;
	}
	
	.doc-footer-item-value {
	margin-left: 16px;
	display: flex;
	flex-direction: column;
	font-size: 16px;
	}
	
	.doc-footer-value-sub {
	font-size: 14px;
	color: #4d4d4d;
	}
	
	</style>
	</head>
	<body>
	${document.getElementById('ccd-view-body').innerHTML}
	</body>
	</html>`;
}

export default function printDocument(documentName = 'Document') {
	const printWindow = window.open('', 'PRINT', 'height=600,width=800');
	printWindow.document.write(getPrintString(documentName));
	printWindow.document.close();
	printWindow.focus();

	setTimeout(() => {
		printWindow.print();
		printWindow.close();
	}, 10);
}
