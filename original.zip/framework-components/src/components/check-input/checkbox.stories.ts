// @ts-nocheck
import CheckInput from '.';

export default {
	title: 'Inputs/Check Input',
	component: CheckInput,
};

export { default as Preview } from './stories/preview';
export { default as Basic } from './stories/basic';
export { default as Sizes } from './stories/sizes';
export { default as Colors } from './stories/colors';
