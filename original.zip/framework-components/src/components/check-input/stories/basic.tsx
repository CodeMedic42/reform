// @ts-nocheck
import React, { useState } from 'react';
import CheckInput from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [checked, setChecked] = useState(true);

	return (
		<>
			<Scope title="Basic">
				<CheckInput
					id="basic"
					value={checked}
					onChange={() => setChecked(!checked)}
				/>
			</Scope>
			<Scope title="With Label">
				<div>
					<CheckInput
						id="with-label"
						label="Click Me!"
						value={checked}
						onChange={() => setChecked(!checked)}
					/>
				</div>
			</Scope>
			<Scope title="Ignore Halo">
				<div>
					<CheckInput
						id="with-label2"
						label="Click Me!"
						value={checked}
						onChange={() => setChecked(!checked)}
						ignoreHalo
					/>
				</div>
			</Scope>
			<Scope title="With Long Label">
				<div
					className="with-long-label-container"
					style={{
						width: '250px',
						border: '1px solid black',
					}}
				>
					<CheckInput
						id="with-long-label"
						label="This is a very long label, to be multiline. Here is more label description"
						value={checked}
						onChange={() => setChecked(!checked)}
					/>
				</div>
			</Scope>
			<Scope title="Indeterminate">
				<CheckInput
					id="indeterminate"
					value={checked}
					variant="indeterminate"
					onChange={() => setChecked(!checked)}
				/>
			</Scope>
			<Scope title="Disabled">
				<CheckInput
					id="check-disabled"
					label="Text"
					value={checked}
					disabled
					onChange={() => setChecked(!checked)}
				/>
				<CheckInput
					id="indeterminate-disabled"
					value={checked}
					variant="indeterminate"
					disabled
					onChange={() => setChecked(!checked)}
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
