// @ts-nocheck
import React, { useState } from 'react';
import map from 'lodash-es/map';
import CheckInput from '..';
import { schemeColorOrder } from '../../../common/color-list';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [checked, setChecked] = useState(false);

	return (
		<>
			{map(schemeColorOrder, (color) => (
				<Scope key={color} title={color}>
					{map(['check', 'indeterminate'], (variant) => (
						<CheckInput
							key={variant}
							id={`${color}-${variant}`}
							label="Click Me!"
							value={checked}
							variant={variant}
							color={color}
							onChange={() => setChecked(!checked)}
						/>
					))}
				</Scope>
			))}
		</>
	);
}

example.story = {
	name: 'Colors',
};

export default example;
