// @ts-nocheck
import React, { useState, useMemo } from 'react';
import { schemeColorOrder } from '../../../common/color-list';
import Scope from '../../../../.storybook/components/scope';
import CheckBox from '..';

function generateMessages(count = 0) {
	const messages = [];

	for (let counter = 0; counter < count; counter += 1) {
		messages.push(`Message Number ${counter + 1}`);
	}

	return messages;
}

function example(props) {
	const [value, setValue] = useState(false);

	const {
		successMessageCount,
		invalidMessageCount,
		generalMessageCount,
		...rest
	} = props;

	const successMessages = useMemo(
		() => generateMessages(successMessageCount),
		[successMessageCount],
	);
	const invalidMessages = useMemo(
		() => generateMessages(invalidMessageCount),
		[invalidMessageCount],
	);
	const generalMessages = useMemo(
		() => generateMessages(generalMessageCount),
		[generalMessageCount],
	);

	const messages = useMemo(() => {
		if (
			successMessages.length <= 0 &&
			invalidMessages.length <= 0 &&
			generalMessages.length <= 0
		) {
			return null;
		}

		const mess = {};

		if (successMessages.length > 0) {
			mess.success = successMessages;
		}

		if (invalidMessages.length > 0) {
			mess.invalid = invalidMessages;
		}

		if (generalMessages.length > 0) {
			mess.general = generalMessages;
		}

		return mess;
	}, [successMessages, invalidMessages, generalMessages]);

	return (
		<Scope fillViewport>
			<CheckBox
				{...rest}
				value={value}
				onChange={setValue}
				messages={messages}
			/>
		</Scope>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		label: {
			control: 'text',
		},
		disabled: {
			control: 'boolean',
		},
		hidden: {
			control: 'boolean',
		},
		onClick: { table: { disable: true } },
		size: {
			options: ['lg', 'md', 'sm'],
			control: { type: 'select' },
		},
		'aria-label': {
			control: 'text',
		},
		'aria-labelledby': {
			control: 'text',
		},
		'aria-describedby': {
			control: 'text',
		},
		title: {
			control: 'text',
		},
		color: {
			options: schemeColorOrder,
			control: { type: 'select' },
			description:
				'The scheme colors. pallette colors are not supported. If not set with inherit the scheme of its parent elements.',
		},
		variant: {
			options: ['check', 'indeterminate'],
			control: { type: 'select' },
			description: 'The style to render the Checkbox as.',
		},
		onClickMeta: { table: { disable: true } },
		ignoreHalo: {
			control: 'boolean',
		},
		successMessageCount: {
			control: 'number',
		},
		invalidMessageCount: {
			control: 'number',
		},
		generalMessageCount: {
			control: 'number',
		},
		messages: { table: { disable: true } },
		onChange: { table: { disable: true } },
		onChangeMeta: { table: { disable: true } },
		value: { table: { disable: true } },
		constrictField: {
			control: 'boolean',
		},
	},
	args: {
		disabled: false,
		hidden: false,
		ignoreHalo: false,
		constrictField: false,
	}
};

export default example;
