// @ts-nocheck
import React, { useState } from 'react';
import map from 'lodash-es/map';
import CheckInput from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [checked, setChecked] = useState(false);

	return (
		<>
			{map(['sm', 'md', 'lg'], (size) => (
				<Scope key={size} title={size}>
					{map(['check', 'indeterminate'], (variant) => (
						<div key={`${variant}`}>
							{map(['sm', 'md', 'lg'], (haloSize) => (
								<CheckInput
									key={haloSize}
									id={`${size}-${variant}-${haloSize}`}
									label="Click Me!"
									value={checked}
									size={size}
									haloSize={haloSize}
									variant={variant}
									onChange={() => setChecked(!checked)}
								/>
							))}
						</div>
					))}
				</Scope>
			))}
		</>
	);
}

example.story = {
	name: 'Sizes',
};

export default example;
