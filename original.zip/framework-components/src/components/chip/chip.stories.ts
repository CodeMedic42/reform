// @ts-nocheck
import Chip from '.';

export default {
	title: 'Labeling/Chip',
	component: Chip,
};

export { default as preview } from './stories/preview';
export { default as basic } from './stories/basic';
export { default as colors } from './stories/colors';
export { default as wrappingText } from './stories/wrapping-text';
export { default as clickable } from './stories/clickable';
