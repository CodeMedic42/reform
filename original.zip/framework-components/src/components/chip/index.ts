// @ts-nocheck
import Chip from './chip';

export default Chip;
