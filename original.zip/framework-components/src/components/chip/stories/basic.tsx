// @ts-nocheck
import React from 'react';
import Chip from '..';
import { Row, Column } from '../../grid';
import Scope from '../../../../.storybook/components/scope';

function example() {
	return (
		<>
			<Scope title="Variants">
				<Row gutter>
					<Column width="content">
						<Chip color="primary" variant="rectangle">
							Rectangle
						</Chip>
					</Column>
					<Column width="content">
						<Chip color="primary" variant="pill">
							Pill
						</Chip>
					</Column>
				</Row>
			</Scope>
			<Scope title="Floating">
				<Chip color="primary" floating>
					Floating
				</Chip>
			</Scope>
			<Scope title="Disabled">
				<Chip color="primary" floating disabled>
					Disabled
				</Chip>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
