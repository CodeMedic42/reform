/* eslint-disable no-alert */
// @ts-nocheck
import React, { Fragment } from 'react';
import map from 'lodash-es/map';
import Chip from '../chip';
import Scope from '../../../../.storybook/components/scope';
import {
	paletteColorOrder,
	schemeColorOrder,
} from '../../../common/color-list';
import { Row, Column } from '../../grid';

const sizes = ['xs', 'sm', 'md', 'lg', 'xl'];
const variants = ['rectangle', 'pill'];
const shades = ['light', 'dark'];

function example() {
	return (
		<>
			{map(shades, (shade) => (
				<Scope key={shade} title={`Palette Colors Shade: ${shade}`}>
					{map(sizes, (size) => (
						<Fragment key={size}>
							{map(variants, (variant) => (
								<Row key={variant} gutter>
									{map(paletteColorOrder, (color) => (
										<Column key={color} width="content">
											<Chip
												color={color}
												size={size}
												variant={variant}
												shade={shade}
												onClick={() => alert('clicked')}
											>
												Clickable
											</Chip>
										</Column>
									))}
								</Row>
							))}
						</Fragment>
					))}
				</Scope>
			))}
			<Scope title="Schema Colors">
				{map(sizes, (size) => (
					<Fragment key={size}>
						{map(variants, (variant) => (
							<Row key={variant} gutter>
								{map(schemeColorOrder, (color) => (
									<Column key={color} width="content">
										<Chip
											color={color}
											size={size}
											variant={variant}
											onClick={() => alert('clicked')}
										>
											Clickable
										</Chip>
									</Column>
								))}
							</Row>
						))}
					</Fragment>
				))}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Clickable',
};

export default example;
