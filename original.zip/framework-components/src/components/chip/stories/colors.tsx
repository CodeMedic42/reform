// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Chip from '..';
import { Row, Column } from '../../grid';
import Scope from '../../../../.storybook/components/scope';
import { colorOrder } from '../../../common/color-list';

const sizes = ['xs', 'sm', 'md', 'lg', 'xl'];

function BuildScope(color) {
	return (
		<Scope key={color} title={color}>
			<Row gutter="8">
				{map(sizes, (size) => (
					<Column key={size} width="content">
						<Chip
							key={size}
							color={color}
							size={size}
							className="gutter-horizontal"
						>
							{`size-${size}`}
						</Chip>
					</Column>
				))}
			</Row>
			<Row gutter="8">
				{map(sizes, (size) => (
					<Column key={size} width="content">
						<Chip
							key={size}
							color={color}
							size={size}
							onClear={() => {}}
							className="gutter-horizontal"
						>
							{`size-${size}`}
						</Chip>
					</Column>
				))}
			</Row>
			<Row gutter="8">
				{map(sizes, (size) => (
					<Column key={size} width="content">
						<Chip
							key={size}
							color={color}
							size={size}
							variant="pill"
							className="gutter-horizontal"
						>
							{`size-${size}`}
						</Chip>
					</Column>
				))}
			</Row>
			<Row gutter="8">
				{map(sizes, (size) => (
					<Column key={size} width="content">
						<Chip
							key={size}
							color={color}
							size={size}
							variant="pill"
							onClear={() => {}}
							className="gutter-horizontal"
						>
							{`size-${size}`}
						</Chip>
					</Column>
				))}
			</Row>
		</Scope>
	);
}

function example() {
	return <>{map(colorOrder, (color) => BuildScope(color))}</>;
}

example.story = {
	name: 'Colors',
};

export default example;
