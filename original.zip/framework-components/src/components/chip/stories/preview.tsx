// @ts-nocheck
import React from 'react';
import { colorOrder } from '../../../common/color-list';
import Scope from '../../../../.storybook/components/scope';
import Chip from '..';

function example(props) {
	return (
		<Scope fillViewport>
			<Chip {...props} />
		</Scope>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		color: {
			options: colorOrder,
			control: { type: 'select' },
			description:
				'The scheme colors. pallette colors are not supported. If not set with inherit the scheme of its parent elements.',
		},
		size: {
			options: ['xs', 'sm', 'md', 'lg', 'xl'],
			control: { type: 'select' },
		},
		variant: {
			options: ['rectangle', 'pill'],
			control: { type: 'select' },
		},
		asButton: {
			control: 'boolean',
		},
		disabled: {
			control: 'boolean',
			if: { arg: 'asButton', truthy: true },
		},
		children: {
			control: 'text',
		},
		onClick: { table: { disable: true } },
		onClickMeta: { table: { disable: true } },
	},
	args: {
		size: 'md',
		variant: 'rectangle',
		asButton: false,
		disabled: false,
		children: 'Chip Label',
	}
};

export default example;
