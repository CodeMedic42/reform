// @ts-nocheck
import React from 'react';
import Chip from '..';
import Scope from '../../../../.storybook/components/scope';
import { Row, Column } from '../../grid';

function example() {
	return (
		<Scope title="wrapping text">
			<Row gutter>
				<Column width="3">
					<Chip color="primary" size="sm">
						This is some very long text to test wrapping.
					</Chip>
				</Column>
				<Column width="3">
					<Chip color="primary" size="md">
						This is some very long text to test wrapping.
					</Chip>
				</Column>
				<Column width="3">
					<Chip color="primary" size="lg">
						This is some very long text to test wrapping.
					</Chip>
				</Column>
				<Column width="3">
					<Chip color="primary" size="xl">
						This is some very long text to test wrapping.
					</Chip>
				</Column>
			</Row>
		</Scope>
	);
}

example.story = {
	name: 'Wrapping Text',
};

export default example;
