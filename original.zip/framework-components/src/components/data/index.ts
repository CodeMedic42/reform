// @ts-nocheck
import Data from './data';
import DataTextProperty from './data-text-property';
import DataNumericProperty from './data-numeric-property';
import DataSelectProperty from './data-select-property';
import DataMultiSelectProperty from './data-multi-select-property';
import DataCheckProperty from './data-check-property';
import DataDateProperty from './data-date-property';
import DataMaskProperty from './data-mask-property';
import DataTextAreaProperty from './data-text-area-property';
import DataRadioGroupProperty from './data-radio-group-property';
import DataIconButton from './data-icon-button';
import DataSwitchProperty from './data-switch-property';
import DataValueProperty from './data-value-property';
import DataList from './data-list';
import DataGroup from './data-group';
import DataButton from './data-button';
import DataAccess from './data-access';

export default Data;

export {
	DataTextAreaProperty,
	DataTextProperty,
	DataNumericProperty,
	DataSelectProperty,
	DataMultiSelectProperty,
	DataCheckProperty,
	DataDateProperty,
	DataMaskProperty,
	DataRadioGroupProperty,
	DataIconButton,
	DataSwitchProperty,
	DataValueProperty,
	DataList,
	DataGroup,
	DataButton,
	DataAccess,
};
