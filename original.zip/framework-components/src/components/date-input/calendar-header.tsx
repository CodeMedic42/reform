// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

class CalendarHeader extends PureComponent {
	constructor(props) {
		super(props);

		this.handleMonthChange = this.handleMonthChange.bind(this);
		this.handleYearChange = this.handleYearChange.bind(this);
	}

	handleMonthChange(event) {
		const { date, onChange } = this.props;
		const month = event.target.value;
		const year = date.getFullYear();
		onChange(new Date(year, month));
	}

	handleYearChange(event) {
		const { date, onChange } = this.props;
		const year = event.target.value;
		const month = date.getMonth();
		onChange(new Date(year, month));
	}

	render() {
		const { date, localeUtils, fromDate, toDate } = this.props;
		const months = localeUtils.getMonths();
		const dateYear = date.getFullYear();
		let dateYearInRange = false;

		const years = [];
		for (
			let i = fromDate.getFullYear();
			i <= toDate.getFullYear();
			i += 1
		) {
			years.push(i);

			if (!dateYearInRange && i === dateYear) {
				dateYearInRange = true;
			}
		}

		if (!dateYearInRange) {
			years.push(dateYear);
		}

		return (
			<div className="DayPicker-Caption calendar-header">
				<select
					tabIndex="-1"
					className="calendar-header-month"
					name="month"
					onChange={this.handleMonthChange}
					value={date.getMonth()}
				>
					{months.map((month, i) => (
						<option key={month} value={i}>
							{month}
						</option>
					))}
				</select>
				<select
					tabIndex="-1"
					className="calendar-header-year"
					name="year"
					onChange={this.handleYearChange}
					value={dateYear}
				>
					{years.map((year) => (
						<option key={year} value={year}>
							{year}
						</option>
					))}
				</select>
			</div>
		);
	}
}

CalendarHeader.propTypes = {
	date: PropTypes.instanceOf(Date).isRequired,
	// eslint-disable-next-line react/forbid-prop-types
	localeUtils: PropTypes.object.isRequired,
	onChange: PropTypes.func.isRequired,
	fromDate: PropTypes.instanceOf(Date).isRequired,
	toDate: PropTypes.instanceOf(Date).isRequired,
};
export default CalendarHeader;
