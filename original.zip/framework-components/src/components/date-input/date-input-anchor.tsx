// @ts-nocheck
import React, { useCallback, useMemo, useState } from 'react';
import formatFnc from 'date-fns/format';
import parse from 'date-fns/parse';
import startOfToday from 'date-fns/startOfToday';
import isNil from 'lodash-es/isNil';
import PropTypes from 'prop-types';
import isValidDate from '@audacious/web-common/utilities/isValidDate';
import InputValueBuffer from '../base-input/input-value-buffer';
import BaseMaskInput from '../base-input/base-mask-input';
import applyAnchorBinding from '../drop-down/anchor-binding';

const INVALID_DATE = new Date(NaN);
const DATE_FORMAT = 'MM / dd / yyyy';
const DATE_PLACEHOLDER = 'MM / DD / YYYY';
const DATE_MASK = [/\d/, /\d/, ' ', '/', ' ', /\d/, /\d/, ' ', '/', ' ', /\d/, /\d/, /\d/, /\d/];

function DateInputAnchor(props) {
	const {
		value,
		onChange,
		...rest
	} = props;

	const [stringValue, setStringValue] = useState(null);
	
	const handleChange = useCallback((newValue) => {
		let finalValue = null;

		setStringValue(newValue);

		if (!isNil(newValue)) {
			finalValue = parse(newValue, DATE_FORMAT, startOfToday());

			if (isValidDate(finalValue)) {
				setStringValue(newValue);
			} else {
				finalValue = INVALID_DATE;
			}
		}

		onChange(finalValue);
	}, [onChange]);

	const date = useMemo(() => {
		if (isNil(value)) {
			return '';
		}

		if (isValidDate(value)) {
			return formatFnc(value, DATE_FORMAT);
		}

		return stringValue;
	}, [value, stringValue]);

	return (
		<InputValueBuffer
			value={date}
			onChange={handleChange}
		>
			{({ value: baseValue, onChange: baseOnChange }) => (
				<BaseMaskInput
					value={baseValue}
					onChange={baseOnChange}
					placeholder={DATE_PLACEHOLDER}
					mask={DATE_MASK}
					autoComplete="off"
					guide
					keepCharPositions
					{...rest}
				/>
			)
		}
		</InputValueBuffer>
	);
}

DateInputAnchor.propTypes = {
	value: PropTypes.instanceOf(Date),
	onChange: PropTypes.func,
};

DateInputAnchor.defaultProps = {
	value: null,
	onChange: null,
};

export default applyAnchorBinding(DateInputAnchor, {
	focusSelector: '.input-container input',
});
