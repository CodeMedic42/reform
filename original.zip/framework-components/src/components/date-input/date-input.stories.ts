// @ts-nocheck
import Button from '.';

export default {
	title: 'Inputs/Date Input',
	component: Button,
	argTypes: { onClick: { action: 'clicked' } },
};

export { default as basic } from './stories/basic';
export { default as sizes } from './stories/sizes';
export { default as messages } from './stories/messages';
export { default as availableRange } from './stories/available-range';
