// @ts-nocheck
import React, { PureComponent, createRef } from 'react';
import PropTypes from 'prop-types';
import { DayPicker } from "react-day-picker";
import startOfDay from 'date-fns/startOfDay';
import startOfToday from 'date-fns/startOfToday';
import isNil from 'lodash-es/isNil';
import classnames from 'classnames';
import { faCalendar } from '@audacious/icons/regular/faCalendar';
import isValidDate from '@audacious/web-common/utilities/isValidDate';
import DropDown from '../drop-down';
import InputLabel, {
	propTypes as inputLabelPropTypes,
	defaultProps as inputLabelDefaultProps,
} from '../base-input/input-label';
import preventDefault from '../../common/prevent-default';
import DateInputAnchor from './date-input-anchor';


const currentYear = new Date().getFullYear();

class DateInput extends PureComponent {
	constructor(props) {
		super(props);

		this.dropdownRef = createRef();
		this.labelRef = createRef();

		const { value } = props;

		this.state = {
			displayMonthDate: !isNil(value) ? value : startOfToday(),
			currentValue: value,
		};

		this.handleMonthChange = this.handleMonthChange.bind(this);
		this.handleDayClick = this.handleDayClick.bind(this);
		this.labelPreventDefault = this.labelPreventDefault.bind(this);
		this.handleClose = this.handleClose.bind(this);
	}

	static getDerivedStateFromProps(nextProps, currentState) {
		const { value } = nextProps;

		let { displayMonthDate, currentValue } = currentState;

		if (isValidDate(value) && currentValue !== value) {
			// If something other than this component changed the date value,
			// ensure the datepicker month shows the new date

			displayMonthDate = value;
		}

		currentValue = value;

		return {
			currentValue,
			displayMonthDate,
		};
	}

	handleMonthChange(month) {
		this.setState({ displayMonthDate: month });
	}

	handleDayClick(nextDate) {
		const { onChange } = this.props;

		const date = startOfDay(nextDate);

		this.setState({
			displayMonthDate: date,
		});

		onChange(date);

		this.dropdownRef.current.close(true);
	}

	handleClose() {
		const { value } = this.props;

		this.setState({
			displayMonthDate: isValidDate(value) ? value : startOfToday(),
		});
	}

	labelPreventDefault(event) {
		if (event.target === this.labelRef.current) {
			event.preventDefault();
		}
	}

	render() {
		const {
			id,
			className,
			label,
			messages,
			title,
			invalid,
			required,
			hidden,
			disabled,
			name,
			fromDate,
			toDate,
			onFocus,
			onBlur,
			onChange,
			format,
			value,
			'aria-label': ariaLabel,
			'aria-labelledby': ariaLabelledby,
			'aria-describedby': ariaDescribedby,
			size,
		} = this.props;

		const { displayMonthDate } = this.state;

		return (
			<InputLabel
				className={classnames(
					'ai-drop-down-input',
					'ai-date-input',
					className,
				)}
				id={id}
				label={label}
				messages={messages}
				invalid={invalid}
				aria-labelledby={ariaLabelledby}
				aria-describedby={ariaDescribedby}
				hidden={hidden}
				disabled={disabled}
				size={size}
			>
				{({ describedBy, labelledBy, inputId, finalId }) => (
					<DropDown
						ref={this.dropdownRef}
						id={`${finalId}-dropdown`}
						trayClassName="ai-date-tray"
						onFocus={onFocus}
						onBlur={onBlur}
						closeTrayOnClick={false}
						disabled={disabled}
						Anchor={DateInputAnchor}
						onClose={this.handleClose}
						anchorProps={{
							onChange,
							value,
							id: inputId,
							title,
							'aria-labelledby': labelledBy,
							'aria-describedby': describedBy,
							required,
							disabled,
							name,
							size,
							rightIcon: {
								icon: faCalendar,
							},
							'aria-label': ariaLabel,
							format,
						}}
					>
						<DayPicker
							tabIndex="-1"
							month={displayMonthDate}
							fromMonth={fromDate}
							toMonth={toDate}
							numberOfMonths={1}
							selectedDays={value}
							onDayClick={this.handleDayClick}
							onMonthChange={this.handleMonthChange}
							captionLayout="dropdown-buttons"
							containerProps={{ onClick: preventDefault }}
						/>
					</DropDown>
				)}
			</InputLabel>
		);
	}
}

DateInput.propTypes = {
	...inputLabelPropTypes,
	value: PropTypes.instanceOf(Date),
	onChange: PropTypes.func,
	onBlur: PropTypes.func,
	onFocus: PropTypes.func,
	title: PropTypes.string,
	'aria-label': PropTypes.string,
	required: PropTypes.bool,
	disabled: PropTypes.bool,
	name: PropTypes.string,
	fromDate: PropTypes.instanceOf(Date),
	toDate: PropTypes.instanceOf(Date),
	format: PropTypes.string,
};

DateInput.defaultProps = {
	...inputLabelDefaultProps,
	value: null,
	onChange: null,
	onBlur: null,
	onFocus: null,
	title: null,
	'aria-label': null,
	required: null,
	disabled: null,
	name: null,
	fromDate: new Date(currentYear - 120, 0),
	toDate: new Date(currentYear + 50, 11),
	format: 'MM / dd / yyyy',
};

export default DateInput;
