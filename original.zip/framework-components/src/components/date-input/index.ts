// @ts-nocheck
import DateInput from './date-input';

export default DateInput;
