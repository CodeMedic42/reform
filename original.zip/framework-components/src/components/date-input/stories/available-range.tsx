// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import DateInput from '..';

const currentYear = new Date().getFullYear();

function example() {
	const [value, setValue] = React.useState(null);

	return (
		<>
			<Scope title="Default">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Next 10 Years">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
					fromDate={new Date(currentYear, 0)}
					toDate={new Date(currentYear + 10, 0)}
				/>
			</Scope>
			<Scope title="Previous 10 Years">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
					fromDate={new Date(currentYear - 10, 0)}
					toDate={new Date(currentYear, 11)}
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Available Range',
};

export default example;
