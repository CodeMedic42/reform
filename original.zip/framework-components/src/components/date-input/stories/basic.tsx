// @ts-nocheck
import React from 'react';
import parse from 'date-fns/parse';
import startOfToday from 'date-fns/startOfToday';
import Scope from '../../../../.storybook/components/scope';
import DateInput from '..';

const startingDate = parse('10-05-2020', 'MM-dd-yyyy', startOfToday());

function example() {
	const [value, setValue] = React.useState(null);
	const [value2, setValue2] = React.useState(startingDate);

	return (
		<>
			<Scope title="Simple">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Disabled">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
					disabled
				/>
			</Scope>
			<Scope title="Hidden">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
					hidden
				/>
			</Scope>
			<Scope title="No label">
				<DateInput value={value} onChange={setValue} />
			</Scope>
			<Scope title="Initial Value">
				<DateInput
					label="Date Input"
					value={value2}
					onChange={setValue2}
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
