// @ts-nocheck
import React from 'react';
import DateInput from '..';
import CheckInput from '../../check-input';
import Scope from '../../../../.storybook/components/scope';
import MessageControls from '../../../common/storybook/message-controls';
import { Row, Column } from '../../grid';

function example() {
	const [value, setValue] = React.useState(null);

	const [generalMessages, setGeneralMessages] = React.useState([]);
	const [successMessages, setSuccessMessages] = React.useState([]);
	const [invalidMessages, setInvalidMessages] = React.useState([]);
	const [showInvalid, setShowInvalid] = React.useState(false);

	const renderControls = () => (
		<MessageControls
			onGeneralMessageChange={setGeneralMessages}
			onSuccessMessageChange={setSuccessMessages}
			onInvalidMessageChange={setInvalidMessages}
		>
			<Row>
				<Column>
					<CheckInput
						id="hideScope"
						label="Show as invalid"
						value={showInvalid}
						onChange={() => {
							setShowInvalid(!showInvalid);
						}}
					/>
				</Column>
			</Row>
		</MessageControls>
	);

	return (
		<Scope title="Messages" controls={renderControls()}>
			<DateInput
				id="example"
				label="Date Input"
				value={value}
				placeholder="Placeholder"
				messages={{
					general: generalMessages,
					success: successMessages,
					invalid: invalidMessages,
				}}
				invalid={showInvalid}
				onChange={setValue}
			/>
		</Scope>
	);
}

example.story = {
	name: 'Messages',
};

export default example;
