// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import DateInput from '..';

function example() {
	const [value, setValue] = React.useState(null);

	return (
		<>
			<Scope title="No Size">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Small">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
					size="sm"
				/>
			</Scope>
			<Scope title="Medium">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
					size="md"
				/>
			</Scope>
			<Scope title="Large">
				<DateInput
					label="Date Input"
					value={value}
					onChange={setValue}
					size="lg"
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Sizes',
};

export default example;
