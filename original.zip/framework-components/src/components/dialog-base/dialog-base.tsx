// @ts-nocheck
import React, { PureComponent } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import forEach from 'lodash-es/forEach';
import { faXmarkLarge } from '@audacious/icons/solid/faXmarkLarge';
import IconButton from '../icon-button';
import OverlaySpinner from '../overlay-spinner';
import Backdrop from '../backdrop';
import ExternalBoundary from '../external-boundary';

const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

function resetRoot(root) {
	if (isSafari) {
		// eslint-disable-next-line no-param-reassign
		root.style.overflow = 'hidden';

		setTimeout(() => {
			// eslint-disable-next-line no-param-reassign
			root.style.overflow = null;

			window.dispatchEvent(new Event('resize'));
		}, 10);
	} else {
		window.dispatchEvent(new Event('resize'));
	}
}

function hideScrollBar() {
	const root = document.documentElement;

	root.classList.add('hide-scroll');

	resetRoot(root, isSafari);
}

function showScrollBar() {
	const root = document.documentElement;

	root.classList.remove('hide-scroll');

	resetRoot(root, isSafari);
}

let scrollHiddenCount = 0;

class DialogBase extends PureComponent {
	constructor(props) {
		super(props);

		this.scrollHidden = false;

		this.handleClose = this.handleClose.bind(this);
		this.handleAnimationEnd = this.handleAnimationEnd.bind(this);
		this.handleExternalClick = this.handleExternalClick.bind(this);

		this.state = {
			rendered: false,
		};
	}

	componentDidMount() {
		const { open, disableBackdrop } = this.props;
		const { rendered } = this.state;

		if ((open || rendered) && disableBackdrop) {
			if (scrollHiddenCount <= 0) {
				hideScrollBar();
			}

			this.scrollHidden = true;
			scrollHiddenCount += 1;
		}
	}

	componentDidUpdate() {
		const { open, disableBackdrop } = this.props;
		const { rendered } = this.state;

		if ((open || rendered) && disableBackdrop) {
			if (!this.scrollHidden) {
				if (scrollHiddenCount <= 0) {
					hideScrollBar();
				}

				this.scrollHidden = true;
				scrollHiddenCount += 1;
			}
		} else if (this.scrollHidden) {
			this.scrollHidden = false;
			scrollHiddenCount -= 1;

			if (scrollHiddenCount <= 0) {
				showScrollBar();
			}
		}
	}

	componentWillUnmount() {
		showScrollBar();

		if (this.scrollHidden) {
			this.scrollHidden = false;
			scrollHiddenCount -= 1;

			if (scrollHiddenCount <= 0) {
				showScrollBar();
			}
		}
	}

	handleClose(event) {
		const { onClose, onCloseMeta } = this.props;

		if (isNil(onClose)) {
			return;
		}

		onClose({
			event,
			meta: onCloseMeta,
		});
	}

	handleExternalClick(event) {
		const { enableCloseOnOffClick, isSaving } = this.props;

		if (isSaving) {
			return;
		}

		let close = false;

		if (enableCloseOnOffClick === true) {
			close = true;
		} else {
			let matches = false;

			forEach(enableCloseOnOffClick, (ignoreSelector) => {
				matches = !isNil(event.target.closest(ignoreSelector));

				return !matches;
			});

			close = !matches;
		}

		if (close) {
			this.handleClose();
		}
	}

	handleAnimationEnd() {
		const { open } = this.props;

		const { rendered } = this.state;

		if (open) {
			this.setState({
				rendered: true,
			});

			return;
		}

		if (rendered) {
			this.setState({
				rendered: false,
			});
		}
	}

	render() {
		const {
			id,
			size,
			className,
			open,
			enableCloseButton,
			disableBackdrop,
			isLoading,
			isSaving,
			children,
			enableCloseOnOffClick,
			enableAnimation,
			backdropVariant,
			spinnerSize,
			spinnerAlignment,
		} = this.props;

		const { rendered } = this.state;

		if (!open) {
			if (!enableAnimation) {
				return null;
			}

			if (!rendered) {
				return null;
			}
		}

		if (isNil(size)) {
			return null;
		}

		const sizeClass = `size-${size}`;

		const closeButton = enableCloseButton ? (
			<IconButton
				id={!isNil(id) ? `${id}-close` : null}
				className="btn-close"
				icon={faXmarkLarge}
				onClick={this.handleClose}
				aria-label="Close"
			/>
		) : null;

		const spinner =
			isLoading || isSaving ? (
				<OverlaySpinner
					size={spinnerSize}
					alignment={spinnerAlignment}
				/>
			) : null;

		const backdrop =
			backdropVariant !== 'none' ? (
				<Backdrop
					className="ai-dialog-backdrop"
					variant={backdropVariant}
					enabled={open}
					enableAnimation={enableAnimation}
					position="fixed"
				/>
			) : null;

		const onExternalClick =
			enableCloseOnOffClick !== false && !isNil(enableCloseOnOffClick)
				? this.handleExternalClick
				: null;

		const dialog = (
			<>
				{backdrop}
				<ExternalBoundary
					id={id}
					className={classnames('ai-dialog', className, {
						'enable-animation': enableAnimation,
						'start-close': !open && rendered,
						'dialog-is-loading': isLoading,
						'dialog-is-saving': isSaving,
					})}
					onAnimationEnd={this.handleAnimationEnd}
					onExternalClick={onExternalClick}
					cancelExternalScroll={disableBackdrop}
				>
					<div
						className={classnames(
							'ai-dialog-container',
							sizeClass,
							{
								'dialog-is-loading': isLoading,
								'dialog-is-saving': isSaving,
							},
						)}
					>
						<div className="ai-dialog-content">
							{spinner}
							{closeButton}
							{children}
						</div>
					</div>
				</ExternalBoundary>
			</>
		);

		return ReactDOM.createPortal(dialog, window.document.body);
	}
}

DialogBase.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	open: PropTypes.bool,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	onClose: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onCloseMeta: PropTypes.object,
	enableCloseButton: PropTypes.bool,
	enableCloseOnOffClick: PropTypes.oneOfType([
		PropTypes.bool,
		PropTypes.arrayOf(PropTypes.string),
	]),
	disableBackdrop: PropTypes.bool,
	// Set to true while data is being retrieved to display in the dialog
	isLoading: PropTypes.bool,
	// Set to true while data entered on the dialog is being saved
	isSaving: PropTypes.bool,
	enableAnimation: PropTypes.bool,
	backdropVariant: PropTypes.oneOf(['lite', 'dark', 'none']).isRequired,
	spinnerSize: PropTypes.string,
	spinnerAlignment: PropTypes.string,
};

DialogBase.defaultProps = {
	id: null,
	className: null,
	open: false,
	children: null,
	onClose: null,
	onCloseMeta: null,
	enableCloseButton: false,
	enableCloseOnOffClick: false,
	isLoading: false,
	isSaving: false,
	enableAnimation: false,
	disableBackdrop: false,
	size: 'md',
	spinnerSize: 'md',
	spinnerAlignment: 'centered',
};

export default DialogBase;
