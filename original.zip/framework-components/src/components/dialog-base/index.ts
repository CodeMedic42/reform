// @ts-nocheck
import DialogBase from './dialog-base';

export default DialogBase;
