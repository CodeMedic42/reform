// @ts-nocheck
import Dialog from './dialog';

export default {
	title: 'Layout/Dialog',
	component: Dialog,
};

export { default as basic } from './stories/modal';
export { default as left } from './stories/drawer-left';
export { default as right } from './stories/drawer-right';
