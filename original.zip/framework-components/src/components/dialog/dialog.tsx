// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import deprecateMessage from '../../common/deprecate-message';
import Drawer from '../drawer';
import Modal from '../modal';

function Dialog(props) {
	const { variant, children, enableCloseBackdrop, ...rest } = props;

	deprecateMessage(
		'dialog',
		'The Dialog component is being deprecated, please use either Drawer or Modal.',
	);

	if (variant === 'modal') {
		return (
			<Modal {...rest} enableCloseOnOffClick={enableCloseBackdrop}>
				{children}
			</Modal>
		);
	}

	let drawerVariant = null;

	if (variant === 'drawer-left') {
		drawerVariant = 'left';
	} else if (variant === 'drawer-right') {
		drawerVariant = 'right';
	} else {
		return null;
	}

	return (
		<Drawer
			{...rest}
			variant={drawerVariant}
			enableCloseOnOffClick={enableCloseBackdrop}
		>
			{children}
		</Drawer>
	);
}

Dialog.propTypes = {
	variant: PropTypes.oneOf(['modal', 'drawer-left', 'drawer-right'])
		.isRequired,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	enableCloseBackdrop: PropTypes.bool,
};

Dialog.defaultProps = {
	children: null,
	enableCloseBackdrop: false,
};

export default Dialog;
