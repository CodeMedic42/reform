// @ts-nocheck
import Dialog from './dialog';

export default Dialog;
