// @ts-nocheck
import React, { useState, useCallback } from 'react';
import Dialog from '..';
import Button from '../../button';
import Scope from '../../../../.storybook/components/scope';
import Document from '../../document';
import DocumentHeader from '../../document/document-header';
import DocumentBody from '../../document/document-body';
import DocumentFooter from '../../document/document-footer';
import ButtonGroup from '../../button-group';
import SelectInput from '../../select-input';
import { Text } from '../../typography';
import { Row, Column } from '../../grid';

const sizeOptions = [
	{
		key: 'xs',
		text: 'Extra Small',
	},
	{
		key: 'sm',
		text: 'Small',
	},
	{
		key: 'md',
		text: 'Medium',
	},
	{
		key: 'lg',
		text: 'Large',
	},
	{
		key: 'xl',
		text: 'Extra Large',
	},
];

const allRows = [];

for (let counter = 0; counter < 100; counter += 1) {
	allRows.push(<p key={counter}>{`Row ${counter + 1}`}</p>);
}

export default function renderSizes(
	title,
	variant,
	showLargeBody,
	enableCloseButton = false,
	enableAnimation = false,
) {
	const rows = showLargeBody ? allRows : [allRows[0]];
	const [open, setOpen] = useState(false);
	const [size, setSize] = useState('md');
	const [loading, setLoading] = useState(false);
	const [saving, setSaving] = useState(false);

	let description = enableCloseButton
		? 'Document footers and Save/Cancel buttons should not be used when enableCloseButton (which enables the X button) is true.'
		: 'The Save button should be disabled while loading.';

	if (variant === 'modal' && enableCloseButton) {
		description = `Unless enableCloseBackdrop is set, it defaults to true only for modals with enableCloseButton set to true. ${description}`;
	}

	const handleOpenClick = useCallback(() => {
		setOpen(true);
		setLoading(true);

		setTimeout(() => setLoading(false), 2000);
	});

	const handleClose = useCallback(() => {
		setOpen(false);
	});

	const handleSave = useCallback(() => {
		setSaving(true);

		setTimeout(() => {
			setOpen(false);
			setSaving(false);
		}, 5000);
	});

	return (
		<Scope title={title}>
			<Row gutter>
				<Column>
					<Text>{description}</Text>
				</Column>
				<Column>
					<Button onClick={handleOpenClick}>Open</Button>
				</Column>
			</Row>
			<Dialog
				open={open}
				size={size}
				variant={variant}
				onClose={handleClose}
				enableCloseButton={enableCloseButton}
				isLoading={loading}
				isSaving={saving}
				enableCloseBackdrop
				enableAnimation={enableAnimation}
			>
				<Document size={size}>
					<DocumentHeader>
						<span>Document Header</span>
					</DocumentHeader>
					<DocumentBody>
						<div>
							<SelectInput
								value={size}
								onChange={setSize}
								options={sizeOptions}
								nullable={false}
							/>
						</div>
						<div>{rows}</div>
					</DocumentBody>
					{enableCloseButton ? null : (
						<DocumentFooter>
							<ButtonGroup>
								<Button
									color="primary"
									variant="fill"
									disabled={loading || saving}
									onClick={handleSave}
								>
									Save
								</Button>
								<Button
									color="primary"
									variant="opaque"
									disabled={saving}
									onClick={handleClose}
								>
									Cancel
								</Button>
							</ButtonGroup>
						</DocumentFooter>
					)}
				</Document>
			</Dialog>
		</Scope>
	);
}
