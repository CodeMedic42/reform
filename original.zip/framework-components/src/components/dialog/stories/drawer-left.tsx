// @ts-nocheck
import React from 'react';
import renderSizes from './common';

function example() {
	return (
		<>
			{renderSizes('Basic', 'drawer-left', false)}
			{renderSizes('Large Body', 'drawer-left', true)}
			{renderSizes('Close Button', 'drawer-left', false, true)}
		</>
	);
}

example.story = {
	name: 'Drawer Left',
};

export default example;
