// @ts-nocheck
import React from 'react';
import renderSizes from './common';

function example() {
	return (
		<>
			{renderSizes('Basic', 'drawer-right', false)}
			{renderSizes(
				'Basic enable animation',
				'drawer-right',
				false,
				false,
				true,
			)}
			{renderSizes('Large Body', 'drawer-right', true)}
			{renderSizes('Close Button', 'drawer-right', false, true)}
		</>
	);
}

example.story = {
	name: 'Drawer Right',
};

export default example;
