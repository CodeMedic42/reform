// @ts-nocheck
import React from 'react';
import renderSizes from './common';

function example() {
	return (
		<>
			{renderSizes('Basic', 'modal', false)}
			{renderSizes('Large Body', 'modal', true)}
			{renderSizes('Close Button', 'modal', false, true)}
		</>
	);
}

example.story = {
	name: 'Modal',
};

export default example;
