// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import Button from '../button';
import Document from './document';
import DocumentBody from './document-body';
import DocumentHeader from './document-header';
import ButtonGroup from '../button-group';
import { Text, Heading } from '../typography';

class DeleteItemDocument extends PureComponent {
	render() {
		const {
			size,
			itemName,
			headerText,
			disabled,
			handleDelete,
			handleCancel,
		} = this.props;

		return (
			<Document className="delete-item-document" size={size}>
				<DocumentHeader enableDivider>
					<Heading level="5">{headerText}</Heading>
				</DocumentHeader>
				<DocumentBody className="delete-item-drawer-body">
					<Text
						className="delete-message"
						weight="bold"
						applyMargin
						size="lg"
					>
						Are you sure?
					</Text>
					<Text className="delete-message" size="lg">
						{'Once '}
						<Text weight="bold">{itemName}</Text>
						{' is deleted, you can’t undo it.'}
					</Text>
					<ButtonGroup className="delete-button-group">
						<Button
							id="deleteItemDelete"
							color="danger"
							variant="fill"
							disabled={disabled}
							onClick={handleDelete}
						>
							Delete
						</Button>
						<Button
							id="deleteItemCancel"
							color="secondary"
							variant="opaque"
							disabled={disabled}
							onClick={handleCancel}
						>
							Cancel
						</Button>
					</ButtonGroup>
				</DocumentBody>
			</Document>
		);
	}
}

DeleteItemDocument.propTypes = {
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	headerText: PropTypes.string.isRequired,
	itemName: PropTypes.string.isRequired,
	handleDelete: PropTypes.func.isRequired,
	handleCancel: PropTypes.func.isRequired,
	disabled: PropTypes.bool,
};

DeleteItemDocument.defaultProps = {
	size: 'lg',
	disabled: false,
};

export default DeleteItemDocument;
