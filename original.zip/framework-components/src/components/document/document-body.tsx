// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

class DocumentBody extends PureComponent {
	render() {
		const { className, children } = this.props;

		return (
			<div className={classnames('ai-document-body', className)}>
				{children}
			</div>
		);
	}
}

DocumentBody.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

DocumentBody.defaultProps = {
	className: null,
	children: null,
};

export default DocumentBody;
