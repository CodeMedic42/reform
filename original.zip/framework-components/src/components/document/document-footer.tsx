// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

class DocumentFooter extends PureComponent {
	render() {
		const { className, sticky, children } = this.props;

		return (
			<>
				{sticky ? <div className="gradient-cover" /> : null}
				<div
					className={classnames('ai-document-footer', className, {
						sticky,
					})}
				>
					{children}
				</div>
			</>
		);
	}
}

DocumentFooter.propTypes = {
	className: PropTypes.string,
	sticky: PropTypes.bool,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

DocumentFooter.defaultProps = {
	className: null,
	sticky: true,
	children: null,
};

export default DocumentFooter;
