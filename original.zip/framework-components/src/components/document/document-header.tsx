// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

class DocumentHeader extends PureComponent {
	render() {
		const { className, enableDivider, children } = this.props;

		return (
			<div
				className={classnames('ai-document-header', className, {
					divider: enableDivider,
				})}
			>
				{children}
			</div>
		);
	}
}

DocumentHeader.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	enableDivider: PropTypes.bool,
};

DocumentHeader.defaultProps = {
	className: null,
	children: null,
	enableDivider: false,
};

export default DocumentHeader;
