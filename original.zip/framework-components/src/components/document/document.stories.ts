// @ts-nocheck
import Document from './document';

export default {
	title: 'Layout/Document',
	component: Document,
};

export { default as sizes } from './stories/sizes';
export { default as deleteItemDocument } from './stories/delete-item-document';
