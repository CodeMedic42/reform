// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';

class Document extends PureComponent {
	render() {
		const { className, size, children } = this.props;

		if (isNil(size)) {
			return null;
		}

		const sizeClass = `size-${size}`;

		return (
			<div className={classnames('ai-document', sizeClass, className)}>
				{children}
			</div>
		);
	}
}

Document.propTypes = {
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']).isRequired,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

Document.defaultProps = {
	className: null,
	children: null,
};

export default Document;
