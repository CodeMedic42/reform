// @ts-nocheck
import Document from './document';
import DocumentHeader from './document-header';
import DocumentBody from './document-body';
import DocumentFooter from './document-footer';
import DeleteItemDocument from './delete-item-document';

export default Document;

export { DocumentHeader, DocumentBody, DocumentFooter, DeleteItemDocument };
