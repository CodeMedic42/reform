/* eslint-disable no-console */
// @ts-nocheck
import React from 'react';
import Dialog from '../../dialog';
import DeleteItemDocument from '../delete-item-document';
import Scope from '../../../../.storybook/components/scope';

function onDeleteClick() {
	console.log('Delete clicked');
}

function onCancelClick() {
	console.log('Cancel clicked');
}

function example() {
	return (
		<Scope title="Delete item document in a dialog">
			<Dialog open variant="drawer-right" size="lg">
				<DeleteItemDocument
					size="lg"
					headerText="Delete Filter"
					itemName="Patient Filter"
					handleDelete={onDeleteClick}
					handleCancel={onCancelClick}
				/>
			</Dialog>
		</Scope>
	);
}

example.story = {
	name: 'Delete Item Document',
};

export default example;
