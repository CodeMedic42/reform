// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Document from '..';
import DocumentHeader from '../document-header';
import DocumentBody from '../document-body';
import DocumentFooter from '../document-footer';
import Scope from '../../../../.storybook/components/scope';

const sizes = ['xs', 'sm', 'md', 'lg', 'xl'];

function renderModalSizeScope(size) {
	return (
		<Scope key={size} title={size} SpecimenContainer={null}>
			<Document size={size}>
				<DocumentHeader>
					<div
						style={{
							height: '50px',
							border: 'solid 1px black',
						}}
					/>
				</DocumentHeader>
				<DocumentBody>
					<div
						style={{
							height: '50px',
							border: 'solid 1px black',
						}}
					/>
				</DocumentBody>
				<DocumentFooter>
					<div
						style={{
							height: '50px',
							border: 'solid 1px black',
						}}
					/>
				</DocumentFooter>
			</Document>
		</Scope>
	);
}

function example() {
	return <>{map(sizes, (size) => renderModalSizeScope(size))}</>;
}

example.story = {
	name: 'Sizes',
};

export default example;
