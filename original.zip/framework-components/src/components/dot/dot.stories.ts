// @ts-nocheck
import Dot from '.';

export default {
	title: 'Labeling/Dot',
	component: Dot,
};

export { default as preview } from './stories/preview';
export { default as colors } from './stories/colors';
