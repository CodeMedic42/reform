// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { paletteColorPropType } from '../../common/color-list';

class Dot extends PureComponent {
	render() {
		const { id, className, color } = this.props;

		return (
			<span
				id={id}
				className={classnames(
					'ai-dot',
					`plt-${color}`,
					'plt-light',
					'ai-palette',
					'plt-bg',
					className,
				)}
			/>
		);
	}
}

Dot.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	color: paletteColorPropType.isRequired,
};

Dot.defaultProps = {
	id: null,
	className: null,
};

export default Dot;
