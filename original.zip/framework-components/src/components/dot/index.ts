// @ts-nocheck
import Dot from './dot';

export default Dot;
