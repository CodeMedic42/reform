// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Scope from '../../../../.storybook/components/scope';
import Dot from '..';
import { paletteColorOrder } from '../../../common/color-list';
import { Row, Column } from '../../grid';

function example() {
	return (
		<Scope title="Colors">
			<Row gutter>
				{map(paletteColorOrder, (color) => (
					<Column key={color} width="content">
						<Dot color={color} />
					</Column>
				))}
			</Row>
		</Scope>
	);
}

example.story = {
	name: 'Colors',
};

export default example;
