// @ts-nocheck
import React from 'react';
import { paletteColorOrder } from '../../../common/color-list';
import Scope from '../../../../.storybook/components/scope';
import Dot from '..';

function example(props) {
	return (
		<Scope fillViewport>
			<Dot {...props} />
		</Scope>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		color: {
			options: paletteColorOrder,
			control: { type: 'select' },
			description:
				'The scheme colors. pallette colors are not supported. If not set with inherit the scheme of its parent elements.',
		},
	},
};

export default example;
