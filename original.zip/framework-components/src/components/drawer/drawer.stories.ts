// @ts-nocheck
import Drawer from './drawer';

export default {
	title: 'Layout/Drawer',
	component: Drawer,
};

export { default as preview } from './stories/preview';
