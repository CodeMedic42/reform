// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Dialog from '../dialog-base';

function Drawer(props) {
	const { className, variant, disableBackdrop } = props;

	return (
		<Dialog
			{...props}
			className={classnames(
				'ai-drawer',
				`ai-drawer-${variant}`,
				className,
			)}
			backdropVariant={disableBackdrop ? 'none' : 'lite'}
			spinnerSize="lg"
			spinnerAlignment="lg"
		/>
	);
}

Drawer.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	open: PropTypes.bool,
	variant: PropTypes.oneOf(['left', 'right']).isRequired,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	onClose: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onCloseMeta: PropTypes.object,
	enableCloseButton: PropTypes.bool,
	enableCloseOnOffClick: PropTypes.oneOfType([
		PropTypes.bool,
		PropTypes.arrayOf(PropTypes.string),
	]),
	disableBackdrop: PropTypes.bool,
	// Set to true while data is being retrieved to display in the dialog
	isLoading: PropTypes.bool,
	// Set to true while data entered on the dialog is being saved
	isSaving: PropTypes.bool,
	enableAnimation: PropTypes.bool,
};

Drawer.defaultProps = {
	id: null,
	className: null,
	open: false,
	children: null,
	onClose: null,
	onCloseMeta: null,
	enableCloseButton: false,
	enableCloseOnOffClick: false,
	isLoading: false,
	isSaving: false,
	enableAnimation: false,
	disableBackdrop: false,
	size: 'md',
};

export default Drawer;
