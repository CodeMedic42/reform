// @ts-nocheck
import React, { useState, useCallback } from 'react';
import isNil from 'lodash-es/isNil';
import split from 'lodash-es/split';
import PropTypes from 'prop-types';
import Scope from '../../../../.storybook/components/scope';
import Drawer from '..';
import { Container, Column, Row } from '../../grid';
import TextInput from '../../text-input';
import SelectInput from '../../select-input';
import Button from '../../button';
import Document from '../../document';
import DocumentHeader from '../../document/document-header';
import DocumentBody from '../../document/document-body';
import DocumentFooter from '../../document/document-footer';
import ButtonGroup from '../../button-group';
import ActionSelector from '../../action-selector';
import { textOnly } from '../../../common/storybook/options-data';

function DrawerDocument(props) {
	const { size, children, onClose } = props;

	return (
		<Document size={size}>
			<DocumentHeader>
				<span>Document Header</span>
			</DocumentHeader>
			<DocumentBody>{children}</DocumentBody>
			<DocumentFooter>
				<ButtonGroup>
					<Button color="primary" variant="fill" onClick={onClose}>
						Save
					</Button>
					<Button color="primary" variant="opaque" onClick={onClose}>
						Cancel
					</Button>
				</ButtonGroup>
			</DocumentFooter>
		</Document>
	);
}

DrawerDocument.propTypes = {
	size: PropTypes.string.isRequired,
	// eslint-disable-next-line react/forbid-prop-types
	children: PropTypes.any,
	onClose: PropTypes.func,
};

DrawerDocument.defaultProps = {
	children: null,
	onClose: null,
};

const actionOptions = ['Received Time', 'Event Time'];

function example(props) {
	const { size, enableCloseOnOffClick, enableCloseOnOffClickValue, ...rest } =
		props;

	let enableCloseOnOffClickFinalValue;

	if (enableCloseOnOffClick) {
		enableCloseOnOffClickFinalValue =
			!isNil(enableCloseOnOffClickValue) &&
			enableCloseOnOffClickValue.length > 0
				? split(enableCloseOnOffClickValue, ',')
				: true;
	}

	const [value, setValue] = useState(null);
	const [selectValue, setSelectValue] = useState(null);
	const [actionValue, setActionValue] = useState('Event Time');
	const [open, setOpen] = useState(false);
	const [useDocument, setUseDocument] = useState(false);

	const handleSetOpen = useCallback(() => {
		setUseDocument(false);
		setOpen(true);
	});

	const handleSetOpenWithDocument = useCallback(() => {
		setOpen(true);
		setUseDocument(true);
	});

	const handleSetClose = useCallback(() => {
		setOpen(false);
	});

	let content = (
		<Row gutter>
			<Column>
				<SelectInput
					label="Select your favorite doughnut"
					placeholder="Placeholder"
					value={selectValue}
					options={textOnly}
					onChange={setSelectValue}
				/>
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<ActionSelector
					value={actionValue}
					options={actionOptions}
					onChange={setActionValue}
				/>
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
			<Column>
				<TextInput value={value} onChange={setValue} />
			</Column>
		</Row>
	);

	content = useDocument ? (
		<DrawerDocument size={size} onClose={handleSetClose}>
			{content}
		</DrawerDocument>
	) : (
		<Container sideGutter topGutter bottomGutter>
			<Row gutter>
				<Column>
					<SelectInput
						label="Select your favorite doughnut"
						placeholder="Placeholder"
						value={selectValue}
						options={textOnly}
						onChange={setSelectValue}
					/>
				</Column>
				<Column>
					<TextInput value={value} onChange={setValue} />
				</Column>
			</Row>
		</Container>
	);

	return (
		<>
			<Scope fillViewport>
				<Row gutter>
					<Column width="content">
						<Button onClick={handleSetOpen}>Open</Button>
					</Column>
					<Column width="content">
						<Button onClick={handleSetOpenWithDocument}>
							Open with Document
						</Button>
					</Column>
				</Row>
				<Row gutter>
					<Column>
						<TextInput value={value} onChange={setValue} />
					</Column>
				</Row>
				<Drawer
					{...rest}
					size={size}
					open={open}
					enableCloseOnOffClick={enableCloseOnOffClickFinalValue}
					onClose={handleSetClose}
				>
					{content}
				</Drawer>
			</Scope>
			<div>
				<div
					style={{ height: '100px', backgroundColor: 'lightblue' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightgreen' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightpink' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightyellow' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightblue' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightgreen' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightpink' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightyellow' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightblue' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightgreen' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightpink' }}
				/>
				<div
					style={{ height: '100px', backgroundColor: 'lightyellow' }}
				/>
			</div>
		</>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		variant: {
			options: ['left', 'right'],
			control: { type: 'select' },
		},
		size: {
			options: ['xs', 'sm', 'md', 'lg', 'xl'],
			control: { type: 'select' },
		},
		open: { table: { disable: true } },
		children: { table: { disable: true } },
		onClose: { table: { disable: true } },
		onCloseMeta: { table: { disable: true } },
		enableCloseButton: {
			control: 'boolean',
		},
		enableCloseOnOffClick: {
			control: 'boolean',
		},
		enableCloseOnOffClickValue: {
			control: 'text',
			if: { arg: 'enableCloseOnOffClick', truthy: true },
			description:
				'THIS IS NOT A PROP BUT JUST A WAY TO CHANGE THE VALUE OF enableCloseOnOffClick. If no value given then will result in true value. As an example try this ".ai-btn,.ai-input"',
		},
		disableBackdrop: {
			control: 'boolean',
		},
		isLoading: {
			control: 'boolean',
		},
		isSaving: {
			control: 'boolean',
		},
		enableAnimation: {
			control: 'boolean',
		},
	},
	args: {
		variant: 'right',
		size: 'md',
		enableCloseButton: false,
		enableCloseOnOffClick: false,
		enableCloseOnOffClickValue: undefined,
		disableBackdrop: false,
		isLoading: false,
		isSaving: false,
		enableAnimation: false,
	}
};

export default example;
