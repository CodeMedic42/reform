/* eslint-disable jsx-a11y/no-static-element-interactions */
// @ts-nocheck
import React, { PureComponent, createRef, forwardRef } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import isFunction from 'lodash-es/isFunction';

function getTarget(rootElement, selector) {
	return !isNil(selector)
		? rootElement.querySelector(selector)
		: rootElement.firstElementChild;
}

class AnchorBinding extends PureComponent {
	constructor(props) {
		super(props);

		this.anchorRef = createRef();

		this.getBoundingElement = this.getBoundingElement.bind(this);
		this.contains = this.contains.bind(this);
		this.focus = this.focus.bind(this);
	}

	getBoundingElement() {
		const { boundingTargetSelector } = this.props;

		return getTarget(this.anchorRef.current, boundingTargetSelector);
	}

	contains(element) {
		this.anchorRef.current.contains(element);
	}

	focus() {
		const { focusTargetSelector } = this.props;

		const focusTarget = getTarget(
			this.anchorRef.current,
			focusTargetSelector,
		);

		focusTarget.focus();
	}

	render() {
		const {
			AnchorComponent,
			bindingInterface: {
				onClick,
				onFocus,
				onBlur,
				onKeyPress,
				onKeyDown,
				onPointerEnter,
				onPointerLeave,
				onPointerCancel,
			},
			children,
			boundingTargetSelector,
			focusTargetSelector,
			...rest
		} = this.props;

		return (
			<div
				ref={this.anchorRef}
				className={classnames('anchor-binding')}
				tabIndex="-1"
				onClick={onClick}
				onFocus={onFocus}
				onBlur={onBlur}
				onKeyPress={onKeyPress}
				onKeyDown={onKeyDown}
				onPointerEnter={onPointerEnter}
				onPointerLeave={onPointerLeave}
				onPointerCancel={onPointerCancel}
			>
				<AnchorComponent {...rest}>{children}</AnchorComponent>
			</div>
		);
	}
}

AnchorBinding.propTypes = {
	bindingInterface: PropTypes.shape({
		onClick: PropTypes.func,
		onFocus: PropTypes.func,
		onBlur: PropTypes.func,
		onKeyPress: PropTypes.func,
		onKeyDown: PropTypes.func,
		onPointerEnter: PropTypes.func,
		onPointerLeave: PropTypes.func,
		onPointerCancel: PropTypes.func,
	}).isRequired,
	AnchorComponent: PropTypes.elementType.isRequired,
	boundingTargetSelector: PropTypes.string,
	focusTargetSelector: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

AnchorBinding.defaultProps = {
	children: null,
	boundingTargetSelector: null,
	focusTargetSelector: null,
};

function applyAnchorBinding(
	AnchorComponent,
	{ focusSelector, boundingSelector, displayName } = {},
) {
	let focusSelectorLookup = focusSelector;
	let boundingSelectorLookup = boundingSelector;

	if (!isFunction(focusSelector)) {
		focusSelectorLookup = () => focusSelector;
	}

	if (!isFunction(boundingSelector)) {
		boundingSelectorLookup = () => boundingSelector;
	}

	const Anchor = forwardRef((props, ref) => {
		// eslint-disable-next-line react/prop-types
		const { children, ...rest } = props;

		return (
			<AnchorBinding
				{...rest}
				ref={ref}
				AnchorComponent={AnchorComponent}
				boundingTargetSelector={boundingSelectorLookup(rest)}
				focusTargetSelector={focusSelectorLookup(rest)}
			>
				{children}
			</AnchorBinding>
		);
	});

	if (!isNil(displayName)) {
		Anchor.displayName = displayName;
	}

	Anchor.isAnchorBinding = true;

	return Anchor;
}

export default applyAnchorBinding;
