// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { faAngleUp } from '@audacious/icons/solid/faAngleUp';
import { faAngleDown } from '@audacious/icons/solid/faAngleDown';
import Chip from '../chip';
import Icon from '../icon';
import { selectChipIconSize } from '../chip/utils';
import applyAnchorBinding from './anchor-binding';

class AnchorChip extends PureComponent {
	render() {
		const {
			className,
			open,
			hideArrow,
			size,
			onClick,
			onClickMeta,
			children,
			...rest
		} = this.props;

		const arrow = !hideArrow ? (
			<Icon
				icon={open ? faAngleUp : faAngleDown}
				{...selectChipIconSize(false, size)}
			/>
		) : null;

		return (
			<Chip
				{...rest}
				className={classnames(className, {
					focus: open,
				})}
				type="button"
				size={size}
				onClick={onClick}
				onClickMeta={onClickMeta}
				asButton
			>
				<span>{children}</span>
				{arrow}
			</Chip>
		);
	}
}

AnchorChip.propTypes = {
	className: PropTypes.string,
	open: PropTypes.bool.isRequired,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	hideArrow: PropTypes.bool,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
};

AnchorChip.defaultProps = {
	className: null,
	children: null,
	hideArrow: false,
	size: null,
	onClick: null,
	onClickMeta: null,
};

export default applyAnchorBinding(AnchorChip);
