// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import IconButton from '../icon-button';
import applyAnchorBinding from './anchor-binding';

class AnchorIconButton extends PureComponent {
	render() {
		const { className, open, children, ...rest } = this.props;

		return (
			<IconButton
				{...rest}
				className={classnames(className, {
					focus: open,
				})}
			>
				{children}
			</IconButton>
		);
	}
}

AnchorIconButton.propTypes = {
	className: PropTypes.string,
	open: PropTypes.bool.isRequired,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

AnchorIconButton.defaultProps = {
	className: null,
	children: null,
};

export default applyAnchorBinding(AnchorIconButton, {
	boundingSelector: ({ alignToIcon }) =>
		alignToIcon ? '.ai-icon-btn > .border-target' : null,
});
