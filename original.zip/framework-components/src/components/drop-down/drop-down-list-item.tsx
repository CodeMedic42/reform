/* eslint-disable jsx-a11y/click-events-have-key-events */
// @ts-nocheck
import React, { createRef, PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import {
	schemeColorPropType,
	getSchemeColorClasses,
} from '../../common/color-list';

class DropDownListItem extends PureComponent {
	constructor(...args) {
		super(...args);

		this.itemRef = createRef();

		this.handleMouseEnter = this.handleMouseEnter.bind(this);
		this.handleMouseLeave = this.handleMouseLeave.bind(this);
		this.handleClick = this.handleClick.bind(this);

		this.state = {};
	}

	handleMouseEnter(event) {
		const { onMouseEnter, onMouseEnterMeta } = this.props;

		if (isNil(onMouseEnter)) {
			return;
		}

		onMouseEnter({
			event,
			meta: onMouseEnterMeta,
		});
	}

	handleMouseLeave(event) {
		const { onMouseLeave, onMouseLeaveMeta } = this.props;

		if (isNil(onMouseLeave)) {
			return;
		}

		onMouseLeave({
			event,
			meta: onMouseLeaveMeta,
		});
	}

	handleClick(event) {
		const { onClick, preventCloseOnClick } = this.props;

		if (preventCloseOnClick) {
			event.preventDefault();
		}

		if (!isNil(onClick)) {
			onClick(event);
		}
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	getRootNode() {
		return this.itemRef.current;
	}

	render() {
		const {
			id,
			color,
			className,
			selected,
			targeted,
			children,
			'aria-label': ariaLabel,
			borderBottom,
			borderTop,
		} = this.props;

		const ariaCurrent = targeted ? ariaLabel : null;

		let accessibilityLabel = ariaLabel;

		if (selected) {
			accessibilityLabel = !isNil(accessibilityLabel)
				? `${accessibilityLabel}, Selected`
				: 'Selected';
		}

		const colorClasses = getSchemeColorClasses({
			color,
			style: 'opaque',
		});

		return (
			<li
				ref={this.itemRef}
				id={id}
				className={classnames(
					'ai-dd-list-item',
					className,
					colorClasses,
					{
						selected,
						targeted,
						'border-bottom': borderBottom,
						'border-top': borderTop,
					},
				)}
				role="option" // TODO: Review how this is not clickable anymore
				aria-selected={selected || false}
				aria-current={ariaCurrent}
				aria-label={accessibilityLabel}
				onMouseEnter={this.handleMouseEnter}
				onMouseLeave={this.handleMouseLeave}
				onClick={this.handleClick}
			>
				{children}
			</li>
		);
	}
}

DropDownListItem.propTypes = {
	id: PropTypes.string,
	color: schemeColorPropType,
	className: PropTypes.string,
	selected: PropTypes.bool,
	targeted: PropTypes.bool,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	'aria-label': PropTypes.string,
	onMouseEnter: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onMouseEnterMeta: PropTypes.any,
	onMouseLeave: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onMouseLeaveMeta: PropTypes.any,
	borderBottom: PropTypes.bool,
	borderTop: PropTypes.bool,
	onClick: PropTypes.func,
	preventCloseOnClick: PropTypes.bool,
};

DropDownListItem.defaultProps = {
	id: null,
	className: null,
	color: null,
	children: null,
	'aria-label': null,
	selected: false,
	targeted: false,
	onMouseEnter: null,
	onMouseEnterMeta: null,
	onMouseLeave: null,
	onMouseLeaveMeta: null,
	borderBottom: false,
	borderTop: false,
	onClick: null,
	preventCloseOnClick: false,
};

export default DropDownListItem;
