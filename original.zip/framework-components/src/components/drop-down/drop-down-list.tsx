// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import scrollIntoView from 'scroll-into-view-if-needed';

function scrollTo(listElement, targetIndex) {
	const optionElement = listElement.childNodes[targetIndex];

	if (isNil(optionElement)) {
		return;
	}

	scrollIntoView(optionElement, {
		scrollMode: 'always',
		block: 'center',
		inline: 'center',
		boundary: listElement,
	});
}

class DropDownList extends React.Component {
	constructor(...args) {
		super(...args);

		this.listRef = React.createRef();
		this.handleWheel = this.handleWheel.bind(this);
	}

	componentDidMount() {
		this.listRef.current.addEventListener('wheel', this.handleWheel, {
			passive: false,
			capture: false,
		});
	}

	componentWillUnmount() {
		this.listRef.current.removeEventListener('wheel', this.handleWheel);
	}

	// This method constrains the mouse wheel events to only this element.
	// If the wheel is at the bottom when scrolling down then normally a browser will continue the scroll with a high parent.
	// The purpose of the component is to be used inside the drop down component in the tray.
	// While the tray is open I don't want to scroll anywhere except the tray.
	// This method will prevent that scrolling.
	handleWheel(event) {
		const { deltaY, deltaX } = event;

		const {
			scrollTop,
			scrollLeft,
			scrollHeight,
			scrollWidth,
			clientHeight,
			clientWidth,
		} = this.listRef.current;

		event.stopPropagation();

		let stop = false;

		if (deltaY < 0) {
			stop = scrollTop <= 0;
		} else if (deltaY > 0) {
			stop = scrollTop + clientHeight >= scrollHeight;
		}

		if (deltaX < 0) {
			stop = scrollLeft <= 0;
		} else if (deltaX > 0) {
			stop = scrollLeft + clientWidth >= scrollWidth;
		}

		if (stop) {
			event.preventDefault();
		}
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	getRootNode() {
		return this.listRef.current;
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	scrollToIndex(index) {
		scrollTo(this.listRef.current, index);
	}

	render() {
		const {
			id,
			className,
			dark,
			children,
			size,
			'aria-labelledby': ariaLabeledBy,
		} = this.props;

		const sizeClass = !isNil(size) ? `size-${size}` : 'size-md';

		return (
			<ol
				ref={this.listRef}
				id={id}
				className={classnames('ai-dd-list', className, sizeClass, {
					dark,
				})}
				role="listbox"
				aria-labelledby={ariaLabeledBy}
			>
				{children}
			</ol>
		);
	}
}

DropDownList.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	dark: PropTypes.bool,
	size: PropTypes.oneOf(['2xs', 'xs', 'sm', 'md', 'lg']),
	'aria-labelledby': PropTypes.string,
};

DropDownList.defaultProps = {
	id: null,
	className: null,
	children: null,
	dark: false,
	size: 'md',
	'aria-labelledby': null,
};

export default DropDownList;
