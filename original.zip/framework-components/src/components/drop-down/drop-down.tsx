/* eslint-disable jsx-a11y/no-static-element-interactions */
// @ts-nocheck
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import noop from 'lodash-es/noop';
import get from 'lodash-es/get';
import debounce from 'lodash-es/debounce';
import Tray from '../tray';
import Provider from './drop-down-context';

class DropDown extends Component {
	constructor(...args) {
		super(...args);

		this.mainRef = React.createRef();
		this.anchorRef = React.createRef();
		this.trayRef = React.createRef();

		this.handleButtonKeyPress = this.handleButtonKeyPress.bind(this);
		this.handleButtonClick = this.handleButtonClick.bind(this);
		this.handleTrayClick = this.handleTrayClick.bind(this);
		this.handleWindowEvent = debounce(
			this.handleWindowEvent.bind(this),
			200,
			{
				leading: true,
				trailing: false,
			},
		);
		this.handleWindowKeyDown = this.handleWindowKeyDown.bind(this);
		this.handleButtonFocus = this.handleButtonFocus.bind(this);
		this.handleBlur = this.handleBlur.bind(this);
		this.handleKeyUp = this.handleKeyUp.bind(this);
		// The debounce here is because there are a lot of different events trying to open and close the tray.
		// It is getting hard to manage them all. Most utilize the current state of the tray to determine what to do.
		// But if one event closes the tray and then another right after it sees the tray closed in the state it will open it back up.
		// The user will see a flicker and then tray never closes.
		// So within a span of 200 milliseconds the first event to fire will close it and then all others will get ignored.
		// There are edge cases here that can happen but I am too tired to try to smooth them out and they require the user to
		// do things like click and hold the mouse for more than 200 milliseconds on the select button.
		this.setOpen = debounce(this.setOpen.bind(this), 200, {
			leading: true,
			trailing: false,
		});
		this.focus = this.focus.bind(this);
		this.getAnchorElement = this.getAnchorElement.bind(this);
		this.handleKeyDown = this.handleKeyDown.bind(this);
		this.handleAnchorPointerEnter =
			this.handleAnchorPointerEnter.bind(this);
		this.handleAnchorPointerLeave =
			this.handleAnchorPointerLeave.bind(this);

		this.state = {
			open: false,
			openFromHover: false,
			openFromHoverTimer: null,
			autoCloseTimer: null,
			openFromFocus: false,
		};
	}

	componentDidMount() {
		window.addEventListener('scroll', this.handleWindowEvent, true);
		window.addEventListener('resize', this.handleWindowEvent);
	}

	componentWillUnmount() {
		const { autoCloseTimer, openFromHoverTimer } = this.state;

		if (autoCloseTimer) {
			clearTimeout(autoCloseTimer);
		}

		if (openFromHoverTimer) {
			clearTimeout(openFromHoverTimer);
		}

		if (!isNil(this.controlTimer)) {
			clearTimeout(this.controlTimer);

			this.controlTimer = null;
		}

		window.removeEventListener('scroll', this.handleWindowEvent, true);
		window.removeEventListener('resize', this.handleWindowEvent);
	}

	handleWindowEvent(event) {
		const { open } = this.state;

		if (!open) {
			return;
		}

		if (
			event.target.nodeType === 1 &&
			this.trayRef.current.contains(event.target)
		) {
			return;
		}

		this.setOpen(false);

		this.focusOnAnchorContent();
	}

	handleWindowKeyDown(event) {
		// This handler will prevent arrow keys from causing a scroll event from happening while the tray is open.
		const { open } = this.state;

		// arrow keys
		if (open && [37, 38, 39, 40].indexOf(event.keyCode) > -1) {
			event.preventDefault();
		}
	}

	handleButtonKeyPress(event) {
		const { openOnClick } = this.props;

		if (openOnClick && event.which === 13) {
			// enter key
			event.preventDefault();
		}
	}

	handleButtonClick(event) {
		if (event.defaultPrevented) {
			return;
		}

		const { openOnClick, onAnchorClick } = this.props;
		const { open } = this.state;

		if (!isNil(onAnchorClick)) {
			onAnchorClick({ event });
		}

		if (openOnClick) {
			this.setOpen(!open);
		}
	}

	handleTrayClick(event) {
		const { closeTrayOnClick } = this.props;

		if (closeTrayOnClick && !event.defaultPrevented) {
			this.setOpen(false);

			this.focusOnAnchorContent();
		}
	}

	handleKeyUp() {
		this.keyOnce = false;
	}

	handleKeyDown(event) {
		if (this.keyOnce) {
			return;
		}

		this.keyOnce = true;

		if (event.defaultPrevented) {
			return;
		}

		const { closeTrayOnEnter } = this.props;

		const { open } = this.state;

		if (open) {
			if (
				event.which === 27 || // Escape key
				(closeTrayOnEnter && event.which === 13) // Enter key
			) {
				// Escape key
				this.setOpen(false);

				this.focusOnAnchorContent();
			} else if (
				event.which === 40 || // down arrow
				event.which === 38 // up arrow
			) {
				// prevent scroll.
				event.preventDefault();
			}
		} else if (
			event.which === 13 || // Enter Key
			event.which === 40 // down arrow
		) {
			// open tray
			this.setOpen(true);
			event.preventDefault();
		}
	}

	handleButtonFocus() {
		const { onFocus, openOnFocus } = this.props;

		if (openOnFocus) {
			this.setState({ openFromFocus: true });
		}

		if (isNil(onFocus)) {
			return;
		}

		const { open } = this.state;

		if (open) {
			return;
		}

		this.controlTimer = setTimeout(() => {
			this.controlTimer = null;

			onFocus();
		}, 1);
	}

	handleBlur(event) {
		const { currentTarget, relatedTarget } = event;

		if (
			this.trayRef.current.contains(relatedTarget) ||
			currentTarget.contains(relatedTarget)
		) {
			return;
		}

		this.setOpen(false);

		const { onBlur } = this.props;

		if (isNil(onBlur)) {
			return;
		}

		onBlur(event);
	}

	handleAnchorPointerEnter() {
		const { hoverOpenTime, openOnHover, disabled } = this.props;

		if (disabled) {
			return;
		}

		if (openOnHover) {
			const openTimer = setTimeout(() => {
				this.setState({ openFromHover: true });
			}, hoverOpenTime);

			this.setState({ openFromHoverTimer: openTimer });
		}
	}

	handleAnchorPointerLeave() {
		const { openFromHoverTimer } = this.state;

		if (!isNil(openFromHoverTimer)) {
			clearTimeout(openFromHoverTimer);

			this.setState({ openFromHoverTimer: null });
		}

		this.setState({ openFromHover: false });
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	getRootNode() {
		return this.mainRef.current;
	}

	getAnchorElement() {
		if (isNil(this.anchorRef.current)) {
			return null;
		}

		return this.anchorRef.current.getBoundingElement();
	}

	setOpen(open) {
		const { disabled, onOpen, onClose, autoClose, autoCloseTime } =
			this.props;

		const { autoCloseTimer } = this.state;

		if (disabled) {
			return;
		}

		const { open: current } = this.state;

		if (current === open) {
			return;
		}

		if (open) {
			if (!isNil(onOpen)) {
				// If we are opening and we have a callback function
				onOpen();
			}
		} else if (!isNil(onClose)) {
			// If we are closing and we have a callback function
			onClose();
		}

		let newAutoCloseTimer = null;

		if (autoClose) {
			if (autoCloseTimer) {
				clearTimeout(autoCloseTimer);
			}
			if (open) {
				newAutoCloseTimer = setTimeout(() => {
					this.setOpen(false);
				}, autoCloseTime);
			}
		}

		this.setState({
			open,
			autoCloseTimer: newAutoCloseTimer,
		});
	}

	focusOnAnchorContent() {
		const focus = get(this.anchorRef, ['current', 'focus']);

		if (isNil(focus)) {
			return;
		}

		focus();
	}

	focus() {
		const { disabled } = this.props;

		if (disabled) {
			return;
		}

		if (isNil(this.anchorRef) || isNil(this.anchorRef.current)) {
			// eslint-disable-next-line no-console
			console.warn('Attempting to focus on an unmounted component');
		}

		this.focusOnAnchorContent();

		this.setOpen(true);
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	isOpen() {
		const { open } = this.state;

		return open;
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	close(focusOnAnchor) {
		this.setOpen(false);

		if (focusOnAnchor) {
			this.focusOnAnchorContent();
		}
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	open() {
		this.setOpen(true);
	}

	renderMainControl() {
		const { Anchor, anchorProps, onKeyDown, openOnHover } = this.props;

		const { open } = this.state;

		const { children, ...rest } = !isNil(anchorProps) ? anchorProps : {};

		if (isNil(Anchor)) {
			throw new Error('Need Anchor');
		}

		return (
			<Anchor
				{...rest}
				open={open}
				ref={this.anchorRef}
				bindingInterface={{
					onClick: this.handleButtonClick,
					onFocus: this.handleButtonFocus,
					onKeyPress: this.handleButtonKeyPress,
					onKeyDown,
					onPointerEnter: openOnHover
						? this.handleAnchorPointerEnter
						: null,
					onPointerLeave: openOnHover
						? this.handleAnchorPointerLeave
						: null,
					onPointerCancel: openOnHover
						? this.handleAnchorPointerLeave
						: null,
				}}
			>
				{children}
			</Anchor>
		);
	}

	render() {
		const {
			id,
			className,
			trayClassName,
			children,
			dropPositions,
			minDrawerWidth,
			maxDrawerWidth,
			maxDrawerHeight,
			horizontallyCenter,
			dockRight,
			enableTail,
			onClick,
		} = this.props;

		const { open, openFromHover, openFromFocus } = this.state;

		return (
			// This element should NOT show up as a valid element that can be clicked on.
			// It's sole purpose is to listen for these events coming from it's children.
			<div
				ref={this.mainRef}
				id={id}
				className={classnames('ai-drop-down', className, {
					open,
				})}
				onKeyUp={this.handleKeyUp}
				onKeyPress={this.handleButtonKeyPress}
				onKeyDown={this.handleKeyDown}
				onBlur={this.handleBlur}
				onClick={onClick}
			>
				{this.renderMainControl()}
				<Tray
					className={classnames('ai-drop-down-tray', trayClassName)}
					ref={this.trayRef}
					open={open || openFromHover || openFromFocus}
					id={!isNil(id) && id.length > 0 ? `${id}-drawer` : null}
					dropPositions={dropPositions}
					getAnchorElement={this.getAnchorElement}
					onClick={this.handleTrayClick}
					minWidth={minDrawerWidth}
					maxWidth={maxDrawerWidth}
					maxHeight={maxDrawerHeight}
					horizontallyCenter={horizontallyCenter}
					dockRight={dockRight}
					enableTail={enableTail}
				>
					<Provider value={{ open }}>{children}</Provider>
				</Tray>
			</div>
		);
	}
}

const dropPositionTypes = PropTypes.oneOf(['top', 'bottom', 'left', 'right']);

DropDown.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	trayClassName: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	'aria-labelledby': PropTypes.string,
	'aria-describedby': PropTypes.string,
	onBlur: PropTypes.func,
	onFocus: PropTypes.func,
	disabled: PropTypes.bool,
	dropPositions: PropTypes.arrayOf(dropPositionTypes),
	closeTrayOnClick: PropTypes.bool,
	closeTrayOnEnter: PropTypes.bool,
	minDrawerWidth: PropTypes.oneOfType([
		PropTypes.number,
		PropTypes.oneOf(['anchor']),
	]),
	maxDrawerWidth: PropTypes.oneOfType([
		PropTypes.number,
		PropTypes.oneOf(['anchor']),
	]),
	maxDrawerHeight: PropTypes.number,
	onOpen: PropTypes.func,
	onClose: PropTypes.func,
	onKeyDown: PropTypes.func,
	Anchor: PropTypes.elementType.isRequired,
	// eslint-disable-next-line react/forbid-prop-types
	anchorProps: PropTypes.object,
	openOnHover: PropTypes.bool,
	hoverOpenTime: PropTypes.number,
	autoClose: PropTypes.bool,
	autoCloseTime: PropTypes.number,
	openOnFocus: PropTypes.bool,
	onAnchorClick: PropTypes.func,
	openOnClick: PropTypes.bool,
	horizontallyCenter: PropTypes.bool,
	dockRight: PropTypes.bool,
	enableTail: PropTypes.bool,
	onClick: PropTypes.func,
};

DropDown.defaultProps = {
	id: null,
	className: null,
	trayClassName: null,
	children: null,
	'aria-labelledby': null,
	'aria-describedby': null,
	onBlur: noop,
	onFocus: noop,
	disabled: false,
	dropPositions: ['bottom', 'top', 'right', 'left'],
	closeTrayOnClick: true,
	closeTrayOnEnter: true,
	minDrawerWidth: null,
	maxDrawerWidth: null,
	maxDrawerHeight: null,
	onOpen: null,
	onClose: null,
	onKeyDown: null,
	anchorProps: {},
	openOnHover: false,
	hoverOpenTime: 500,
	autoClose: false,
	autoCloseTime: 3000,
	openOnFocus: false,
	onAnchorClick: noop,
	openOnClick: true,
	horizontallyCenter: false,
	dockRight: false,
	enableTail: false,
	onClick: null,
};

export default DropDown;
