// @ts-nocheck
import React, { PureComponent, createRef } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import { ApplyConsumer } from './drop-down-context';
import ListItemContent from './list-item-content';

class ListItemButton extends PureComponent {
	constructor(props) {
		super(props);

		this.buttonRef = createRef();

		this.handleClick = this.handleClick.bind(this);
		this.handleKeyDown = this.handleKeyDown.bind(this);
	}

	handleClick(event) {
		const { onClick, onClickMeta } = this.props;

		if (isNil(onClick)) {
			return;
		}

		onClick({
			event,
			meta: onClickMeta,
		});
	}

	handleKeyDown(event) {
		// Treat enter key presses as clicks
		if (event.which === 13) {
			this.handleClick(event);
		}
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	getRootNode() {
		return this.buttonRef.current;
	}

	render() {
		const {
			id,
			className,
			'aria-label': ariaLabel,
			tabIndex,
			children,
			disabled,
			dropDownContext: { open },
		} = this.props;

		return (
			<>
				<button
					id={!isNil(id) ? `${id}-button` : null}
					className={classnames(
						'ai-dd-list-item-control',
						'ai-dd-list-item-button',
						className,
					)}
					ref={this.buttonRef}
					type="button"
					onClick={this.handleClick}
					onKeyDown={this.handleKeyDown}
					aria-label={ariaLabel}
					tabIndex={open ? tabIndex : -1}
					disabled={disabled}
				>
					{ariaLabel}
				</button>
				<ListItemContent>{children}</ListItemContent>
			</>
		);
	}
}

ListItemButton.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
	'aria-label': PropTypes.string,
	tabIndex: PropTypes.string,
	disabled: PropTypes.bool,
	dropDownContext: PropTypes.shape({
		open: PropTypes.bool.isRequired,
	}).isRequired,
};

ListItemButton.defaultProps = {
	id: null,
	className: null,
	children: null,
	onClick: null,
	onClickMeta: null,
	'aria-label': null,
	tabIndex: null,
	disabled: false,
};

export default ApplyConsumer(ListItemButton);
