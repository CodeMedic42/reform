/* eslint-disable no-alert */
// @ts-nocheck
import React from 'react';
import DropDown from '..';
import AnchorBinding from '../anchor-binding';
import Button from '../../button';
import Scope from '../../../../.storybook/components/scope';

function example() {
	return (
		<>
			<Scope title="Just Click">
				<div className="gutter-horizontal">
					<DropDown
						Anchor={AnchorBinding(Button)}
						anchorProps={{
							children: 'Just Click',
							color: 'primary',
							variant: 'outline',
						}}
						openOnClick
						openOnHover={false}
						openOnFocus={false}
					>
						Children
					</DropDown>
				</div>
			</Scope>
			<Scope title="Just Hover">
				<div className="gutter-horizontal">
					<DropDown
						Anchor={AnchorBinding(Button)}
						anchorProps={{
							children: 'Just Hover',
							color: 'primary',
							variant: 'outline',
						}}
						openOnClick={false}
						openOnHover
						openOnFocus={false}
					>
						Children
					</DropDown>
				</div>
			</Scope>
			<Scope title="Just Focus">
				<div className="gutter-horizontal">
					<DropDown
						Anchor={AnchorBinding(Button)}
						anchorProps={{
							children: 'Just Focus',
							color: 'primary',
							variant: 'outline',
						}}
						openOnClick={false}
						openOnHover={false}
						openOnFocus
					>
						Children
					</DropDown>
				</div>
			</Scope>
			<Scope title="Anchor Click">
				<div className="gutter-horizontal">
					<DropDown
						Anchor={AnchorBinding(Button)}
						anchorProps={{
							children: 'Anchor Click',
							color: 'primary',
							variant: 'outline',
						}}
						openOnClick={false}
						openOnHover
						openOnFocus={false}
						onAnchorClick={() => alert('Anchor was clicked')}
					>
						Children
					</DropDown>
				</div>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Activations',
};

export default example;
