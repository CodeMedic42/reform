// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import DropDown from '..';
import DropDownList from '../drop-down-list';
import DropDownListItem from '../drop-down-list-item';
import AnchorButton from '../anchor-button';
import Scope from '../../../../.storybook/components/scope';
import { Row, Column } from '../../grid';

const items = [
	{
		id: 'foo',
		content: 'Foo',
		'aria-label': 'foo',
	},
	{
		id: 'bar',
		content: 'Bar',
		'aria-label': 'bar',
	},
	{
		id: 'faz',
		content: 'Faz',
		'aria-label': 'faz',
	},
	{
		id: 'baz',
		content: 'Baz',
		'aria-label': 'baz',
	},
	{
		id: 'fooa',
		content: 'Foo',
		'aria-label': 'foo',
	},
	{
		id: 'bara',
		content: 'Bar',
		'aria-label': 'bar',
	},
	{
		id: 'faza',
		content: 'Faz',
		'aria-label': 'faz',
	},
	{
		id: 'baza',
		content: 'Baz',
		'aria-label': 'baz',
	},
];

function example() {
	return (
		<>
			<Scope title="Default">
				<DropDown
					id="with-options"
					Anchor={AnchorButton}
					anchorProps={{
						children: 'Text',
					}}
				>
					<DropDownList id="with-options-list">
						{map(items, (item) => {
							const itemId = item.id;

							return (
								<DropDownListItem key={itemId} id={itemId}>
									{item.content}
								</DropDownListItem>
							);
						})}
					</DropDownList>
				</DropDown>
			</Scope>
			<Scope title="Border Bottom">
				<DropDown
					id="with-options"
					Anchor={AnchorButton}
					anchorProps={{
						children: 'Text',
					}}
				>
					<DropDownList id="with-options-list">
						<DropDownListItem>Foo</DropDownListItem>
						<DropDownListItem borderBottom>Bar</DropDownListItem>
						<DropDownListItem>Foo</DropDownListItem>
					</DropDownList>
				</DropDown>
			</Scope>
			<Scope title="Sizes">
				<Row gutter>
					<Column width="content">
						<DropDown
							id="with-options"
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Text',
							}}
						>
							<DropDownList id="with-options-list" size="sm">
								{map(items, (item) => {
									const itemId = item.id;

									return (
										<DropDownListItem
											key={itemId}
											id={itemId}
										>
											{item.content}
										</DropDownListItem>
									);
								})}
							</DropDownList>
						</DropDown>
					</Column>
					<Column width="content">
						<DropDown
							id="with-options"
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Text',
							}}
						>
							<DropDownList id="with-options-list" size="md">
								{map(items, (item) => {
									const itemId = item.id;

									return (
										<DropDownListItem
											key={itemId}
											id={itemId}
										>
											{item.content}
										</DropDownListItem>
									);
								})}
							</DropDownList>
						</DropDown>
					</Column>
					<Column width="content">
						<DropDown
							id="with-options"
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Text',
							}}
						>
							<DropDownList id="with-options-list" size="lg">
								{map(items, (item) => {
									const itemId = item.id;

									return (
										<DropDownListItem
											key={itemId}
											id={itemId}
										>
											{item.content}
										</DropDownListItem>
									);
								})}
							</DropDownList>
						</DropDown>
					</Column>
				</Row>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic List',
};

export default example;
