/* eslint-disable no-alert */
// @ts-nocheck
import React from 'react';
import { faCircleInfo } from '@audacious/icons/regular/faCircleInfo';
import DropDown from '..';
import AnchorButton from '../anchor-button';
import Icon from '../../icon';
import applyAnchorBinding from '../anchor-binding';
import Scope from '../../../../.storybook/components/scope';

const iconBinding = applyAnchorBinding(Icon);

function example() {
	return (
		<>
			<Scope title="Simple Tray">
				<div className="gutter-horizontal">
					<DropDown
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Text',
						}}
					>
						Children
					</DropDown>
				</div>
			</Scope>
			<Scope title="Tray Open">
				<div className="gutter-horizontal">
					<DropDown
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Text',
						}}
						onOpen={() => alert('Tray opened')}
					>
						Children
					</DropDown>
				</div>
			</Scope>
			<Scope title="Tray Closed">
				<div className="gutter-horizontal">
					<DropDown
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Text',
						}}
						onClose={() => alert('Tray closed')}
					>
						Children
					</DropDown>
				</div>
			</Scope>
			<Scope title="Non-focusable anchor">
				<div className="gutter-horizontal">
					<DropDown
						Anchor={iconBinding}
						anchorProps={{
							icon: faCircleInfo,
						}}
					>
						Children
					</DropDown>
				</div>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basics',
};

export default example;
