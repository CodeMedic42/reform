// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Scope from '../../../../.storybook/components/scope';
import DropDown from '..';
import AnchorButton from '../anchor-button';
import { Row, Column } from '../../grid';

function renderColorScope(color) {
	return (
		<Scope key={color} title={color}>
			<Row gutter>
				<Column width="content">
					<DropDown
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Fill',
							variant: 'fill',
							color,
						}}
					>
						Children
					</DropDown>
				</Column>
				<Column width="content">
					<DropDown
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Outline',
							variant: 'outline',
							color,
						}}
					>
						Children
					</DropDown>
				</Column>
				<Column width="content">
					<DropDown
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Opaque',
							variant: 'opaque',
							color,
						}}
					>
						Children
					</DropDown>
				</Column>
			</Row>
			<Row gutter>
				<Column width="content">
					<DropDown
						disabled
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Disabled',
							variant: 'fill',
							color,
						}}
					>
						Children
					</DropDown>
				</Column>
				<Column width="content">
					<DropDown
						disabled
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Disabled',
							variant: 'outline',
							color,
						}}
					>
						Children
					</DropDown>
				</Column>
				<Column width="content">
					<DropDown
						disabled
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Disabled',
							variant: 'opaque',
							color,
						}}
					>
						Children
					</DropDown>
				</Column>
			</Row>
		</Scope>
	);
}

function example() {
	return (
		<>
			{map(
				['primary', 'secondary', 'info', 'success', 'warn', 'danger'],
				(color) => renderColorScope(color),
			)}
		</>
	);
}

example.story = {
	name: 'Colors and Variants',
};

export default example;
