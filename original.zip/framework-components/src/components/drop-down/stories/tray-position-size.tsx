// @ts-nocheck
import React from 'react';
import DropDown from '..';
import NumericInput from '../../numeric-input';
import CheckInput from '../../check-input';
import AnchorButton from '../anchor-button';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [contentWidth, setContentWidth] = React.useState(200);
	const [contentHeight, setContentHeight] = React.useState(100);
	const [hideScope, setHideScope] = React.useState(false);

	const style = {
		width: `${contentWidth}px`,
		height: `${contentHeight}px`,
	};

	return (
		<>
			<NumericInput
				id="contentWidth"
				label="Width"
				value={contentWidth}
				onChange={setContentWidth}
				min={15}
				width="md"
			/>
			<NumericInput
				id="contentHeight"
				label="Height"
				value={contentHeight}
				onChange={setContentHeight}
				min={15}
				width="md"
			/>
			<CheckInput
				id="hideScope"
				label="Hide Scope"
				value={hideScope}
				onChange={() => {
					setHideScope(!hideScope);
				}}
			/>
			<Scope specimenOnly={hideScope} title="No constraints">
				<DropDown
					id="wide-contents"
					closeTrayOnClick={false}
					Anchor={AnchorButton}
					anchorProps={{
						children: 'Text',
					}}
				>
					<div className="sizer" style={style}>
						{`${contentWidth}px X ${contentHeight}px`}
					</div>
				</DropDown>
			</Scope>
			<Scope specimenOnly={hideScope} title="Min Drawer Width 300px">
				<DropDown
					id="wide-contents"
					closeTrayOnClick={false}
					minDrawerWidth={300}
					Anchor={AnchorButton}
					anchorProps={{
						children: 'Text',
					}}
				>
					<div className="sizer" style={style}>
						{`${contentWidth}px X ${contentHeight}px`}
					</div>
				</DropDown>
			</Scope>
			<Scope
				specimenOnly={hideScope}
				title="Min Drawer Width Bounding Parent"
			>
				<DropDown
					id="wide-contents"
					closeTrayOnClick={false}
					minDrawerWidth="anchor"
					Anchor={AnchorButton}
					anchorProps={{
						children: 'Text',
					}}
				>
					<div className="sizer" style={style}>
						{`${contentWidth}px X ${contentHeight}px`}
					</div>
				</DropDown>
			</Scope>
			<Scope specimenOnly={hideScope} title="Max Drawer Width 300px">
				<DropDown
					id="wide-contents"
					closeTrayOnClick={false}
					maxDrawerWidth={300}
					Anchor={AnchorButton}
					anchorProps={{
						children: 'Text',
					}}
				>
					<div className="sizer" style={style}>
						{`${contentWidth}px X ${contentHeight}px`}
					</div>
				</DropDown>
			</Scope>
			<Scope specimenOnly={hideScope} title="Max Drawer Height 300px">
				<DropDown
					id="wide-contents"
					closeTrayOnClick={false}
					maxDrawerHeight={300}
					Anchor={AnchorButton}
					anchorProps={{
						children: 'Text',
					}}
				>
					<div className="sizer" style={style}>
						{`${contentWidth}px X ${contentHeight}px`}
					</div>
				</DropDown>
			</Scope>
			<Scope specimenOnly={hideScope} title="Dock Left/Right">
				<div style={{ marginLeft: -50, marginBottom: 10 }}>
					<DropDown
						id="wide-contents"
						closeTrayOnClick={false}
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Left Clipped',
						}}
					>
						<div className="sizer" style={style}>
							{`${contentWidth}px X ${contentHeight}px`}
						</div>
					</DropDown>
				</div>
				<div style={{ marginBottom: 10 }}>
					<DropDown
						id="wide-contents"
						closeTrayOnClick={false}
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Left',
						}}
					>
						<div className="sizer" style={style}>
							{`${contentWidth}px X ${contentHeight}px`}
						</div>
					</DropDown>
				</div>
				<div style={{ display: 'flex' }}>
					<div
						style={{
							marginLeft: 'auto',
							marginRight: 'auto',
							marginBottom: 10,
						}}
					>
						<DropDown
							id="wide-contents"
							closeTrayOnClick={false}
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Center',
							}}
						>
							<div className="sizer" style={style}>
								{`${contentWidth}px X ${contentHeight}px`}
							</div>
						</DropDown>
					</div>
				</div>
				<div
					style={{
						display: 'flex',
						justifyContent: 'flex-end',
						marginBottom: 10,
					}}
				>
					<div>
						<DropDown
							id="wide-contents"
							closeTrayOnClick={false}
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Right',
							}}
						>
							<div className="sizer" style={style}>
								{`${contentWidth}px X ${contentHeight}px`}
							</div>
						</DropDown>
					</div>
				</div>
				<div
					style={{
						display: 'flex',
						justifyContent: 'flex-end',
						marginBottom: 10,
					}}
				>
					<div style={{ marginRight: -50 }}>
						<DropDown
							id="wide-contents"
							closeTrayOnClick={false}
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Right Clipped',
							}}
						>
							<div className="sizer" style={style}>
								{`${contentWidth}px X ${contentHeight}px`}
							</div>
						</DropDown>
					</div>
				</div>
			</Scope>
			<Scope specimenOnly={hideScope} title="Center Horizontally">
				<div style={{ marginLeft: -50, marginBottom: 10 }}>
					<DropDown
						id="wide-contents"
						closeTrayOnClick={false}
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Left Clipped',
						}}
						horizontallyCenter
					>
						<div className="sizer" style={style}>
							{`${contentWidth}px X ${contentHeight}px`}
						</div>
					</DropDown>
				</div>
				<div style={{ marginBottom: 10 }}>
					<DropDown
						id="wide-contents"
						closeTrayOnClick={false}
						Anchor={AnchorButton}
						anchorProps={{
							children: 'Left',
						}}
						horizontallyCenter
					>
						<div className="sizer" style={style}>
							{`${contentWidth}px X ${contentHeight}px`}
						</div>
					</DropDown>
				</div>
				<div style={{ display: 'flex' }}>
					<div
						style={{
							marginLeft: 'auto',
							marginRight: 'auto',
							marginBottom: 10,
						}}
					>
						<DropDown
							id="wide-contents"
							closeTrayOnClick={false}
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Center',
							}}
							horizontallyCenter
						>
							<div className="sizer" style={style}>
								{`${contentWidth}px X ${contentHeight}px`}
							</div>
						</DropDown>
					</div>
				</div>
				<div
					style={{
						display: 'flex',
						justifyContent: 'flex-end',
						marginBottom: 10,
					}}
				>
					<div>
						<DropDown
							id="wide-contents"
							closeTrayOnClick={false}
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Right',
							}}
							horizontallyCenter
						>
							<div className="sizer" style={style}>
								{`${contentWidth}px X ${contentHeight}px`}
							</div>
						</DropDown>
					</div>
				</div>
				<div
					style={{
						display: 'flex',
						justifyContent: 'flex-end',
						marginBottom: 10,
					}}
				>
					<div style={{ marginRight: -50 }}>
						<DropDown
							id="wide-contents"
							closeTrayOnClick={false}
							Anchor={AnchorButton}
							anchorProps={{
								children: 'Right Clipped',
							}}
							horizontallyCenter
						>
							<div className="sizer" style={style}>
								{`${contentWidth}px X ${contentHeight}px`}
							</div>
						</DropDown>
					</div>
				</div>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Tray Position and Size',
};

export default example;
