// @ts-nocheck
import React, { createRef } from 'react';
import PropTypes from 'prop-types';
import isNil from 'lodash-es/isNil';

let lastCalledFor = null;
let lastCalledForContainer = null;
let timer = null;

// This will find the scrolling parent
function getScrollContainer(node, stop) {
	if (isNil(node) || node === stop) {
		return null;
	}

	const { overflowY } = window.getComputedStyle(node);
	const isScrollable = overflowY !== 'visible' && overflowY !== 'hidden';

	if (isScrollable && node.scrollHeight >= node.clientHeight) {
		return node;
	}

	return getScrollContainer(node.parentNode, stop);
}

function findScrollContainer(node, stop) {
	if (node === lastCalledFor) {
		return lastCalledForContainer;
	}

	if (!isNil(timer)) {
		clearTimeout(timer);
	}

	timer = setTimeout(() => {
		lastCalledFor = null;
		lastCalledForContainer = null;

		timer = null;
	}, 500);

	lastCalledFor = node;

	lastCalledForContainer = getScrollContainer(node, stop);

	return lastCalledForContainer;
}

/*

This will apply a listener which will cancel all scrolling events from propagating up out of the boundary.
I find it very annoying when you are scrolling with the mouse wheel in one element and then when you get to the bottom
one of its parents start to scroll. This will prevent that.

*/
function applyWheel(boundaryElement) {
	if (isNil(boundaryElement)) {
		return null;
	}

	const handleWheel = (event) => {
		const { deltaY, deltaX, target } = event;

		const scrollingContainer = findScrollContainer(target, boundaryElement);

		if (isNil(scrollingContainer)) {
			return;
		}

		const {
			scrollTop,
			scrollLeft,
			scrollHeight,
			scrollWidth,
			clientHeight,
			clientWidth,
		} = scrollingContainer;

		// This will stop the event from propagating to the parents.
		event.stopPropagation();

		let stop = false;

		if (deltaY < 0) {
			stop = scrollTop <= 0;
		} else if (deltaY > 0) {
			stop = scrollTop + clientHeight >= scrollHeight;
		}

		if (deltaX < 0) {
			stop = scrollLeft <= 0;
		} else if (deltaX > 0) {
			stop = scrollLeft + clientWidth >= scrollWidth;
		}

		if (stop) {
			// This will stop other weirdness. Sometime even though you stop the propagation.
			// There are other things which can respond.
			// SCROLLING IS WEIRD AND A HUGE PAIN IN THE NECK!
			// event.preventDefault();
		}
	};

	boundaryElement.addEventListener('wheel', handleWheel, {
		passive: false,
		capture: false,
	});

	return () => {
		boundaryElement.removeEventListener('wheel', handleWheel);
	};
}

/* 

This will information the component using this if a click event happened outside of this component.
THis can be used to respond by closing things.

*/
function applyClick() {
	const handleClick = (event) => {
		if (!this.didClick) {
			this.props.onExternalClick(event);
		}

		this.didClick = false;
	};

	document.addEventListener('click', handleClick);

	return () => {
		document.removeEventListener('click', handleClick);
	};
}

class ExternalBoundary extends React.Component {
	constructor(props) {
		super(props);

		this.boundaryRef = createRef();

		this.handleClickCapture = this.handleClickCapture.bind(this);
	}

	componentDidMount() {
		const { onExternalClick, cancelExternalScroll } = this.props;

		if (!isNil(onExternalClick)) {
			// Setup the click listener if we need to.
			this.clickListenerUpdate = applyClick.call(this);
		}

		if (cancelExternalScroll) {
			// Setup the wheel listener if we need to
			this.wheelListenerUpdate = applyWheel(this.boundaryRef.current);
		}
	}

	componentDidUpdate() {
		const { cancelExternalScroll, onExternalClick } = this.props;

		if (!isNil(onExternalClick)) {
			if (isNil(this.clickListenerUpdate)) {
				// Setup the click listener if we need to.
				this.clickListenerUpdate = applyClick.call(this);
			}
		} else if (!isNil(this.clickListenerUpdate)) {
			// Someone turned of the external click listener.
			// We need to remove the window listener.
			this.clickListenerUpdate();

			this.clickListenerUpdate = null;
		}

		if (cancelExternalScroll) {
			if (isNil(this.wheelListenerUpdate)) {
				// Setup the wheel listener if we need to
				this.wheelListenerUpdate = applyWheel(this.boundaryRef.current);
			}
		} else if (!isNil(this.wheelListenerUpdate)) {
			this.wheelListenerUpdate();

			this.wheelListenerUpdate = null;
		}
	}

	// This will clean up any listeners
	componentWillUnmount() {
		if (!isNil(this.clickListenerUpdate)) {
			this.clickListenerUpdate();

			this.clickListenerUpdate = null;
		}

		if (!isNil(this.wheelListenerUpdate)) {
			this.wheelListenerUpdate();

			this.wheelListenerUpdate = null;
		}
	}

	handleClickCapture() {
		// eslint-disable-next-line react/no-unused-class-component-methods
		this.didClick = true;
	}

	render() {
		const { onExternalClick, cancelExternalScroll, ...rest } = this.props;

		return (
			<div
				{...rest}
				ref={this.boundaryRef}
				// Only set this up if we need to
				onClickCapture={
					!isNil(onExternalClick) ? this.handleClickCapture : null
				}
			/>
		);
	}
}

ExternalBoundary.propTypes = {
	// eslint-disable-next-line react/forbid-prop-types
	children: PropTypes.any,
	// This will be called if a click event happened outside the boundary
	onExternalClick: PropTypes.func,
	// This will cancel all scrolling outside the boundary if the scroll is targeted inside the boundary.
	cancelExternalScroll: PropTypes.bool,
};

ExternalBoundary.defaultProps = {
	onExternalClick: null,
	cancelExternalScroll: null,
	children: null,
};

export default ExternalBoundary;
