// @ts-nocheck
import FileDrop from '.';
// import './stories/styles.scss';

export default {
	title: 'Controls/File Drop',
	component: FileDrop,
};

export { default as basics } from './stories/basics';
export { default as layout } from './stories/layout';
