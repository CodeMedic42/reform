/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
// @ts-nocheck
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCloudArrowUp } from '@audacious/icons/solid/faCloudArrowUp';
import isNil from 'lodash-es/isNil';
import reduce from 'lodash-es/reduce';
import InputMessages from '../input-messages';

class FileDrop extends Component {
	constructor(props) {
		super(props);

		this.dragRef = React.createRef();
		this.inputRef = React.createRef();

		this.handleFileSelect = this.handleFileSelect.bind(this);
		this.handleDrag = this.handleDrag.bind(this);
		this.handleDragStart = this.handleDragStart.bind(this);
		this.handleDragEnd = this.handleDragEnd.bind(this);
		this.handleDragOver = this.handleDragOver.bind(this);
		this.handleDragEnter = this.handleDragEnter.bind(this);
		this.handleDragLeave = this.handleDragLeave.bind(this);
		this.handleDrop = this.handleDrop.bind(this);
		this.handleMouseDown = this.handleMouseDown.bind(this);

		this.state = {};
	}

	static getDerivedStateFromProps(nextProps) {
		const { id, 'aria-describedby': ariaDescribedBy, messages } = nextProps;

		const descriptionId = `${id}-description`;

		let describedBy = reduce(
			ariaDescribedBy,
			(acc, additionalDescriptionId) =>
				`${acc} ${additionalDescriptionId}`,
			descriptionId,
		);

		if (!messages) {
			describedBy = null;
		}

		return {
			describedBy,
			descriptionId,
		};
	}

	handleFileSelect(event) {
		this.processFiles(event.target.files);
	}

	// eslint-disable-next-line class-methods-use-this
	handleDrag(event) {
		event.preventDefault();
		event.stopPropagation();
	}

	// eslint-disable-next-line class-methods-use-this
	handleDragStart(event) {
		event.preventDefault();
		event.stopPropagation();
	}

	handleDragEnd(event) {
		event.preventDefault();
		event.stopPropagation();

		this.dragRef.current.classList.remove('is-dragging');
	}

	handleDragOver(event) {
		event.preventDefault();
		event.stopPropagation();

		this.dragRef.current.classList.add('is-dragging');
	}

	handleDragEnter(event) {
		event.preventDefault();
		event.stopPropagation();

		this.dragRef.current.classList.add('is-dragging');
	}

	handleDragLeave(event) {
		event.preventDefault();
		event.stopPropagation();

		this.dragRef.current.classList.remove('is-dragging');
	}

	handleDrop(event) {
		event.preventDefault();
		event.stopPropagation();

		this.dragRef.current.classList.remove('is-dragging');

		this.processFiles(event.dataTransfer.files);
	}

	handleMouseDown() {
		this.inputRef.current.value = '';
	}

	processFiles(files) {
		const { onFileSelect } = this.props;

		if (isNil(onFileSelect)) {
			return;
		}

		onFileSelect(files);
	}

	render() {
		const {
			id,
			className,
			headerText,
			accept,
			disabled,
			hidden,
			title,
			'aria-label': ariaLabel,
			messages,
			invalid,
			'aria-labelledby': ariaLabelledBy,
		} = this.props;

		const { describedBy, descriptionId } = this.state;

		const dragProps = {};

		if (!disabled) {
			dragProps.onDrag = this.handleDrag;
			dragProps.onDragStart = this.handleDragStart;
			dragProps.onDragEnd = this.handleDragEnd;
			dragProps.onDragOver = this.handleDragOver;
			dragProps.onDragEnter = this.handleDragEnter;
			dragProps.onDragLeave = this.handleDragLeave;
			dragProps.onDrop = this.handleDrop;
		}

		let headerTextElement = null;

		if (!isNil(headerText) && headerText.length > 0) {
			headerTextElement = (
				<span className="ai-file-drop-header-text">{headerText}</span>
			);
		}

		return (
			<div
				ref={this.dragRef}
				id={id}
				className={classnames('ai-file-drop', className, {
					disabled,
					hidden,
					invalid,
				})}
				title={title}
				{...dragProps}
			>
				<div className="ai-file-drop-header">
					<FontAwesomeIcon icon={faCloudArrowUp} />
					{headerTextElement}
				</div>
				<div className="ai-file-drop-control">
					<span>{'Drag your file here or '}</span>
					<label
						id={`${id}-label`}
						htmlFor={`${id}-input`}
						aria-label={ariaLabel}
						onMouseDown={this.handleMouseDown}
					>
						Browse File
						<input
							ref={this.inputRef}
							tabIndex="-1"
							id={`${id}-input`}
							type="file"
							multiple
							accept={accept}
							onChange={this.handleFileSelect}
							aria-labelledby={ariaLabelledBy}
							aria-describedby={describedBy}
						/>
					</label>
				</div>
				<InputMessages id={descriptionId} messages={messages} />
			</div>
		);
	}
}

FileDrop.propTypes = {
	id: PropTypes.string.isRequired,
	headerText: PropTypes.string,
	title: PropTypes.string,
	'aria-label': PropTypes.string,
	className: PropTypes.string,
	disabled: PropTypes.bool,
	hidden: PropTypes.bool,
	onFileSelect: PropTypes.func,
	accept: PropTypes.string,
	'aria-labelledby': PropTypes.string,
	'aria-describedby': PropTypes.string,
	invalid: PropTypes.bool,
	messages: PropTypes.shape({
		general: PropTypes.arrayOf(PropTypes.string),
		success: PropTypes.arrayOf(PropTypes.string),
		invalid: PropTypes.arrayOf(PropTypes.string),
	}),
};

FileDrop.defaultProps = {
	className: null,
	headerText: null,
	title: null,
	'aria-label': null,
	disabled: false,
	hidden: false,
	onFileSelect: null,
	accept: null,
	'aria-describedby': null,
	'aria-labelledby': null,
	messages: null,
	invalid: false,
};

export default FileDrop;
