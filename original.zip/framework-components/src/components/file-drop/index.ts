// @ts-nocheck
import FileDrop from './file-drop';

export default FileDrop;
