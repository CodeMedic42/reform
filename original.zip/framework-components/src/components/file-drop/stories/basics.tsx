// @ts-nocheck
import React from 'react';
import FileDrop from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	return (
		<>
			<Scope title="Simple">
				<FileDrop id="basic-example-simple" />
			</Scope>
			<Scope title="With header">
				<FileDrop
					id="basic-example-with-header"
					headerText="Header Text"
				/>
			</Scope>
			<Scope title="With Title">
				<FileDrop
					id="basic-example-with-title"
					title="Drag here for a surprise"
				/>
			</Scope>
			<Scope title="Disabled">
				<FileDrop id="basic-example-disabled" disabled />
			</Scope>
			<Scope title="Hidden">
				<FileDrop id="basic-example-hidden" hidden />
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basics',
};

export default example;
