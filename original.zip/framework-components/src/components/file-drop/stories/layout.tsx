// @ts-nocheck
import React from 'react';
import FileDrop from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	return (
		<>
			<Scope title="Default Width (100%)">
				<FileDrop id="example-100" headerText="Header Text" />
			</Scope>
			<Scope title="Extra Extra Large Width">
				<FileDrop
					id="example-2xlg"
					headerText="Header Text"
					width="2xlg"
				/>
			</Scope>
			<Scope title="Extra Large Width">
				<FileDrop
					id="example-xlg"
					headerText="Header Text"
					width="xlg"
				/>
			</Scope>
			<Scope title="Large Width">
				<FileDrop id="example-lg" headerText="Header Text" width="lg" />
			</Scope>
			<Scope title="Medium Width">
				<FileDrop id="example-md" headerText="Header Text" width="md" />
			</Scope>
			<Scope title="Small Width">
				<FileDrop id="example-sm" headerText="Header Text" width="sm" />
			</Scope>
			<Scope title="Extra Small Width">
				<FileDrop
					id="example-xsm"
					headerText="Header Text"
					width="xsm"
				/>
			</Scope>
			<Scope title="Extra Extra Small Width">
				<FileDrop
					id="example-2xsm"
					headerText="Header Text"
					width="2xs"
				/>
			</Scope>
			<Scope title="Tiling">
				<FileDrop id="example-tile-2xlg" label="2XLG" width="2xlg" />
				<FileDrop id="example-tile-xlg" label="XLG" width="xlg" />
				<FileDrop id="example-tile-lg" label="LG" width="lg" />
				<FileDrop id="example-tile-md" label="MD" width="md" />
				<FileDrop id="example-tile-sm" label="SM" width="sm" />
				<FileDrop id="example-tile-xsm" label="XSM" width="xsm" />
				<FileDrop id="example-tile-2xs" label="2XS" width="2xs" />
			</Scope>
		</>
	);
}

example.story = {
	name: 'Layout',
};

export default example;
