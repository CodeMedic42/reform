# Grid

## Description

The gridding system is used to layout components for the webpage as well as support most kinds of responsive needs.

## Import

```jsx
import { Container, Row, Column } from 'ainq-core-theme/lib/components/grid';
```

## Use

There are three components, Container, Row, Column. In most cases only Row and Column will be needed.

Start with a Row and a Column.

```jsx
<Row>
	<Column>... Your content here</Column>
</Row>
```

A Row should ONLY have Column elements, but can have as many as are needed.

A Column will contain any content, it can also contain Rows. It is STRONGLY recommended and considered good composition to not mix rows with other elements immediately inside a Column element. A Column can contain as many Rows as are needed.

## Responsive

All the components support a responsive design. This means that the prop features can be turned off and on based on the width of the view port.

The are 6 sizes Small(sm), Medium(md), Large(lg), Extra Large(xl), and Extra Extra Large(2xl).

Any prop which supports responsive settings will be marked as responsive. All properties marked this way will support an array one way or the other. When using an array for these props the indices of the array represent the above sizes. So If I wanted to target the sm size I would use a prop like this.
use

```jsx
<Component propName={[value]}>
```

If I wanted to target the lg size I would use a prop like the following.

```jsx
<Component propName={[null, null, value]}>
```

The to target all sizes the prop can be set like the following

```jsx
<Component propName={[smValue, mdValue, lgValue, xlValue, 2xlValue]}>
```

If a value is not provided at a particular size then the next size down will be used. If no size is provided for sm then the default setting will be chosen.

## Row

The Row components supports the following properties. Any additional properties beyond these will be applied to the root element.

-   **className**

    **Type:** (Nil, String)

    **Responsive:** No

    **Description:** **Description:** This will be the class names which wil put on the resulting HTML element.

    **Default:** Null

-   **justify**

    **Type:** (Nil, String, Array[])

    **Responsive:** Yes

    **Description:** This will align Column elements along the horizontal axis.

    **Values:** The only valid values are "left", "center", "right". Each of these

    **Default:** "left"

-   **align**

    **Type:** (Nil, String, Array[])

    **Responsive:** Yes

    **Description:** This will align Column elements along the vertical axis.

    **Values:** The only valid values are "top", "center", "bottom"

    **Default:** "top"

-   **gutter**

    **Type:** (Nil, Boolean, String, Array[], Shape{ h: (String, Array[]), v: (String, Array[]) })

    **Responsive:** Yes

    **Description:** This will be the gutter

    **Values:** The only valid values are "8", "16", "24", "32". When true is passed then 16 is used.

    **Default:** null

-   **before**

    **Type:** (Nil, String, Array[])

    **Responsive:** Yes

    **Description:** Sets up a psuedo before clause which can then be targeted with specific css to add additional css features at the beginning of the row.

    **Values:** The only valid values are "8", "16", "24", "32". When true is passed then 16 is used.

    **Default:** null

-   **after**

    **Type:** Boolean

    **Responsive:** Yes

    **Description:** Sets up a psuedo after clause which can then be targeted with specific css to add additional css features at the end of the row.

    **Default:** null

### Example 1: Row with gutter 16

In this example the gutter would always be 16.

```jsx
<Row gutter="16">...</Row>
```

### Example 2: Row with gutter 32

In this example the gutter would always be 32.

```jsx
<Row gutter="32">...</Row>
```

### Example 3: Row with standard gutter, same as row with gutter 16

In this example the gutter would always be 16 which is the default gutter when a gutter is applied.

```jsx
<Row gutter>...</Row>
```

### Example 4: Row where there is no gutter at SM, 16 at MD, and 32 at 2xl

In this example the breakdown would look like this

-   SM: No Gutter
-   MD: Gutter of 16
-   LG: Gutter of 16
-   XL: Gutter of 16
-   2xl: Gutter of 32

```jsx
<Row gutter={[null, '16', null, null, '32']}>...</Row>
```

### Example 5: No gutter

This example results in the same gutter which is no gutter

```jsx
<Row gutter={[null]}>...</Row>
<Row gutter={null}>...</Row>
<Row gutter={false}>...</Row>
<Row>...</Row>
```

### Example 6: Justify Bottom and Align Right

This example the contents will be moved to the bottom and to the right.

```jsx
<Row justify="bottom" align="right">
	...
</Row>
```

### Example 7: Justify Bottom and Align Right but only at large or greater

This example the contents will be moved to the bottom and to the right, only at a LG resolution.

```jsx
<Row justify={[null, null, 'bottom']} align={[null, null, 'right']}>
	...
</Row>
```

## Column

A Column controls with available width for its contents. It also will wrap when the combined width of all columns in a Row element is greater than the width of that Row element.

### Properties

The Column components supports the following properties. Any additional properties beyond these will be applied to the root element.

-   **className**

    **Type:** (Nil, String)

    **Description:** **Description:** This will be the class names which wil put on the resulting HTML element.

    **Default:** Null

-   **justify**

    **Type:** (Nil, String, Array[])

    **Responsive:** Yes

    **Description:** This will align Column elements along the horizontal axis.

    **Values:** The only valid values are "left", "center", "right". Each of these

    **Default:** "left"

-   **align**

    **Type:** (Nil, String, Array[])

    **Responsive:** Yes

    **Description:** This will align Column elements along the vertical axis.

    **Values:** The only valid values are "top", "center", "bottom"

    **Default:** "top"

-   **width**

    **Type:** (Nil, String, Array[])

    **Responsive:** Yes

    **Description:** This will be the width of the column.

    If set to a number then the width of the column element will be the (width / 12) \* 100% of the Row width.

    If set to "content" then the width of the column will be the width of it's children.

    If set to "fill" then the width of the column will evenly distributed between all other columns set to fill within the row minus the static widths of all columns which are not set to fill.

    A value of static:# can be provided which will set the column to a specific width. For example if you want a column 100xp wide then you can use "static:100".

    If no width is provided then the result is a Column which is 100% as width as the row it is in.

    **Values:** The only valid values are "static:#", "content", "fill", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "1", and "12".

    **Default:** null

-   **leftOffset**

    **Type:** (Nil, String, Array[])

    **Responsive:** Yes

    **Description:** This will be an offset margin applied to the left of the column.

    If set to a number then the offset of the column element will be the (offset / 12) \* 100% of the Row width.

    If set to "fill" then the the margin will be set to auto and will take up slack evenly across all other offset, left or right, values.

    **Values:** The only valid values are "fill", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "1", and "12".

    **Default:** null

-   **rightOffset**

    **Type:** (Nil, String, Array[])

    **Responsive:** Yes

    **Description:** This will be an offset margin applied to the right of the column.

    If set to a number then the offset of the column element will be the (offset / 12) \* 100% of the Row width.

    If set to "fill" then the the margin will be set to auto and will take up slack evenly across all other offset, left or right, values.

    **Values:** The only valid values are "fill", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "1", and "12".

    **Default:** null

-   **minWidth**

    **Type:** String

    **Responsive:** Yes

    **Description:** This will be set the min width of the column. The value should be an number.

    **Values:** Any valid, positive, finite number.

    **Default:** null

-   **maxWidth**

    **Type:** String

    **Responsive:** Yes

    **Description:** This will be set the min width of the column. The value should be an number.

    **Values:** Any valid, positive, finite number.

    **Default:** null

-   **paddingTop**

    **Type:** String

    **Responsive:** Yes

    **Description:** This will be set the min width of the column. The value should be an number.

    **Values:** Any positive, finite number.

    **Default:** null

-   **order**

    **Type:** String

    **Responsive:** Yes

    **Description:** This will be set the order in which the element is rendered with the others. All elements start at 0.

    **Values:** Any positive, integer.

    **Default:** null

### Example 1: Column with a width of 3 columns at all times.

In this example the width for this column will always be 3 columns.

```jsx
<Column width="16">...</Column>
```

### Example 2: Column with a width matching its content.

In this example the width will be just as wide as the contents of the Column.

```jsx
<Column width="content">...</Column>
```

### Example 3: Column with a width filling in unused space .

In this example the width will fill unused space evenly.

```jsx
<Column width="fill">...</Column>
```

### Example 4: Column where there it is the width of its content at SM, will fill at MD, and is 5 column width at 2xl

In this example the breakdown would look like this

-   SM: As wide as the content
-   MD: Will fill unused space
-   LG: Will fill unused space
-   XL: Will fill unused space
-   2xl: Will be 5 column widths wide.

```jsx
<Column width={['content', 'fill', null, null, '5']}>...</Column>
```

### Example 5: Left offset and right offset of fill

This example the left and right offset are set to fill

```jsx
<Column leftOffset="fill" rightOffset="fill">
	...
</Column>
```

### Example 6: Left offset and right offset of fill, but only at LG

This example the left and right offset are set to fill only when the browser is at a large resolution.

```jsx
<Column leftOffset={[null, null, 'fill']} rightOffset={[null, null, 'fill']}>
	...
</Column>
```

### Example 7: Justify Bottom and Align Right

This example the contents will be moved to the bottom and to the right.

```jsx
<Column justify="bottom" align="right">
	...
</Column>
```

### Example 8: Justify Bottom and Align Right but only at large or greater

This example the contents will be moved to the bottom and to the right, only at a LG resolution.

```jsx
<Column justify={[null, null, 'bottom']} align={[null, null, 'right']}>
	...
</Column>
```

## Container

A Container is an option component and does not even need to be used with Row or Column elements.

It provides some support when wanting to have a gutter at the end of a group of Rows.

Also based on how the gridding works there is some negative margins at the top of the first Row element. Sometime this overflow can cause problems. The Container component has a property with can be used to clip this off.

### Properties

The Column components supports the following properties

-   **id**

    **Type:** (Nil, String)

    **Description:** This will be the id which will put on the resulting HTML element.

    **Default:** Null

-   **className**

    **Type:** (Nil, String)

    **Description:** **Description:** This will be the class names which wil put on the resulting HTML element.

    **Default:** Null

-   **gutter**

    **Type:** (Nil, Boolean, String, Array[], Shape{ h: (String, Array[]), v: (String, Array[]) })

    **Responsive:** Yes

    **Description:** This will be a gutter applied to the bottom of the Container element.

    **Values:** The only valid values are "8", "16", "24", "32". When true is passed then "16" is used.

    **Default:** null

-   **hideOverflow**

    **Type:** (Nil, Boolean)

    **Description:** This will remove the overflow of the Rows if needed.

    **Default:** false

-   **style**
    **Type:** (Nil, Standard style Object)
    **Description:** Apply direct styles to the html element.
    **Default:** null

### Example 1: Container with gutter 16

In this example the gutter would always be 16.

```jsx
<Container bottomGutter="16">...</Container>
```

### Example 2: Container with gutter 32

In this example the gutter would always be 32.

```jsx
<Container bottomGutter="32">...</Container>
```

### Example 3: Container with standard gutter, same as with gutter 16

In this example the gutter would always be 16 which is the default gutter when a gutter is applied.

```jsx
<Container bottomGutter>...</Container>
```

### Example 4: Container where there is no gutter at SM, 16 at MD, and 32 at 2xl

In this example the breakdown would look like this

-   SM: No Gutter
-   MD: Gutter of 16
-   LG: Gutter of 16
-   XL: Gutter of 16
-   2xl: Gutter of 32

```jsx
<Container bottomGutter={[null, '16', null, null, '32']}>...</Container>
```

### Example 5: No gutter

This example results in the same gutter which is no gutter

```jsx
<Container bottomGutter={[null]}>...</Container>
<Container bottomGutter={null}>...</Container>
<Container bottomGutter={false}>...</Container>
<Container>...</Container>
```

### Example 5: Clip overflow

```jsx
<Container hideOverflow>...</Container>
```
