// @ts-nocheck
import React, { PureComponent, createRef } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import startsWith from 'lodash-es/startsWith';
import isString from 'lodash-es/isString';
import Row from './row';

function buildClass(prop, prefix) {
	if (isNil(prop)) {
		return null;
	}

	if (isString(prop)) {
		return `${prefix}-${prop}`;
	}

	const [base, medium, large, exLarge, exExLarge] = prop;

	return classnames({
		[`${prefix}-${base}`]: !isNil(base),
		[`${prefix}-${medium}-md`]: !isNil(medium),
		[`${prefix}-${large}-lg`]: !isNil(large),
		[`${prefix}-${exLarge}-xl`]: !isNil(exLarge),
		[`${prefix}-${exExLarge}-2xl`]: !isNil(exExLarge),
	});
}

function applySequenceOrderState(acc, value, suffix) {
	if (isNil(value)) {
		return;
	}

	acc.classNames.push(`sequence-order${suffix}`);
	acc.styles[`--grid-col-order${suffix}`] = value;
}

function applyWidthState(acc, value, suffix) {
	if (isNil(value)) {
		return;
	}

	if (!startsWith(value, 'static')) {
		acc.classNames.push(`width-${value}${suffix}`);
	} else {
		const widthSize = value.slice(7);

		acc.classNames.push(`width-static${suffix}`);
		acc.styles[`--grid-col-static${suffix}`] = `${widthSize}px`;
	}
}

function applyWidthLimitState(acc, value, suffix, limitType) {
	if (isNil(value)) {
		return;
	}

	if (!startsWith(value, 'static')) {
		throw new Error(
			'Width limits do not support anything other than static at the moment',
		);
	}

	acc.classNames.push(`${limitType}-width-static${suffix}`);
	acc.styles[
		`--grid-col-${limitType}-width-static${suffix}`
	] = `${value.slice(7)}px`;
}

function applyPaddingTopState(acc, value, suffix) {
	if (isNil(value)) {
		return;
	}

	if (!startsWith(value, 'static')) {
		throw new Error(
			'Padding Top does not support anything other than static at the moment',
		);
	}

	acc.classNames.push(`padding-top-static${suffix}`);
	acc.styles[`--grid-col-padding-top-static${suffix}`] = `${value.slice(
		7,
	)}px`;
}

function buildClassState(value, cb, ...args) {
	const states = {
		classNames: [],
		styles: {},
	};

	if (!isNil(value)) {
		if (isString(value)) {
			cb(states, value, '', ...args);
		} else {
			const [base, medium, large, exLarge, exExLarge] = value;

			cb(states, base, '', ...args);
			cb(states, medium, '-md', ...args);
			cb(states, large, '-lg', ...args);
			cb(states, exLarge, '-xl', ...args);
			cb(states, exExLarge, '-2xl', ...args);
		}
	}

	return states;
}

class Column extends PureComponent {
	constructor(props) {
		super(props);

		this.columnRef = createRef();
	}

	render() {
		const {
			className,
			justify,
			align,
			width,
			minWidth,
			maxWidth,
			paddingTop,
			leftOffset,
			rightOffset,
			order,
			useContentBox,
			children,
			style = {},
			...rest
		} = this.props;

		const { classNames: widthClasses, styles: widthStyles } =
			buildClassState(width, applyWidthState);
		const { classNames: orderClasses, styles: orderStyles } =
			buildClassState(order, applySequenceOrderState);
		const { classNames: minWidthClasses, styles: minWidthStyles } =
			buildClassState(minWidth, applyWidthLimitState, 'min');
		const { classNames: maxWidthClasses, styles: maxWidthStyles } =
			buildClassState(maxWidth, applyWidthLimitState, 'max');
		const { classNames: paddingTopClasses, styles: paddingTopStyles } =
			buildClassState(paddingTop, applyPaddingTopState);

		const classNames = classnames(
			'grid-col',
			buildClass(justify, 'justify'),
			buildClass(align, 'align'),
			buildClass(leftOffset, 'offset-left'),
			buildClass(rightOffset, 'offset-right'),
			className,
			...widthClasses,
			...orderClasses,
			...minWidthClasses,
			...maxWidthClasses,
			...paddingTopClasses,
			{
				'row-column': children?.[0]?.type === Row,
				'use-content-box': useContentBox,
			},
		);

		return (
			<div
				ref={this.columnRef}
				{...rest}
				className={classNames}
				style={{
					...style,
					...widthStyles,
					...orderStyles,
					...minWidthStyles,
					...maxWidthStyles,
					...paddingTopStyles,
				}}
			>
				{children}
			</div>
		);
	}
}

Column.propTypes = {
	className: PropTypes.string,
	justify: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, 'left', 'center', 'right'])),
	]),
	align: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, 'top', 'center', 'bottom'])),
	]),
	width: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.string),
	]),
	minWidth: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.string),
	]),
	maxWidth: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.string),
	]),
	paddingTop: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.string),
	]),
	leftOffset: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(
			PropTypes.oneOf([
				null,
				'fill',
				'0',
				'1',
				'2',
				'3',
				'4',
				'5',
				'6',
				'7',
				'8',
				'9',
				'10',
				'11',
				'12',
			]),
		),
	]),
	rightOffset: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(
			PropTypes.oneOf([
				null,
				'fill',
				'0',
				'1',
				'2',
				'3',
				'4',
				'5',
				'6',
				'7',
				'8',
				'9',
				'10',
				'11',
				'12',
			]),
		),
	]),
	order: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.string),
	]),
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	useContentBox: PropTypes.bool,
	// eslint-disable-next-line react/forbid-prop-types
	style: PropTypes.object,
};

Column.defaultProps = {
	className: null,
	justify: null,
	align: null,
	width: null,
	minWidth: null,
	maxWidth: null,
	paddingTop: null,
	leftOffset: null,
	rightOffset: null,
	children: null,
	order: null,
	style: null,
	useContentBox: false,
};

export default Column;
