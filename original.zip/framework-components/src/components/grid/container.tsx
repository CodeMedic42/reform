// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';
import deprecateMessage from '../../common/deprecate-message';

function buildGutterClasses(gutter, prefix) {
	if (isNil(gutter)) {
		return null;
	}

	if (gutter === true) {
		return `${prefix}gutter-16`;
	}

	if (gutter === false) {
		return null;
	}

	if (isString(gutter)) {
		return `${prefix}gutter-${gutter}`;
	}

	const [base, medium, large, exLarge, exExLarge] = gutter;

	return classnames({
		[`${prefix}gutter-${base}`]: !isNil(base),
		[`${prefix}gutter-${medium}-md`]: !isNil(medium),
		[`${prefix}gutter-${large}-lg`]: !isNil(large),
		[`${prefix}gutter-${exLarge}-xl`]: !isNil(exLarge),
		[`${prefix}gutter-${exExLarge}-2xl`]: !isNil(exExLarge),
	});
}

class Container extends PureComponent {
	render() {
		const {
			className,
			gutter,
			sideGutter,
			topGutter,
			bottomGutter,
			children,
			hideOverflow,
			...rest
		} = this.props;

		if (!isNil(gutter)) {
			deprecateMessage(
				'Container.gutter',
				'The "gutter" property for the Grid Container component has been deprecated. Please use the "bottomGutter" property.',
			);
		}

		const finalBottomGutter = bottomGutter || gutter;

		const classNames = classnames(
			'grid-container',
			buildGutterClasses(finalBottomGutter, 'bottom-'),
			buildGutterClasses(sideGutter, 'side-'),
			buildGutterClasses(topGutter, 'top-'),
			className,
			{
				'hide-overflow': hideOverflow,
			},
		);

		return (
			<div {...rest} className={classNames}>
				{children}
			</div>
		);
	}
}

Container.propTypes = {
	className: PropTypes.string,
	gutter: PropTypes.oneOfType([
		PropTypes.bool,
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, '4', '8', '16', '24', '32'])),
	]),
	bottomGutter: PropTypes.oneOfType([
		PropTypes.bool,
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, '4', '8', '16', '24', '32'])),
	]),
	sideGutter: PropTypes.oneOfType([
		PropTypes.bool,
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, '4', '8', '16', '24', '32'])),
	]),
	topGutter: PropTypes.oneOfType([
		PropTypes.bool,
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, '4', '8', '16', '24', '32'])),
	]),
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	hideOverflow: PropTypes.bool,
};

Container.defaultProps = {
	className: null,
	gutter: null,
	bottomGutter: null,
	sideGutter: null,
	topGutter: null,
	children: null,
	hideOverflow: false,
};

export default Container;
