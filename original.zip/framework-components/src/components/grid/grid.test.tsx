// @ts-nocheck
import React from 'react';

import forEach from 'lodash-es/forEach';
import clone from 'lodash-es/clone';
import join from 'lodash-es/join';
import isNil from 'lodash-es/isNil';
import { Container, Row, Column } from '.';
import ResolutionHeader from './resolution-header';

function attributeTest(targetNode, expectedAttributes = []) {
	const attributesLength = expectedAttributes.length + 1; // Start at one because className probably exists.

	forEach(expectedAttributes, (attribute) => {
		const { name, value } = attribute;

		expect(targetNode.getAttribute(name)).toEqual(value);
	});

	expect(targetNode.attributes.length).toEqual(
		attributesLength,
		'Attributes length incorrect',
	);
}

function expectRootToBe(
	wrapper,
	rootClass,
	{ additionalClasses = [], additionalAttributes = [] } = {},
) {
	const rootNode = wrapper.getDOMNode();

	expect(rootNode.nodeName).toEqual('DIV');
	expect([...rootNode.classList])
		.toEqual(expect.arrayContaining([
			rootClass,
			...additionalClasses,
		]));

	attributeTest(rootNode, additionalAttributes);
}

function expectContainerRootToBe(wrapper, options) {
	return expectRootToBe(wrapper, 'grid-container', options);
}

function expectRowRootToBe(wrapper, options) {
	return expectRootToBe(wrapper, 'grid-row', options);
}

function expectColumnRootToBe(wrapper, options) {
	return expectRootToBe(wrapper, 'grid-col', options);
}

function mountComponent(ComponentUnderTest, props = {}) {
	const { children, ...rest } = props;

	return global.mountTo(
		<ComponentUnderTest {...rest}>{children}</ComponentUnderTest>,
	);
}

function setupNoPropsTest(setup, test) {
	it('With id prop', () => {
		const wrapper = setup();

		test(wrapper);
	});
}

function setupIdTest(setup, test) {
	it('With id prop', () => {
		const idProp = 'testId';
		const wrapper = setup({ id: idProp });

		test(wrapper, {
			additionalAttributes: [{ name: 'id', value: idProp }],
		});
	});
}

function setupChildrenTest(setup, test) {
	it('With children', () => {
		const children = 'testChildren';
		const wrapper = setup({ children });

		test(wrapper);
	});
}

function setupClassNameTest(setup, test) {
	it('With className prop', () => {
		const classNameProp = ['testClassName1', 'testClassName2'];
		const wrapper = setup({ className: join(classNameProp, ' ') });

		test(wrapper, {
			additionalClasses: classNameProp,
		});
	});
}

function setupBaseResponsePropTests(
	propName,
	propValue,
	setup,
	test,
	actualClass,
) {
	const classPrefix = !isNil(actualClass) ? actualClass : propName;

	it(`With ${propName} prop`, () => {
		const prop = propValue[0];
		const wrapper = setup({ [propName]: prop });

		test(wrapper, {
			additionalClasses: [`${classPrefix}-${prop}`],
		});
	});

	it(`With ${propName} prop as array`, () => {
		const prop = propValue;
		const wrapper = setup({ [propName]: prop });

		test(wrapper, {
			additionalClasses: [
				`${classPrefix}-${prop[0]}`,
				`${classPrefix}-${prop[1]}-md`,
				`${classPrefix}-${prop[2]}-lg`,
				`${classPrefix}-${prop[3]}-xl`,
				`${classPrefix}-${prop[4]}-2xl`,
			],
		});
	});

	it(`With ${propName} prop as array with missing items`, () => {
		const prop = clone(propValue);
		prop[1] = null;
		prop[3] = null;
		const wrapper = setup({ [propName]: prop });

		test(wrapper, {
			additionalClasses: [
				`${classPrefix}-${prop[0]}`,
				`${classPrefix}-${prop[2]}-lg`,
				`${classPrefix}-${prop[4]}-2xl`,
			],
		});
	});
}

function setupJustifyPropTest(setup, test) {
	setupBaseResponsePropTests(
		'justify',
		['right', 'center', 'left', 'center', 'right'],
		setup,
		test,
	);
}

function setupAlignPropTest(setup, test) {
	setupBaseResponsePropTests(
		'align',
		['top', 'center', 'bottom', 'center', 'top'],
		setup,
		test,
	);
}

function setupLeftOffsetPropTest(setup, test) {
	setupBaseResponsePropTests(
		'leftOffset',
		['5', '6', '7', '8', '9'],
		setup,
		test,
		'offset-left',
	);
}

function setupRightOffsetPropTest(setup, test) {
	setupBaseResponsePropTests(
		'rightOffset',
		['5', '6', '7', '8', '9'],
		setup,
		test,
		'offset-right',
	);
}

function setupGutterPropTest(setup, test, prefix = '') {
	const testValue = ['4', '8', '16', '24', '32'];

	setupBaseResponsePropTests(
		'gutter',
		testValue,
		setup,
		test,
		`${prefix}gutter`,
	);

	it('With gutter prop true', () => {
		const wrapper = setup({ gutter: true });

		test(wrapper, {
			additionalClasses: [`${prefix}gutter-16`],
		});
	});

	it('With gutter prop false', () => {
		const wrapper = setup({ gutter: false });

		test(wrapper);
	});
}

function setupExtendedGutterPropTest(setup, test) {
	it('With gutter prop h and v are true', () => {
		const prop = { h: '8', v: '8' };
		const wrapper = setup({ gutter: prop });

		test(wrapper, {
			additionalClasses: ['gutter-h-8', 'gutter-v-8'],
		});
	});
}

function setupWidthPropTest(setup, test) {
	const columnProp = ['5', '6', '7', '8', '9'];

	setupBaseResponsePropTests('width', columnProp, setup, test);

	const namedProp = ['fill', 'content', 'fill', 'content', 'fill'];

	setupBaseResponsePropTests('width', namedProp, setup, test);

	it(`With static prop`, () => {
		const prop = 'static:150';
		const wrapper = setup({ width: prop });

		test(wrapper, {
			additionalClasses: [`width-static`],
			additionalAttributes: [
				{ name: 'style', value: '--grid-col-static: 150px;' },
			],
		});
	});

	it(`With static prop`, () => {
		const prop = [
			'static:50',
			'static:100',
			'static:150',
			'static:200',
			'static:250',
		];
		const wrapper = setup({ width: prop });

		test(wrapper, {
			additionalClasses: [
				`width-static`,
				`width-static-md`,
				`width-static-lg`,
				`width-static-xl`,
				`width-static-2xl`,
			],
			additionalAttributes: [
				{
					name: 'style',
					value: join(
						[
							'--grid-col-static: 50px;',
							'--grid-col-static-md: 100px;',
							'--grid-col-static-lg: 150px;',
							'--grid-col-static-xl: 200px;',
							'--grid-col-static-2xl: 250px;',
						],
						' ',
					),
				},
			],
		});
	});
}

describe('Components', () => {
	describe('Grid', () => {
		describe('Container', () => {
			const setup = mountComponent.bind(this, Container);

			setupNoPropsTest(setup, expectContainerRootToBe);
			setupIdTest(setup, expectContainerRootToBe);
			setupClassNameTest(setup, expectContainerRootToBe);
			setupGutterPropTest(setup, expectContainerRootToBe, 'bottom-');
			setupChildrenTest(setup, expectContainerRootToBe);

			it('With hideOverflow prop', () => {
				const wrapper = setup({ hideOverflow: true });

				expectContainerRootToBe(wrapper, {
					additionalClasses: ['hide-overflow'],
				});
			});
		});

		describe('Row', () => {
			const setup = mountComponent.bind(this, Row);

			setupNoPropsTest(setup, expectRowRootToBe);
			setupIdTest(setup, expectRowRootToBe);
			setupClassNameTest(setup, expectRowRootToBe);
			setupJustifyPropTest(setup, expectRowRootToBe);
			setupAlignPropTest(setup, expectRowRootToBe);
			setupGutterPropTest(setup, expectRowRootToBe);
			setupExtendedGutterPropTest(setup, expectRowRootToBe);
			setupChildrenTest(setup, expectRowRootToBe);

			it('With before prop', () => {
				const wrapper = setup({ enableBefore: true });

				expectRowRootToBe(wrapper, {
					additionalClasses: ['before-on'],
				});
			});

			it('With after prop', () => {
				const wrapper = setup({ enableAfter: true });

				expectRowRootToBe(wrapper, {
					additionalClasses: ['after-on'],
				});
			});
		});

		describe('Column', () => {
			const setup = mountComponent.bind(this, Column);

			setupNoPropsTest(setup, expectColumnRootToBe);
			setupIdTest(setup, expectColumnRootToBe);
			setupClassNameTest(setup, expectColumnRootToBe);
			setupJustifyPropTest(setup, expectColumnRootToBe);
			setupAlignPropTest(setup, expectColumnRootToBe);
			setupWidthPropTest(setup, expectColumnRootToBe);
			setupLeftOffsetPropTest(setup, expectColumnRootToBe);
			setupRightOffsetPropTest(setup, expectColumnRootToBe);
			setupChildrenTest(setup, expectColumnRootToBe);
		});
	});

	describe('ResolutionHeader', () => {
		const setup = mountComponent.bind(this, ResolutionHeader);

		it('No Props', () => {
			const wrapper = setup();

			expectRootToBe(wrapper, 'resolution-header');
		});

		it('With sticky prop', () => {
			const wrapper = setup({ sticky: true });

			expectRootToBe(wrapper, 'resolution-header', {
				additionalClasses: ['sticky'],
			});
		});
	});
});
