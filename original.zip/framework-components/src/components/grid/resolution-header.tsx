// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import hiddenBuilder from '../../class-builders/hidden';

class ResolutionHeader extends PureComponent {
	render() {
		const { sticky } = this.props;

		return (
			<div className={classnames('resolution-header', { sticky })}>
				<h1
					className={classnames(
						'header-text',
						hiddenBuilder({ lt: '2xl' }),
					)}
				>
					DESKTOP: 2xl
				</h1>
				<h1
					className={classnames(
						'header-text',
						hiddenBuilder({ lt: 'xl', gt: 'xl' }),
					)}
				>
					DESKTOP: XL
				</h1>
				<h1
					className={classnames(
						'header-text',
						hiddenBuilder({ lt: 'lg', gt: 'lg' }),
					)}
				>
					DESKTOP: LG
				</h1>
				<h1
					className={classnames(
						'header-text',
						hiddenBuilder({ lt: 'md', gt: 'md' }),
					)}
				>
					TABLET: MD
				</h1>
				<h1
					className={classnames(
						'header-text',
						hiddenBuilder({ gt: 'sm' }),
					)}
				>
					MOBILE: SM
				</h1>
			</div>
		);
	}
}

ResolutionHeader.propTypes = {
	sticky: PropTypes.bool,
};

ResolutionHeader.defaultProps = {
	sticky: false,
};

export default ResolutionHeader;
