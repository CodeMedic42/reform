// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';
import isArray from 'lodash-es/isArray';
import deprecateMessage from '../../common/deprecate-message';

function buildClass(prop, prefix) {
	if (isNil(prop)) {
		return null;
	}

	if (isString(prop)) {
		return `${prefix}-${prop}`;
	}

	const [base, medium, large, exLarge, exExLarge] = prop;

	return classnames({
		[`${prefix}-${base}`]: !isNil(base),
		[`${prefix}-${medium}-md`]: !isNil(medium),
		[`${prefix}-${large}-lg`]: !isNil(large),
		[`${prefix}-${exLarge}-xl`]: !isNil(exLarge),
		[`${prefix}-${exExLarge}-2xl`]: !isNil(exExLarge),
	});
}

function buildGutterClassGroup(gutter, additionalPrefix) {
	if (isNil(gutter)) {
		return '';
	}

	if (isString(gutter)) {
		return `gutter-${additionalPrefix}${gutter}`;
	}

	if (!isArray(gutter)) {
		return null;
	}

	const [base, medium, large, exLarge, exExLarge] = gutter;

	return classnames({
		[`gutter-${additionalPrefix}${base}`]: !isNil(base),
		[`gutter-${additionalPrefix}${medium}-md`]: !isNil(medium),
		[`gutter-${additionalPrefix}${large}-lg`]: !isNil(large),
		[`gutter-${additionalPrefix}${exLarge}-xl`]: !isNil(exLarge),
		[`gutter-${additionalPrefix}${exExLarge}-2xl`]: !isNil(exExLarge),
	});
}

function buildGutterClasses(gutter) {
	if (gutter === true) {
		return 'gutter-16';
	}

	if (gutter === false) {
		return null;
	}

	const gutterClasses = buildGutterClassGroup(gutter, '');

	if (!isNil(gutterClasses)) {
		return gutterClasses;
	}

	const { h: hGutter, v: vGutter } = gutter;

	return classnames(
		buildGutterClassGroup(hGutter, 'h-'),
		buildGutterClassGroup(vGutter, 'v-'),
	);
}

class Row extends PureComponent {
	constructor(props) {
		super(props);

		const { enableBefore, enableAfter } = props;

		if (!isNil(enableBefore)) {
			deprecateMessage(
				'Row.enableBefore',
				'The "enableBefore" property for the Grid Row component has been deprecated. Please use the "before" property.',
			);
		}

		if (!isNil(enableAfter)) {
			deprecateMessage(
				'Row.enableAfter',
				'The "enableAfter" property for the Grid Row component has been deprecated. Please use the "after" property.',
			);
		}
	}

	render() {
		const {
			className,
			justify,
			align,
			gutter,
			enableBefore,
			enableAfter,
			children,
			before,
			after,
			...rest
		} = this.props;

		const beforeFinal =
			enableBefore === true && isNil(before) ? 'on' : before;
		const afterFinal = enableAfter === true && isNil(after) ? 'on' : after;

		const classNames = classnames(
			'grid-row',
			buildClass(justify, 'justify'),
			buildClass(align, 'align'),
			buildClass(beforeFinal, 'before'),
			buildClass(afterFinal, 'after'),
			buildGutterClasses(gutter),
			className,
		);

		return (
			<div {...rest} className={classNames}>
				{children}
			</div>
		);
	}
}

const gutterBasePropType = PropTypes.oneOfType([
	PropTypes.string,
	PropTypes.arrayOf(PropTypes.oneOf([null, '4', '8', '16', '24', '32'])),
]);

Row.propTypes = {
	className: PropTypes.string,
	justify: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, 'left', 'center', 'right'])),
	]),
	align: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, 'top', 'center', 'bottom'])),
	]),
	gutter: PropTypes.oneOfType([
		PropTypes.bool,
		gutterBasePropType,
		PropTypes.shape({
			h: gutterBasePropType,
			v: gutterBasePropType,
		}),
	]),
	enableBefore: PropTypes.bool,
	enableAfter: PropTypes.bool,
	before: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, 'on', 'off'])),
	]),
	after: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.arrayOf(PropTypes.oneOf([null, 'on', 'off'])),
	]),
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

Row.defaultProps = {
	className: null,
	justify: null,
	align: null,
	gutter: null,
	enableBefore: false,
	enableAfter: false,
	before: null,
	after: null,
	children: null,
};

export default Row;
