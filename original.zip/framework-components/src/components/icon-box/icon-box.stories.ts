// @ts-nocheck
import IconBox from '.';

export default {
	title: 'Icons/Icon Box',
	component: IconBox,
};

export { default as basic } from './stories/basic';
