// @ts-nocheck
import applyAnchorBinding from '../drop-down/anchor-binding';
import IconButton from './icon-button';

export default applyAnchorBinding(IconButton);
