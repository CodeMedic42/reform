// @ts-nocheck
import Icon from '.';

export default {
	title: 'Icons/Icon Button',
	component: Icon,
};

export { default as properties } from './stories/properties';
