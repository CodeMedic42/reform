// @ts-nocheck
import IconButton from './icon-button';

export default IconButton;
