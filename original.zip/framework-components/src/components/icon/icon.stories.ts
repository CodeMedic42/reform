// @ts-nocheck
import Icon from '.';

export default {
	title: 'Icons/Icons',
	component: Icon,
};

export { default as sizes } from './stories/sizes';
export { default as colors } from './stories/colors';
