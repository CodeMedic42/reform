// @ts-nocheck
import InputMessages from './input-messages';

export default InputMessages;
