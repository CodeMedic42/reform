// @ts-nocheck
import InstantButton from './instant-button';

export default InstantButton;
