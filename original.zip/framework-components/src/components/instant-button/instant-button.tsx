// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

function InstantButton(props) {
	const { className, children, ...rest } = props;

	return (
		// eslint-disable-next-line react/button-has-type
		<button className={classnames('ai-instant-btn', className)} {...rest}>
			{children}
		</button>
	);
}

InstantButton.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

InstantButton.defaultProps = {
	className: null,
	children: null,
};

export default InstantButton;
