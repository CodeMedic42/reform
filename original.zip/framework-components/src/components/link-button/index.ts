// @ts-nocheck
import LinkButton from './link-button';

export default LinkButton;
