// @ts-nocheck
import LinkButton from '.';

export default {
	title: 'Controls/LinkButton',
	component: LinkButton,
	argTypes: { onClick: { action: 'clicked' } },
};

export { default as basic } from './stories/basic';
