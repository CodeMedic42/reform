// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';

import Button from '../button';
import { schemeColorPropType } from '../../common/color-list';

function LinkButton(props) {
	const {
		id,
		className,
		size,
		color,
		children,
		hidden,
		disabled,
		onClick,
		onFocus,
		onBlur,
	} = props;
	return (
		<Button
			id={id}
			className={className}
			size={size}
			color={color}
			hidden={hidden}
			disabled={disabled}
			onClick={onClick}
			onFocus={onFocus}
			onBlur={onBlur}
			variant="opaque"
			noPadding
		>
			{children}
		</Button>
	);
}

LinkButton.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	color: schemeColorPropType,
	size: PropTypes.oneOf(['xl', 'lg', 'md', 'sm', 'xs']),
	hidden: PropTypes.bool,
	disabled: PropTypes.bool,
	onClick: PropTypes.func,
	onFocus: PropTypes.func,
	onBlur: PropTypes.func,
};

LinkButton.defaultProps = {
	id: null,
	className: null,
	children: null,
	color: 'primary',
	size: 'md',
	hidden: false,
	disabled: false,
	onClick: null,
	onFocus: null,
	onBlur: null,
};

export default LinkButton;
