// @ts-nocheck
import PageTitle from '.';

export default {
	title: 'Controls/Link',
	component: PageTitle,
};

export { default as preview } from './stories/preview';
export { default as basic } from './stories/basic';
