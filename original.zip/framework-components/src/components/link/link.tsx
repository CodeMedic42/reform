// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';

class Link extends PureComponent {
	constructor(props) {
		super(props);

		this.handleClick = this.handleClick.bind(this);
	}

	handleClick(event) {
		const { onClick, onClickMeta } = this.props;

		if (isNil(onClick)) {
			return null;
		}

		return onClick({ event, meta: onClickMeta });
	}

	render() {
		const {
			id,
			className,
			children,
			href,
			variant,
			asButton,
			target,
			underline,
			size,
			weight,
			disabled,
		} = this.props;

		const variantClass = !isNil(variant)
			? `variant-${variant}`
			: 'variant-normal';
		const weightClass = !isNil(weight) ? `weight-${weight}` : null;

		const props = {
			id,
			className: classnames(
				'ai-link',
				variantClass,
				weightClass,
				className,
				{
					underline,
					[`size-${size}`]: !isNil(size),
				},
			),
			onClick: this.handleClick,
			disabled,
		};

		if (asButton) {
			return (
				<button {...props} type="button">
					{children}
				</button>
			);
		}

		return (
			<a {...props} href={href} target={target}>
				{children}
			</a>
		);
	}
}

Link.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	variant: PropTypes.oneOf(['normal', 'grey']),
	underline: PropTypes.bool,
	disabled: PropTypes.bool,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
	href: PropTypes.string,
	asButton: PropTypes.bool,
	target: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	weight: PropTypes.oneOf(['bold', 'semi-bold', 'normal']),
};

Link.defaultProps = {
	id: null,
	className: null,
	variant: 'normal',
	disabled: false,
	href: null,
	onClick: null,
	onClickMeta: null,
	children: null,
	asButton: false,
	target: null,
	underline: false,
	size: null,
	weight: null,
};

export default Link;
