/* eslint-disable jsx-a11y/anchor-is-valid */
// @ts-nocheck
import React from 'react';
import Link from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	return (
		<>
			<Scope title="Default" SpecimenContainer={null}>
				<Link href="http://www.apple.com" target="_blank">
					Apple
				</Link>
			</Scope>
			<Scope title="As Button" SpecimenContainer={null}>
				<Link asButton>Apple</Link>
			</Scope>
			<Scope title="Underline" SpecimenContainer={null}>
				<Link href="http://www.apple.com" underline target="_blank">
					Apple
				</Link>
			</Scope>
			<Scope title="grey" SpecimenContainer={null}>
				<Link
					href="http://www.apple.com"
					variant="grey"
					target="_blank"
				>
					Apple
				</Link>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
