// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import Link from '..';

function example(props) {
	return (
		<Scope fillViewport>
			<Link {...props} />
		</Scope>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		children: {
			control: 'text',
		},
		underline: {
			control: 'boolean',
		},
		disabled: {
			control: 'boolean',
		},
		asButton: {
			control: 'boolean',
		},
		href: {
			control: 'text',
			if: { arg: 'asButton', truthy: false },
			description:
				'The href for the anchor. Will not be used if asAnchor is false.',
		},
		target: {
			control: 'text',
			if: { arg: 'asButton', truthy: false },
			description:
				'The target for the anchor. Will not be used if asAnchor is false.',
		},
		size: {
			options: ['xl', 'lg', 'md', 'sm', 'xs'],
			control: { type: 'select' },
		},
		weight: {
			options: ['bold', 'semi-bold', 'normal'],
			control: { type: 'select' },
		},
		variant: {
			options: ['normal', 'grey'],
			control: { type: 'select' },
		},
		onClick: { table: { disable: true } },
		onClickMeta: { table: { disable: true } },
	},
	args: {
		children: 'Audacious Inquiry',
		underline: false,
		disabled: false,
		asButton: false,
		href: 'https://ainq.com/',
		target: '_blank',
	}
};

export default example;
