// @ts-nocheck
import MaskInput from '.';

export default {
	title: 'Inputs/Mask Input',
	component: MaskInput,
};

export { default as basic } from './stories/basic';
export { default as messages } from './stories/messages';
export { default as sizes } from './stories/sizes';
export { default as icons } from './stories/icons';
