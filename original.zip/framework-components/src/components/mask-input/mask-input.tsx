// @ts-nocheck
import React from 'react';
import classnames from 'classnames';
import { faEye } from '@audacious/icons/solid/faEye';
import { faEyeSlash } from '@audacious/icons/solid/faEyeSlash';
import InputLabel, {
	propTypes as inputLabelPropTypes,
	defaultProps as inputLabelDefaultProps,
} from '../base-input/input-label';
import BaseMaskInput from '../base-input/base-mask-input';
import PropTypes from '../../common/prop-types';

class MaskInput extends React.PureComponent {
	constructor(props) {
		super(props);

		this.inputRef = React.createRef();

		this.toggleVisible = this.toggleVisible.bind(this);

		this.state = {
			visible: false,
		};
	}

	static getDerivedStateFromProps(nextProps, currentState) {
		const { disabled, secure } = nextProps;

		const { visible } = currentState;

		return {
			type: secure && (!visible || disabled) ? 'password' : 'text',
		};
	}

	getInputElement() {
		return this.inputRef.current.getInputElement();
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	focus() {
		const { disabled } = this.props;

		if (disabled) {
			return;
		}

		this.getInputElement().focus();
	}

	toggleVisible() {
		const { visible } = this.state;

		this.setState({
			visible: !visible,
		});
	}

	render() {
		const {
			className,
			id,
			label,
			value,
			messages,
			invalid,
			'aria-labelledby': ariaLabelledby,
			'aria-describedby': ariaDescribedby,
			hidden,
			disabled,
			onChange,
			onClear,
			placeholder,
			title,
			name,
			onFocus,
			onBlur,
			onKeyPress,
			onKeyDown,
			onKeyUp,
			minLength,
			maxLength,
			required,
			autoComplete,
			'aria-label': ariaLabel,
			showFocused,
			leftIcon,
			pattern,
			mask,
			guide,
			keepCharPositions,
			focusOnMount,
			size,
			secure,
		} = this.props;

		let { rightIcon } = this.props;

		const { type } = this.state;

		if (secure) {
			rightIcon = {
				icon: type === 'password' ? faEye : faEyeSlash,
				onClick: this.toggleVisible,
				overrideClear: true,
			};
		}

		return (
			<InputLabel
				className={classnames('ai-text-input', className)}
				id={id}
				label={label}
				messages={messages}
				invalid={invalid}
				aria-labelledby={ariaLabelledby}
				aria-describedby={ariaDescribedby}
				hidden={hidden}
				disabled={disabled}
				size={size}
			>
				{({ describedBy, labelledBy, inputId }) => (
					<BaseMaskInput
						ref={this.inputRef}
						id={inputId}
						value={value}
						valueType="string"
						disabled={disabled}
						onChange={onChange}
						onClear={onClear}
						size={size}
						leftIcon={leftIcon}
						rightIcon={rightIcon}
						type={type}
						className={classnames({
							focus: showFocused,
						})}
						placeholder={placeholder}
						title={title}
						name={name}
						onFocus={onFocus}
						onBlur={onBlur}
						onKeyPress={onKeyPress}
						onKeyDown={onKeyDown}
						onKeyUp={onKeyUp}
						minLength={minLength}
						maxLength={maxLength}
						required={required}
						pattern={pattern}
						autoComplete={autoComplete}
						aria-label={ariaLabel}
						aria-labelledby={labelledBy}
						aria-describedby={describedBy}
						mask={mask}
						showMask
						guide={guide}
						keepCharPositions={keepCharPositions}
						focusOnMount={focusOnMount}
					/>
				)}
			</InputLabel>
		);
	}
}

MaskInput.propTypes = {
	...inputLabelPropTypes,
	secure: PropTypes.bool,
	value: PropTypes.string,
	onChange: PropTypes.func,
	leftIcon: PropTypes.shape({
		name: PropTypes.icon.isRequired,
		onClick: PropTypes.func,
	}),
	disabled: PropTypes.bool,
	placeholder: PropTypes.string,
	minLength: PropTypes.number,
	maxLength: PropTypes.number,
	required: PropTypes.bool,
	pattern: PropTypes.instanceOf(RegExp),
	title: PropTypes.string,
	'aria-label': PropTypes.string,
	name: PropTypes.string,
	focusOnMount: PropTypes.bool,
	onClear: PropTypes.func,
	onFocus: PropTypes.func,
	onBlur: PropTypes.func,
	onKeyPress: PropTypes.func,
	onKeyDown: PropTypes.func,
	onKeyUp: PropTypes.func,
	rightIcon: PropTypes.shape({
		name: PropTypes.icon.isRequired,
		onClick: PropTypes.func,
	}),
	autoComplete: PropTypes.oneOf(['on', 'off']),
	showFocused: PropTypes.bool,
	guide: PropTypes.bool,
	keepCharPositions: PropTypes.bool,
	mask: PropTypes.oneOfType([
		PropTypes.func,
		PropTypes.arrayOf(
			PropTypes.oneOfType([
				PropTypes.string,
				PropTypes.instanceOf(RegExp),
			]),
		),
	]).isRequired,
};

MaskInput.defaultProps = {
	...inputLabelDefaultProps,
	secure: false,
	value: null,
	onChange: null,
	leftIcon: null,
	disabled: false,
	required: null,
	placeholder: null,
	title: null,
	minLength: null,
	maxLength: null,
	pattern: null,
	'aria-label': null,
	name: null,
	focusOnMount: false,
	onClear: null,
	onFocus: null,
	onBlur: null,
	onKeyPress: null,
	onKeyDown: null,
	onKeyUp: null,
	rightIcon: null,
	autoComplete: 'off',
	showFocused: false,
	guide: false,
	keepCharPositions: false,
};

export default MaskInput;
