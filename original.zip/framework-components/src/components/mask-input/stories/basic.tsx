// @ts-nocheck
import React from 'react';
import MaskInput from '..';
import Scope from '../../../../.storybook/components/scope';
import { Row, Column } from '../../grid';

const mask = [
	'(',
	/[1-9]/,
	/\d/,
	/\d/,
	')',
	' ',
	/\d/,
	/\d/,
	/\d/,
	'-',
	/\d/,
	/\d/,
	/\d/,
	/\d/,
];

const ssn4Mask = [/\d/, /\d/, /\d/, /\d/];
const ssn9Mask = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];

function example() {
	const [value, setValue] = React.useState(null);

	return (
		<>
			<Scope title="Simple">
				<MaskInput
					label="Mask Input"
					value={value}
					onChange={setValue}
					mask={mask}
				/>
			</Scope>
			<Scope title="Placeholder">
				<MaskInput
					label="Mask Input"
					placeholder="Placeholder"
					value={value}
					onChange={setValue}
					mask={mask}
				/>
			</Scope>
			<Scope title="With Guide">
				<MaskInput
					label="Mask Input"
					value={value}
					onChange={setValue}
					mask={mask}
					guide
				/>
			</Scope>
			<Scope title="Disabled">
				<MaskInput
					label="Mask Input"
					value={value}
					disabled
					onChange={setValue}
					mask={mask}
				/>
			</Scope>
			<Scope title="Hidden">
				<MaskInput
					label="Mask Input"
					value={value}
					hidden
					onChange={setValue}
					mask={mask}
				/>
			</Scope>
			<Scope title="Secure">
				<MaskInput
					label="Text Input"
					value={value}
					onChange={setValue}
					secure
					mask={mask}
				/>
			</Scope>
			<Scope title="Mask Function">
				<MaskInput
					label="Mask Input"
					value={value}
					onChange={setValue}
					mask={(rawValue) => {
						if (rawValue.replace('-', '').length <= 4) {
							return ssn4Mask
						}

						return ssn9Mask;
					}}
				/>
			</Scope>
			<Scope title="Labels">
				<Row gutter>
					<Column width="4">
						<MaskInput
							value={value}
							onChange={setValue}
							label="with label"
							mask={mask}
						/>
					</Column>
					<Column width="4">
						<MaskInput
							value={value}
							onChange={setValue}
							label=""
							mask={mask}
						/>
					</Column>
					<Column width="4">
						<MaskInput
							value={value}
							onChange={setValue}
							mask={mask}
						/>
					</Column>
				</Row>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
