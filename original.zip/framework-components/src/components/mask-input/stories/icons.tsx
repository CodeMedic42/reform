/* eslint-disable no-alert */
// @ts-nocheck
import React from 'react';
import { faMagnifyingGlass } from '@audacious/icons/regular/faMagnifyingGlass';
import MaskInput from '..';
import Scope from '../../../../.storybook/components/scope';

const mask = [
	'(',
	/[1-9]/,
	/\d/,
	/\d/,
	')',
	' ',
	/\d/,
	/\d/,
	/\d/,
	'-',
	/\d/,
	/\d/,
	/\d/,
	/\d/,
];

function example() {
	const [value, setValue] = React.useState(null);

	return (
		<>
			<Scope title="Simple">
				<MaskInput
					id="example"
					label="Mask Input"
					value={value}
					onChange={setValue}
					leftIcon={{
						icon: faMagnifyingGlass,
						onClick: () => alert('clicked'),
					}}
					rightIcon={{
						icon: faMagnifyingGlass,
						onClick: () => alert('clicked'),
					}}
					size="sm"
					mask={mask}
				/>
			</Scope>
			<Scope title="Simple">
				<MaskInput
					id="example"
					label="Mask Input"
					value={value}
					onChange={setValue}
					leftIcon={{
						icon: faMagnifyingGlass,
					}}
					rightIcon={{
						icon: faMagnifyingGlass,
					}}
					size="sm"
					mask={mask}
				/>
			</Scope>
			<Scope title="Simple">
				<MaskInput
					id="example"
					label="Mask Input"
					value={value}
					onChange={setValue}
					leftIcon={{
						icon: faMagnifyingGlass,
						onClick: () => alert('clicked'),
					}}
					rightIcon={{
						icon: faMagnifyingGlass,
						onClick: () => alert('clicked'),
					}}
					mask={mask}
				/>
			</Scope>
			<Scope title="Simple">
				<MaskInput
					id="example"
					label="Mask Input"
					value={value}
					onChange={setValue}
					leftIcon={{
						icon: faMagnifyingGlass,
					}}
					rightIcon={{
						icon: faMagnifyingGlass,
					}}
					mask={mask}
				/>
			</Scope>
			<Scope title="Simple">
				<MaskInput
					id="example"
					label="Mask Input"
					value={value}
					onChange={setValue}
					leftIcon={{
						icon: faMagnifyingGlass,
						onClick: () => alert('clicked'),
					}}
					rightIcon={{
						icon: faMagnifyingGlass,
						onClick: () => alert('clicked'),
					}}
					size="lg"
					mask={mask}
				/>
			</Scope>
			<Scope title="Simple">
				<MaskInput
					id="example"
					label="Mask Input"
					value={value}
					onChange={setValue}
					leftIcon={{
						icon: faMagnifyingGlass,
					}}
					rightIcon={{
						icon: faMagnifyingGlass,
					}}
					size="lg"
					mask={mask}
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Icons',
};

export default example;
