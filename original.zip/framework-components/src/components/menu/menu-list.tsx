// @ts-nocheck
import React, { PureComponent, createRef } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import DropDownList from '../drop-down/drop-down-list';

class MenuList extends PureComponent {
	constructor(...args) {
		super(...args);

		this.listRef = createRef();
	}

	// eslint-disable-next-line react/no-unused-class-component-methods
	getRootNode() {
		return this.listRef.current.getRootNode();
	}

	render() {
		const { className, children, ...rest } = this.props;

		return (
			<DropDownList
				{...rest}
				ref={this.listRef}
				className={classnames('ai-menu-list', className)}
			>
				{children}
			</DropDownList>
		);
	}
}

MenuList.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

MenuList.defaultProps = {
	id: null,
	className: null,
	children: null,
};

export default MenuList;
