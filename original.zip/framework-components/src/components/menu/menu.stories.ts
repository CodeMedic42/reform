// @ts-nocheck
import Menu from '.';

export default {
	title: 'Controls/Menu',
	component: Menu,
};

export { default as preview } from './stories/preview';
export { default as basics } from './stories/basics';
export { default as sizes } from './stories/sizes';
