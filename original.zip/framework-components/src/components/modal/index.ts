// @ts-nocheck
import Modal from './modal';

export default Modal;
