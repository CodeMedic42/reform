// @ts-nocheck
import Modal from './modal';

export default {
	title: 'Layout/Modal',
	component: Modal,
};

export { default as preview } from './stories/preview';
