// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Dialog from '../dialog-base';

function Modal(props) {
	const { className, size, fitVertically } = props;

	return (
		<Dialog
			{...props}
			className={classnames('ai-modal', className, { 'fit-vertically': fitVertically })}
			backdropVariant="dark"
			spinnerSize={size === 'sm' || size === 'xs' ? 'md' : 'lg'}
			spinnerAlignment={size === 'sm' || size === 'xs' ? 'sm' : 'md'}
		/>
	);
}

Modal.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	open: PropTypes.bool,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	onClose: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onCloseMeta: PropTypes.object,
	enableCloseButton: PropTypes.bool,
	enableCloseOnOffClick: PropTypes.bool,
	// Set to true while data is being retrieved to display in the dialog
	isLoading: PropTypes.bool,
	// Set to true while data entered on the dialog is being saved
	isSaving: PropTypes.bool,
	fitVertically: PropTypes.bool,
};

Modal.defaultProps = {
	id: null,
	className: null,
	open: false,
	children: null,
	onClose: null,
	onCloseMeta: null,
	enableCloseButton: false,
	enableCloseOnOffClick: null,
	isLoading: false,
	isSaving: false,
	size: 'md',
	fitVertically: false,
};

export default Modal;
