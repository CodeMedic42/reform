// @ts-nocheck
import MultiSelectInput from './multi-select-input';

export default MultiSelectInput;
