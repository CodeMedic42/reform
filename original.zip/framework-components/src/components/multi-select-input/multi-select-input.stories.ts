// @ts-nocheck
import MultiSelectInput from '.';

export default {
	title: 'Inputs/Multi Select Input',
	component: MultiSelectInput,
};

export { default as preview } from './stories/preview';
export { default as sizes } from './stories/sizes';
export { default as messages } from './stories/messages';
export { default as options } from './stories/options';
export { default as miscellaneous } from './stories/miscellaneous';
