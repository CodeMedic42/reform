// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Select, {
	propTypes as selectPropTypes,
	defaultProps as selectDefaultProps,
} from '../select';
import MultiSelectAnchor from './multi-select-anchor';

class MultiSelectInput extends React.PureComponent {
	render() {
		const { className, expandable, ...rest } = this.props;

		return (
			<Select
				{...rest}
				className={classnames(
					'ai-select-input',
					'ai-multi-select',
					className,
					{
						expandable,
					},
				)}
				Anchor={MultiSelectAnchor}
				useFilter
				isMultiSelect
			/>
		);
	}
}

MultiSelectInput.propTypes = {
	...selectPropTypes,
	value: PropTypes.arrayOf(
		PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	),
	expandable: PropTypes.bool,
};

MultiSelectInput.defaultProps = {
	...selectDefaultProps,
	value: null,
	expandable: false,
};

export default MultiSelectInput;
