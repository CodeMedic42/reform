// @ts-nocheck
import React from 'react';
import MultiSelectInput from '..';
import Scope from '../../../../.storybook/components/scope';
import { textOnly } from '../../../common/storybook/options-data';

function example() {
	return (
		<>
			<Scope title="Placeholder">
				{(state, setState) => (
					<MultiSelectInput
						label="Select your favorite doughnuts"
						value={state.value}
						options={textOnly}
						onChange={(value) => setState({ value })}
						placeholder="Placeholder"
					/>
				)}
			</Scope>
			<Scope title="Disabled">
				{(state, setState) => (
					<MultiSelectInput
						label="Select your favorite doughnuts"
						value={state.value}
						options={textOnly}
						onChange={(value) => setState({ value })}
						disabled
					/>
				)}
			</Scope>
			<Scope title="Hidden">
				{(state, setState) => (
					<MultiSelectInput
						label="Select your favorite doughnuts"
						value={state.value}
						options={textOnly}
						onChange={(value) => setState({ value })}
						hidden
					/>
				)}
			</Scope>
			<Scope title="Not Nullable">
				{(state, setState) => (
					<MultiSelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={textOnly}
						onChange={(value) => setState({ value })}
						nullable={false}
					/>
				)}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Miscellaneous',
};

export default example;
