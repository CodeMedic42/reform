// @ts-nocheck
import React, { useState } from 'react';
import MultiSelectInput from '..';
import Scope from '../../../../.storybook/components/scope';
import { textOnly } from '../../../common/storybook/options-data';
import CheckInput from '../../check-input';

const ini = [
	'Bear Claw',
	'Apple-Crumb',
	'Jelly',
	'Powdered',
	'Glazed',
	'Cinnamon-Sugar',
	'Blueberry',
	'Chocolate Kreme',
	'Bavarian Kreme',
	'Boston Kreme',
	'Old-Fashioned',
	'Sour Cream',
	'Cruller',
	'Strawberry.Frosted.Creme.Filled.with.Extra.Sprinkles',
	'Chocolate Glazed',
];

function example() {
	const [value, setValue] = useState(ini);
	const [expandable, setExpandable] = useState(true);
	const [disabled, setDisabled] = useState(false);

	return (
		<>
			<CheckInput
				id="expandableCheck"
				label="Expandable"
				value={expandable}
				onChange={() => {
					setExpandable(!expandable);
				}}
			/>
			<CheckInput
				id="disabeldCheck"
				label="Disabled"
				value={disabled}
				onChange={() => {
					setDisabled(!disabled);
				}}
			/>
			<Scope title="No Size(Default size-md)">
				<MultiSelectInput
					label="Select Input"
					value={value}
					options={textOnly}
					onChange={setValue}
					expandable={expandable}
					disabled={disabled}
				/>
			</Scope>
			<Scope title="Size SM">
				<MultiSelectInput
					label="Select Input"
					value={value}
					options={textOnly}
					onChange={setValue}
					size="sm"
					expandable={expandable}
					disabled={disabled}
				/>
			</Scope>
			<Scope title="Size MD">
				<MultiSelectInput
					label="Select Input"
					value={value}
					options={textOnly}
					onChange={setValue}
					size="md"
					expandable={expandable}
					disabled={disabled}
				/>
			</Scope>
			<Scope title="Size LG">
				<MultiSelectInput
					label="Select Input"
					value={value}
					options={textOnly}
					onChange={setValue}
					size="lg"
					expandable={expandable}
					disabled={disabled}
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Sizes and Expandable',
};

export default example;
