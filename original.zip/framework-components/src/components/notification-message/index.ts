// @ts-nocheck
import NotificationMessage from './notification-message';

export default NotificationMessage;
