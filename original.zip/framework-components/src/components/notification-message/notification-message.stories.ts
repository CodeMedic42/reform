// @ts-nocheck
import NotificationMessage from '.';

export default {
	title: 'Messaging/Notification Message',
	component: NotificationMessage,
};

export { default as properties } from './stories/properties';
