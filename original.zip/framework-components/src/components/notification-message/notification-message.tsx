// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import map from 'lodash-es/map';
import { faCircleExclamation } from '@audacious/icons/solid/faCircleExclamation';
import { faCircleInfo } from '@audacious/icons/solid/faCircleInfo';
import { faCircleCheck } from '@audacious/icons/solid/faCircleCheck';
import { faTriangleExclamation } from '@audacious/icons/solid/faTriangleExclamation';
import Icon from '../icon';
import Button from '../button';
import ButtonGroup from '../button-group';

class NotificationMessage extends PureComponent {
	renderIcon() {
		const { showIcon, color } = this.props;

		if (!showIcon) {
			return null;
		}

		let icon = null;

		if (color === 'info') {
			icon = faCircleInfo;
		}

		if (color === 'success') {
			icon = faCircleCheck;
		}

		if (color === 'warn') {
			icon = faTriangleExclamation;
		}

		if (color === 'danger') {
			icon = faCircleExclamation;
		}

		if (color === 'primary') {
			icon = faCircleInfo;
		}

		if (color === 'secondary') {
			icon = faCircleInfo;
		}

		if (!isNil(icon)) {
			return <Icon className="notification-message-icon" icon={icon} />;
		}

		return null;
	}

	renderActions() {
		const { actions, color } = this.props;

		if (isNil(actions) || actions.length <= 0) {
			return null;
		}

		return (
			<ButtonGroup>
				{map(actions, (action, index) => (
					<Button
						key={index}
						className="notification-message-action-btn"
						size="md"
						variant={index <= 0 ? 'fill' : 'opaque'}
						onClick={action.onClick}
						onClickMeta={action.onClickMeta}
						color={
							action.matchColor && !isNil(color)
								? color
								: 'secondary'
						}
						useDark
					>
						{action.label}
					</Button>
				))}
			</ButtonGroup>
		);
	}

	render() {
		const { id, className, heading, message, color } = this.props;

		return (
			<div
				id={id}
				className={classnames('ai-notification-message', className, {
					[`notification-message-${color}`]: !isNil(color),
				})}
			>
				{this.renderIcon()}
				<div className="notification-message-content">
					{!isNil(heading) ? (
						<span className="notification-message-heading">
							{heading}
						</span>
					) : null}
					<div className="notification-message-text">{message}</div>
					{this.renderActions()}
				</div>
			</div>
		);
	}
}

NotificationMessage.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	heading: PropTypes.string,
	message: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
		PropTypes.string,
	]).isRequired,
	color: PropTypes.string,
	actions: PropTypes.arrayOf(
		PropTypes.shape({
			label: PropTypes.string.isRequired,
			onClick: PropTypes.func.isRequired,
			// eslint-disable-next-line react/forbid-prop-types
			onClickMeta: PropTypes.any,
			matchColor: PropTypes.bool,
		}),
	),
	showIcon: PropTypes.bool,
};

NotificationMessage.defaultProps = {
	id: null,
	className: null,
	heading: null,
	actions: null,
	showIcon: false,
	color: null,
};

export default NotificationMessage;
