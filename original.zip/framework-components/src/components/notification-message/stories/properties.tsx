/* eslint-disable no-alert */
// @ts-nocheck
import React from 'react';
import NotificationMessage from '..';
import Scope from '../../../../.storybook/components/scope';
import TextInput from '../../text-input';
import CheckInput from '../../check-input';
import ColorSelector from '../../../common/storybook/color-selector';

function example() {
	const [showIcon, setShowIcon] = React.useState(false);
	const [showActions, setShowActions] = React.useState(false);
	const [matchColor, setMathColor] = React.useState(false);
	const [heading, setHeading] = React.useState(null);
	const [color, setColor] = React.useState('info');

	const renderControls = () => (
		<>
			<div className="gutter-vertical">
				<CheckInput
					id="show-icon"
					label="Show Icon"
					value={showIcon}
					onChange={() => setShowIcon(!showIcon)}
				/>
			</div>
			<div className="gutter-vertical">
				<CheckInput
					id="show-action"
					label="Show Action"
					value={showActions}
					onChange={() => setShowActions(!showActions)}
				/>
			</div>
			<div className="gutter-vertical">
				<CheckInput
					id="match-color"
					label="Match Color"
					value={matchColor}
					onChange={() => setMathColor(!matchColor)}
				/>
			</div>
			<div className="gutter-vertical">
				<TextInput
					id="heading-value"
					label="Heading"
					value={heading}
					onChange={(value) => setHeading(value)}
				/>
			</div>
			<div className="gutter-vertical">
				<ColorSelector
					color={color}
					onChange={(value) => setColor(value)}
				/>
			</div>
		</>
	);

	let actions = null;

	if (showActions) {
		actions = [
			{
				label: 'Execute',
				onClick: () => alert('Clicked'),
				matchColor,
			},
			{
				label: 'Cancel',
				onClick: () => alert('Clicked'),
				matchColor,
			},
		];
	}

	return (
		<Scope title="Alert Message" controls={renderControls()}>
			<NotificationMessage
				color={color}
				showIcon={showIcon}
				heading={heading}
				message="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor ut labore Lorem ipsum dolor sit amet."
				actions={actions}
			/>
		</Scope>
	);
}

example.story = {
	name: 'Properties',
};

export default example;
