// @ts-nocheck
import NumericInput from './numeric-input';

export default NumericInput;
