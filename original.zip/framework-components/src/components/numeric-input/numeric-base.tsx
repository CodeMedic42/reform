// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import isNil from 'lodash-es/isNil';
import isNaN from 'lodash-es/isNaN';
import toString from 'lodash-es/toString';

function getNumericValue(value) {
	if (isNil(value)) {
		return '';
	}

	if (isNaN(value)) {
		return '';
	}

	return toString(value);
}

class NumericBaseForwarded extends PureComponent {
	constructor(props) {
		super(props);

		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(event) {
		const {
			target: { value, valueAsNumber, validity },
		} = event;

		const { onChange } = this.props;

		onChange(validity.badInput || value.length > 0 ? valueAsNumber : null);
	}

	render() {
		const { onChange, value, forwardedRef, ...rest } = this.props;

		return (
			<input
				ref={forwardedRef}
				value={getNumericValue(value)}
				onChange={this.handleChange}
				{...rest}
			/>
		);
	}
}

NumericBaseForwarded.propTypes = {
	onChange: PropTypes.func.isRequired,
	value: PropTypes.number,
	// eslint-disable-next-line react/forbid-prop-types
	forwardedRef: PropTypes.object,
};

NumericBaseForwarded.defaultProps = {
	forwardedRef: null,
	value: null,
};

const NumericBase = React.forwardRef((props, ref) => (
	<NumericBaseForwarded {...props} forwardedRef={ref} />
));

NumericBase.displayName = 'NumericBase';

export default NumericBase;
