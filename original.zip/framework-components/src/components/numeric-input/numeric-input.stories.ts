// @ts-nocheck
import NumericInput from '.';

export default {
	title: 'Inputs/Numeric Input',
	component: NumericInput,
};

export { default as preview } from './stories/preview';
export { default as basic } from './stories/basic';
export { default as sizes } from './stories/sizes';
export { default as messages } from './stories/messages';
