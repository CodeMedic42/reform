// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import InputLabel, {
	propTypes as inputLabelPropTypes,
	defaultProps as inputLabelDefaultProps,
} from '../base-input/input-label';
import BaseCursorInput, {
	propTypes as baseCursorInputPropTypes,
	defaultProps as baseCursorInputDefaultProps,
} from '../base-input/base-cursor-input';
import NumericBase from './numeric-base';

class NumericInput extends React.PureComponent {
	constructor(props) {
		super(props);

		this.inputRef = React.createRef();

		this.handleWillChange = this.handleWillChange.bind(this);
		this.handleClear = this.handleClear.bind(this);
	}

	componentDidMount() {
		const { focusOnMount } = this.props;

		if (focusOnMount && this.inputRef && this.inputRef.current) {
			this.focus();
		}
	}

	// eslint-disable-next-line class-methods-use-this
	handleWillChange(event) {
		const {
			target: { value, valueAsNumber, validity },
		} = event;

		if (validity.badInput || value.length > 0) {
			return valueAsNumber;
		}

		return null;
	}

	handleClear() {
		const { onClear } = this.props;

		this.inputRef.current.value = '';

		if (!isNil(onClear)) {
			onClear();
		}
	}

	getInputElement() {
		return this.inputRef.current;
	}

	focus() {
		const { disabled } = this.props;

		if (disabled) {
			return;
		}

		this.getInputElement().focus();
	}

	render() {
		const {
			className,
			id,
			label,
			messages,
			invalid,
			'aria-labelledby': ariaLabelledby,
			'aria-describedby': ariaDescribedby,
			hidden,
			disabled,
			onChange,
			rightIcon,
			placeholder,
			title,
			name,
			onFocus,
			onBlur,
			onKeyPress,
			onKeyDown,
			onKeyUp,
			min,
			max,
			required,
			autoComplete,
			'aria-label': ariaLabel,
			showFocused,
			leftIcon,
			size,
			value,
		} = this.props;

		return (
			<InputLabel
				className={classnames('ai-text-input', className)}
				id={id}
				label={label}
				messages={messages}
				invalid={invalid}
				aria-labelledby={ariaLabelledby}
				aria-describedby={ariaDescribedby}
				hidden={hidden}
				disabled={disabled}
				size={size}
			>
				{({ describedBy, labelledBy, inputId }) => (
					<BaseCursorInput
						id={inputId}
						value={value}
						valueType="number"
						disabled={disabled}
						onChange={onChange}
						onClear={this.handleClear}
						size={size}
						leftIcon={leftIcon}
						rightIcon={rightIcon}
					>
						{({ value: baseValue, onChange: baseOnChange }) => (
							<NumericBase
								ref={this.inputRef}
								id={inputId}
								value={baseValue}
								onChange={baseOnChange}
								type="number"
								className={classnames({
									focus: showFocused,
									'has-value': !isNil(value),
								})}
								placeholder={placeholder}
								title={title}
								disabled={disabled}
								name={name}
								onFocus={onFocus}
								onBlur={onBlur}
								onKeyPress={onKeyPress}
								onKeyDown={onKeyDown}
								onKeyUp={onKeyUp}
								min={min}
								max={max}
								required={required}
								autoComplete={autoComplete}
								aria-label={ariaLabel}
								aria-labelledby={labelledBy}
								aria-describedby={describedBy}
							/>
						)}
					</BaseCursorInput>
				)}
			</InputLabel>
		);
	}
}

NumericInput.propTypes = {
	...inputLabelPropTypes,
	...baseCursorInputPropTypes,
	placeholder: PropTypes.string,
	min: PropTypes.number,
	max: PropTypes.number,
	required: PropTypes.bool,
	title: PropTypes.string,
	'aria-label': PropTypes.string,
	name: PropTypes.string,
	focusOnMount: PropTypes.bool,
	onFocus: PropTypes.func,
	onBlur: PropTypes.func,
	onKeyPress: PropTypes.func,
	onKeyDown: PropTypes.func,
	onKeyUp: PropTypes.func,
	autoComplete: PropTypes.oneOf(['on', 'off']),
	showFocused: PropTypes.bool,
};

NumericInput.defaultProps = {
	...inputLabelDefaultProps,
	...baseCursorInputDefaultProps,
	required: null,
	placeholder: null,
	title: null,
	min: null,
	max: null,
	'aria-label': null,
	name: null,
	focusOnMount: false,
	onFocus: null,
	onBlur: null,
	onKeyPress: null,
	onKeyDown: null,
	onKeyUp: null,
	autoComplete: 'off',
	showFocused: false,
};

export default NumericInput;
