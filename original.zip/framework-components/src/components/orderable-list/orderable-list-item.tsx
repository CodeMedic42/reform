// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { Draggable } from 'react-beautiful-dnd';
import { faBars } from '@audacious/icons/solid/faBars';
import IconBox from '../icon-box';

class OrderableListItem extends PureComponent {
	render() {
		const { id, index, children } = this.props;

		return (
			<Draggable draggableId={id} index={index}>
				{(provided, snapshot) => {
					const { isDragging } = snapshot;

					return (
						<div
							ref={provided.innerRef}
							{...provided.draggableProps}
							className={classnames('ai-orderable-list-item', {
								'is-dragging': isDragging,
							})}
							style={provided.draggableProps.style}
						>
							{children}
							<span
								{...provided.dragHandleProps}
								className="drag-handle"
							>
								<IconBox icon={faBars} size="md" />
							</span>
						</div>
					);
				}}
			</Draggable>
		);
	}
}

OrderableListItem.propTypes = {
	id: PropTypes.string.isRequired,
	index: PropTypes.number.isRequired,
	children: PropTypes.node.isRequired,
};

OrderableListItem.defaultProps = {};

export default OrderableListItem;
