// @ts-nocheck
import OrderableList from '.';

export default {
	title: 'Lists/Orderable List',
	component: OrderableList,
};

export { default as basic } from './stories/basic';
