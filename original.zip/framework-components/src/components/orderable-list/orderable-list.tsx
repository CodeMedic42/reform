// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import map from 'lodash-es/map';
import OrderableListItem from './orderable-list-item';

class OrderableList extends PureComponent {
	constructor(props) {
		super(props);

		this.onDragEnd = this.onDragEnd.bind(this);
	}

	onDragEnd(result) {
		const { items, onMove } = this.props;

		if (!result.destination) {
			// Dropped outside the list
			return;
		}

		// Clone the original items array
		const itemArray = Array.from(items);
		const [removed] = itemArray.splice(result.source.index, 1);
		itemArray.splice(result.destination.index, 0, removed);

		onMove(itemArray);
	}

	render() {
		const { className, items } = this.props;

		return (
			<DragDropContext onDragEnd={this.onDragEnd}>
				<Droppable droppableId="droppable">
					{(provided, snapshot) => {
						const { isDraggingOver } = snapshot;

						return (
							<div
								{...provided.droppableProps}
								ref={provided.innerRef}
								className={classnames(
									'ai-orderable-list',
									className,
									{
										'is-dragging-over': isDraggingOver,
									},
								)}
							>
								{map(items, (item, idx) => (
									<OrderableListItem
										key={item.id}
										id={item.id}
										index={idx}
										moveItem={this.moveItem}
									>
										{item.body}
									</OrderableListItem>
								))}
								{provided.placeholder}
							</div>
						);
					}}
				</Droppable>
			</DragDropContext>
		);
	}
}

OrderableList.propTypes = {
	className: PropTypes.string,
	items: PropTypes.arrayOf(
		PropTypes.shape({
			id: PropTypes.string.isRequired,
			// eslint-disable-next-line react/forbid-prop-types
			data: PropTypes.any,
			body: PropTypes.node.isRequired,
		}),
	).isRequired,
	onMove: PropTypes.func.isRequired,
};

OrderableList.defaultProps = {
	className: null,
};

export default OrderableList;
