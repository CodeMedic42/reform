// @ts-nocheck
import OverlaySpinner from '.';

export default {
	title: 'Progress/Overlay Spinner',
	component: OverlaySpinner,
};

export { default as preview } from './stories/preview';
