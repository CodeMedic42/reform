// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import { paletteColorOrder } from '../../common/color-list';
import SpinnerRing from '../spinner-ring';
import buildId from '../../common/build-id';
import BackDrop from '../backdrop';

function OverlaySpinner(props) {
	const { id, className, size, color, variant, alignment, useBackdrop } =
		props;

	const alignmentClass = !isNil(alignment)
		? `alignment-${alignment}`
		: 'alignment-50';

	return (
		<div
			id={id}
			className={classnames(
				'ai-overlay-spinner',
				alignmentClass,
				className,
			)}
		>
			{useBackdrop ? (
				<BackDrop
					className="overlay-spinner-backdrop"
					enabled
					variant="lite"
					enableAnimation
					position="absolute"
				/>
			) : null}
			<SpinnerRing
				id={buildId(id, 'spinner')}
				size={size}
				color={color}
				variant={variant}
			/>
		</div>
	);
}

OverlaySpinner.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	color: PropTypes.oneOf(paletteColorOrder),
	variant: PropTypes.oneOf(['solid', 'dotted']),
	alignment: PropTypes.oneOf(['centered', 'sm', 'md', 'lg', 'sticky']),
	useBackdrop: PropTypes.bool,
};

OverlaySpinner.defaultProps = {
	id: null,
	className: null,
	size: 'md',
	color: 'blue',
	variant: 'solid',
	alignment: 'centered',
	useBackdrop: true,
};

export default memo(OverlaySpinner);
