// @ts-nocheck
import React from 'react';
import OverlaySpinner from '..';
import { paletteColorOrder } from '../../../common/color-list';
import Scope from '../../../../.storybook/components/scope';

function preview(props) {
	return (
		<Scope fillViewport specimenViewStyle={{ height: '1000px' }}>
			<OverlaySpinner {...props} />
		</Scope>
	);
}

preview.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		size: {
			options: ['xl', 'lg', 'md', 'sm', 'xs'],
			control: { type: 'select' },
		},
		color: {
			options: paletteColorOrder,
			control: { type: 'select' },
		},
		variant: {
			options: ['solid', 'dotted'],
			control: { type: 'select' },
		},
		alignment: {
			options: ['centered', 'lg', 'md', 'sm'],
			control: { type: 'select' },
		},
	},
	args: {
		size: 'md',
		color: 'blue',
		variant: 'solid',
		alignment: 'centered',
	}
};

export default preview;
