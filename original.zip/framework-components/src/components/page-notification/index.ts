// @ts-nocheck
import PageNotification from './page-notification';

export default PageNotification;
