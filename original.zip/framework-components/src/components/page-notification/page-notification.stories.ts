// @ts-nocheck
import PageNotification from '.';

export default {
	title: 'Messaging/Page Notification',
	component: PageNotification,
};

export { default as nonBlocking } from './stories/non-blocking';
export { default as blocking } from './stories/blocking';
