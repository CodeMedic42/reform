// @ts-nocheck
import React, { PureComponent } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Backdrop from '../backdrop';
import NotificationMessage from '../notification-message';

class PageNotification extends PureComponent {
	render() {
		const {
			id,
			className,
			heading,
			message,
			color,
			actions,
			showIcon,
			blocking,
		} = this.props;

		const notification = (
			<div
				id={id}
				className={classnames('ai-page-notification', className)}
			>
				{blocking ? <Backdrop variant="lite" position="fixed" /> : null}
				<NotificationMessage
					heading={heading}
					message={message}
					color={color}
					actions={actions}
					showIcon={showIcon}
				/>
			</div>
		);

		return ReactDOM.createPortal(notification, window.document.body);
	}
}

PageNotification.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	heading: PropTypes.string,
	message: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
		PropTypes.string,
	]).isRequired,
	color: PropTypes.string,
	actions: PropTypes.arrayOf(
		PropTypes.shape({
			label: PropTypes.string.isRequired,
			onClick: PropTypes.func.isRequired,
			// eslint-disable-next-line react/forbid-prop-types
			onClickMeta: PropTypes.any,
			matchColor: PropTypes.bool,
		}),
	),
	showIcon: PropTypes.bool,
	blocking: PropTypes.bool,
};

PageNotification.defaultProps = {
	id: null,
	className: null,
	heading: null,
	actions: null,
	showIcon: false,
	color: null,
	blocking: false,
};

export default PageNotification;
