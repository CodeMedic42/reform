// @ts-nocheck
import PageSpinner from './page-spinner';

export default PageSpinner;
