// @ts-nocheck
import PageSpinner from '.';

export default {
	title: 'Progress/Page Spinner',
	component: PageSpinner,
};

export { default as example } from './stories/example';
