// @ts-nocheck
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { paletteColorOrder } from '../../common/color-list';
import SpinnerRing from '../spinner-ring';
import buildId from '../../common/build-id';
import BackDrop from '../backdrop';

function PageSpinner(props) {
	const { id, className, size, color, variant } = props;

	const pageSpinner = (
		<div
			id={id}
			className={classnames(
				'ai-page-spinner',
				'alignment-centered',
				className,
			)}
		>
			<BackDrop
				className="page-spinner-backdrop"
				enabled
				variant="dark"
				enableAnimation
				position="fixed"
			/>
			<SpinnerRing
				id={buildId(id, 'spinner')}
				size={size}
				color={color}
				variant={variant}
			/>
		</div>
	);

	return ReactDOM.createPortal(pageSpinner, window.document.body);
}

PageSpinner.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	color: PropTypes.oneOf(paletteColorOrder),
	variant: PropTypes.oneOf(['solid', 'dotted']),
};

PageSpinner.defaultProps = {
	id: null,
	className: null,
	size: 'md',
	color: 'blue',
	variant: 'solid',
};

export default PageSpinner;
