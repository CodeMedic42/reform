// @ts-nocheck
import Page from './page';
import PageHeader from './page-header';
import PageLogo from './page-logo';
import PageContainer from './page-container';
import PageContainerGroup from './page-container-group';
import PageTitle from './page-title';

export default Page;

export { PageHeader, PageLogo, PageContainer, PageContainerGroup, PageTitle };
