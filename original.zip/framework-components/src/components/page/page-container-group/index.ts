// @ts-nocheck
import PageContainerGroup from './page-container-group';

export default PageContainerGroup;
