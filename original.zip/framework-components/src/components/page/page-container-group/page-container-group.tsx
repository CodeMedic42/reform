// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

function PageContainerGroup(props) {
	const { id, className, overlay, children } = props;

	return (
		<div
			id={id}
			className={classnames(
				'ai-page-container-group',
				className,
				{
					overlay
				}
			)}
		>
			{children}
		</div>
	);
}

PageContainerGroup.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	overlay: PropTypes.bool,
};

PageContainerGroup.defaultProps = {
	id: null,
	className: null,
	children: null,
	overlay: false
};

export default memo(PageContainerGroup);
