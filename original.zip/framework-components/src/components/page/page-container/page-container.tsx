// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import OverlaySpinner from '../../overlay-spinner';

function InnerCard(props) {
	// eslint-disable-next-line react/prop-types
	const { children, asCard } = props;

	if (!asCard) {
		return children;
	}

	return (
		<div className="ai-page-card">
			<div className="page-card-left-overlay" />
			<div className="page-card-inner">{children}</div>
			<div className="page-card-right-overlay" />
		</div>
	);
}

function PageContainer(props) {
	const {
		id,
		className,
		children,
		noGutter,
		asCard,
		allowScroll,
		isLoading,
		showSpinner,
		fillPage,
		useSpinnerBackDrop,
	} = props;

	const useSpinner = isLoading || showSpinner;

	const useBackdrop = !isNil(useSpinnerBackDrop)
		? useSpinnerBackDrop
		: asCard;

	return (
		<div
			id={id}
			className={classnames('ai-page-container', className, {
				'allow-scroll': allowScroll,
				'no-gutter': noGutter,
				'as-card': asCard,
				'show-spinner': useSpinner,
				'fill-page': fillPage || isLoading,
			})}
		>
			<InnerCard asCard={asCard}>
				<div className="page-content">
					{children}
					{useSpinner ? (
						<OverlaySpinner
							useBackdrop={useBackdrop}
							alignment="sticky"
							size="lg"
						/>
					) : null}
				</div>
			</InnerCard>
		</div>
	);
}

PageContainer.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	noGutter: PropTypes.bool,
	asCard: PropTypes.bool,
	allowScroll: PropTypes.bool,
	isLoading: PropTypes.bool,
	showSpinner: PropTypes.bool,
	fillPage: PropTypes.bool,
	useSpinnerBackDrop: PropTypes.bool,
};

PageContainer.defaultProps = {
	id: null,
	className: null,
	children: null,
	noGutter: false,
	asCard: false,
	allowScroll: false,
	isLoading: false,
	showSpinner: false,
	fillPage: false,
	useSpinnerBackDrop: null,
};

export default memo(PageContainer);
