// @ts-nocheck
import React, { memo } from 'react';
import map from 'lodash-es/map';
import isNil from 'lodash-es/isNil';
import isEmpty from 'lodash-es/isEmpty';
import { faGrid } from '@audacious/icons/solid/faGrid';
import Menu, { MenuLink } from '../../menu';
import AnchorIconButton from '../../drop-down/anchor-icon-button';
import PropTypes from '../../../common/prop-types';

function AppItem(props) {
	const { applications, adminApp } = props;

	const adminAppNode = !isNil(adminApp) ? (
		<MenuLink
			key={adminApp.href}
			onClick={adminApp.onClick}
			onClickMeta={adminApp.onClickMeta}
			href={adminApp.href}
			borderTop
		>
			{adminApp.label}
		</MenuLink>
	) : null;

	if (isEmpty(applications)) {
		return null;
	}

	return (
		<Menu
			id="app-menu"
			className="app-menu"
			size="sm"
			variant="lite"
			Anchor={AnchorIconButton}
			anchorProps={{
				icon: faGrid,
				color: 'primary',
				variant: 'fill',
				size: 'md',
				'aria-label': 'Applications',
			}}
		>
			{map(applications, (app) => (
				<MenuLink
					key={app.href}
					onClick={app.onClick}
					onClickMeta={app.onClickMeta}
					href={app.href}
				>
					{app.label}
				</MenuLink>
			))}
			{adminAppNode}
		</Menu>
	);
}

AppItem.propTypes = {
	applications: PropTypes.arrayOf(PropTypes.applicationMenuItem),
	adminApp: PropTypes.applicationMenuItem,
};

AppItem.defaultProps = {
	applications: null,
	adminApp: null,
};

export default memo(AppItem);
