// @ts-nocheck
import PageHeader from './page-header';

export default PageHeader;
