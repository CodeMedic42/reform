// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { MenuItem } from '../../menu';
import UserAvatar from './user-avatar';

function MenuProfile(props) {
	const { firstName, lastName } = props;

	return (
		<MenuItem borderBottom className="menu-profile">
			<div className="avatar-container">
				<UserAvatar firstName={firstName} lastName={lastName} />
			</div>
			<span className="user-name">
				<span className="user-first-name">{firstName}</span>{' '}
				<span className="user-last-name">{lastName}</span>
			</span>
		</MenuItem>
	);
}

MenuProfile.propTypes = {
	firstName: PropTypes.string,
	lastName: PropTypes.string,
};

MenuProfile.defaultProps = {
	firstName: null,
	lastName: null,
};

export default memo(MenuProfile);
