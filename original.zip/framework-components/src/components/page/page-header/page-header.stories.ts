// @ts-nocheck
import PageHeader from '.';

export default {
	title: 'Page/Page Header',
	component: PageHeader,
};

export { default as basic } from './stories/basic';
