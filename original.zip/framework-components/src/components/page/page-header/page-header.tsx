// @ts-nocheck
import React, { Component, createRef } from 'react';
import classnames from 'classnames';
import map from 'lodash-es/map';
import debounce from 'lodash-es/debounce';
import { faBars } from '@audacious/icons/solid/faBars';
import { faGripLines } from '@audacious/icons/solid/faGripLines';
import UserMenu from './user-menu';
import AppMenu from './app-menu';
import PageLogo from '../page-logo';
import IconButton from '../../icon-button';
import Icon from '../../icon';
import applyEventHandler from '../../../common/apply-event-handler';
import PropTypes from '../../../common/prop-types';

class PageHeader extends Component {
	constructor(props) {
		super(props);

		this.headerRef = createRef();

		this.handleGripClick = this.handleGripClick.bind(this);
		this.handleToggle = this.handleToggle.bind(this);

		this.state = {
			showGrip: false,
			gripOpen: false,
		};
	}

	componentDidMount() {
		this.removeScrollListener = applyEventHandler(
			document,
			'scroll',
			(event) => {
				const headerNode = this.headerRef.current;

				const { gripOpen, showGrip } = this.state;

				if (gripOpen) {
					this.setState({
						gripOpen: false,
					});
				}

				if (!event.target.contains(headerNode)) {
					return;
				}

				const top = event.target.scrollingElement.scrollTop;

				const { height } = headerNode.getBoundingClientRect();

				const percentHidden = top < height ? (top / height) * 100 : 100;

				if (percentHidden > 70) {
					if (!showGrip) {
						this.setState({
							showGrip: true,
						});
					}
				} else if (showGrip) {
					this.setState({
						showGrip: false,
					});
				}
			},
			{
				capture: true,
				passive: true,
			},
		);

		this.removeClickListener = applyEventHandler(
			document,
			'click',
			debounce((event) => {
				const headerNode = this.headerRef.current;

				const { gripOpen } = this.state;

				if (!gripOpen) {
					return;
				}

				if (
					event.target === headerNode ||
					headerNode.contains(event.target)
				) {
					return;
				}

				this.setState({
					gripOpen: false,
				});
			}, 1),
			{
				capture: true,
				passive: true,
			},
		);
	}

	componentWillUnmount() {
		this.removeScrollListener();
		this.removeClickListener();
	}

	handleGripClick() {
		const { gripOpen } = this.state;

		this.setState({
			gripOpen: !gripOpen,
		});
	}

	handleToggle(...args) {
		const { onToggle } = this.props;

		const { gripOpen } = this.state;

		if (gripOpen) {
			this.setState({
				gripOpen: false,
			});
		}

		onToggle(...args);
	}

	renderAdditionalFeatures() {
		const { additionalFeatures } = this.props;

		return map(additionalFeatures, (feature, index) => (
			<div key={index} className="additional-feature">
				{feature}
			</div>
		));
	}

	render() {
		const {
			className,
			logo,
			userName,
			userActions,
			onToggleMeta,
			applications,
			logOutAction,
			removeNavToggle,
			adminApp,
		} = this.props;

		const { showGrip, gripOpen } = this.state;

		return (
			<header
				ref={this.headerRef}
				id="page-header-bar"
				className={classnames(
					'ai-page-header',
					'ai-scheme',
					'sch-primary',
					'sch-fill',
					className,
					{
						'show-grip': showGrip,
						'grip-open': gripOpen,
					},
				)}
			>
				<div className="header-left">
					{!removeNavToggle ? (
						<IconButton
							className="nav-toggle"
							icon={faBars}
							size="md"
							color="primary"
							shape="circle"
							variant="fill"
							onClick={this.handleToggle}
							onClickMeta={onToggleMeta}
						/>
					) : null}
					<PageLogo
						urlHref={logo.urlHref}
						imageSource={logo.imageSource}
						imageAlternate={
							logo.imageAlternate
								? logo.imageAlternate
								: 'Header Logo'
						}
					/>
				</div>
				<div className="header-right">
					{this.renderAdditionalFeatures()}
					<AppMenu applications={applications} adminApp={adminApp} />
					<UserMenu
						userName={userName}
						actions={userActions}
						logOutAction={logOutAction}
					/>
				</div>
				<button
					className="grip"
					type="button"
					onClick={this.handleGripClick}
					aria-label="grip"
				>
					<Icon icon={faGripLines} />
				</button>
			</header>
		);
	}
}

PageHeader.propTypes = {
	className: PropTypes.string,
	userName: PropTypes.shape({
		firstName: PropTypes.string,
		lastName: PropTypes.string,
	}).isRequired,
	userActions: PropTypes.arrayOf(
		PropTypes.shape({
			label: PropTypes.string,
			onClick: PropTypes.func,
			onClickMeta: PropTypes.any,
		}),
	),
	applications: PropTypes.any,
	additionalFeatures: PropTypes.arrayOf(PropTypes.node),
	logo: PropTypes.shape({
		urlHref: PropTypes.string,
		imageSource: PropTypes.string.isRequired,
		imageAlternate: PropTypes.string,
	}).isRequired,
	onToggle: PropTypes.func,
	onToggleMeta: PropTypes.any,
	logOutAction: PropTypes.shape({
		label: PropTypes.string,
		onClick: PropTypes.func,
		onClickMeta: PropTypes.any,
	}).isRequired,
	removeNavToggle: PropTypes.bool,
	adminApp: PropTypes.applicationMenuItem,
};

PageHeader.defaultProps = {
	applications: null,
	className: null,
	userActions: null,
	additionalFeatures: null,
	onToggle: null,
	onToggleMeta: null,
	removeNavToggle: false,
	adminApp: null,
};

export default PageHeader;
