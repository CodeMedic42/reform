// @ts-nocheck
import React, { memo, useMemo } from 'react';
import PropTypes from 'prop-types';
import isNil from 'lodash-es/isNil';
import capitalize from 'lodash-es/capitalize';

import { faUser } from '@audacious/icons/solid/faUser';
import Avatar from '../../avatar';
import Icon from '../../icon';

function UserAvatar(props) {
	const { firstName, lastName, asButton, 'aria-label': ariaLabel } = props;

	const avatarContent = useMemo(() => {
		if (!isNil(firstName)) {
			return capitalize(firstName[0]);
		}

		if (!isNil(lastName)) {
			return capitalize(lastName[0]);
		}

		return <Icon icon={faUser} size="md" />;
	}, [firstName, lastName]);

	return (
		<Avatar
			color={asButton ? 'navy' : 'secondary'}
			size="md"
			shade="darker"
			asButton={asButton}
			enableBorder
			aria-label={ariaLabel}
		>
			{avatarContent}
		</Avatar>
	);
}

UserAvatar.propTypes = {
	firstName: PropTypes.string,
	lastName: PropTypes.string,
	asButton: PropTypes.bool,
	'aria-label': PropTypes.string,
};

UserAvatar.defaultProps = {
	firstName: null,
	lastName: null,
	asButton: false,
	'aria-label': null,
};

export default memo(UserAvatar);
