// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import applyAnchorBinding from '../../drop-down/anchor-binding';
import UserAvatar from './user-avatar';

function UserMenuAnchor(props) {
	const { firstName, lastName, 'aria-label': ariaLabel } = props;

	return <UserAvatar asButton firstName={firstName} lastName={lastName} aria-label={ariaLabel} />;
}

UserMenuAnchor.propTypes = {
	firstName: PropTypes.string,
	lastName: PropTypes.string,
	'aria-label': PropTypes.string,
};

UserMenuAnchor.defaultProps = {
	firstName: null,
	lastName: null,
	'aria-label': null,
};

export default applyAnchorBinding(memo(UserMenuAnchor));
