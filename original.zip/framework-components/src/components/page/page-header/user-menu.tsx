// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import map from 'lodash-es/map';
import Menu, { MenuButton } from '../../menu';
import UserMenuAnchor from './user-menu-anchor';
import MenuProfile from './menu-profile';

function UserMenu(props) {
	const { userName, actions, logOutAction } = props;

	const { firstName, lastName } = userName;

	return (
		<Menu
			id="user-menu"
			className="user-menu"
			size="sm"
			variant="dark"
			Anchor={UserMenuAnchor}
			anchorProps={{
				firstName,
				lastName,
				'aria-label': 'User',
			}}
			dark
		>
			<MenuProfile firstName={firstName} lastName={lastName} />
			{map(actions, (action) => (
				<MenuButton
					key={action.id}
					id={action.id}
					onClick={action.onClick}
					onClickMeta={action.onClickMeta}
				>
					{action.label}
				</MenuButton>
			))}
			<MenuButton
				id="log-out"
				onClick={logOutAction?.onClick}
				onClickMeta={logOutAction?.onClickMeta}
				borderTop
			>
				{logOutAction?.label ?? 'Log Out'}
			</MenuButton>
		</Menu>
	);
}

UserMenu.propTypes = {
	userName: PropTypes.shape({
		firstName: PropTypes.string,
		lastName: PropTypes.string,
	}).isRequired,
	actions: PropTypes.arrayOf(
		PropTypes.shape({
			id: PropTypes.string.isRequired,
			label: PropTypes.string,
			onClick: PropTypes.func,
			// eslint-disable-next-line react/forbid-prop-types
			onClickMeta: PropTypes.any,
		}),
	),
	logOutAction: PropTypes.shape({
		label: PropTypes.string,
		onClick: PropTypes.func,
		// eslint-disable-next-line react/forbid-prop-types
		onClickMeta: PropTypes.any,
	}).isRequired,
};

UserMenu.defaultProps = {
	actions: null,
};

export default memo(UserMenu);
