// @ts-nocheck
import PageLogo from './page-logo';

export default PageLogo;
