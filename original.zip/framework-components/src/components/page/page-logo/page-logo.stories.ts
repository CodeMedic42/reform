// @ts-nocheck
import PageLogo from '.';

export default {
	title: 'Page/Page Logo',
	component: PageLogo,
};

export { default as basic } from './stories/basic';
