// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import isNil from 'lodash-es/isNil';

class PageLogo extends PureComponent {
	render() {
		const { urlHref, imageSource, imageAlternate } = this.props;

		const image = (
			<img type="image" alt={imageAlternate} src={imageSource} />
		);

		if (isNil(urlHref)) {
			return <span className="ai-page-logo">{image}</span>;
		}

		return (
			<a
				className="ai-page-logo"
				role="button"
				aria-label="Click to go to home"
				href={urlHref}
			>
				{image}
			</a>
		);
	}
}

PageLogo.propTypes = {
	urlHref: PropTypes.string,
	imageSource: PropTypes.string.isRequired,
	imageAlternate: PropTypes.string,
};

PageLogo.defaultProps = {
	urlHref: null,
	imageAlternate: null,
};

export default PageLogo;
