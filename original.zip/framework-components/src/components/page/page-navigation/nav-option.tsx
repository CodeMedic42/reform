// @ts-nocheck
import { memo, useCallback, useMemo } from 'react';
import isEmpty from 'lodash-es/isEmpty';
import clone from 'lodash-es/clone';
import PropTypes from '../../../common/prop-types';

function NavOption(props) {
	const {
		id,
		path,
		level,
		navigate,
		openPath,
		selectedPath,
		onClick,
		children,
	} = props;

	if (isEmpty(id)) {
		// eslint-disable-next-line no-console
		console.error('All nav options must have an id');

		return null;
	}

	const open = openPath?.[level] === id;
	const selected = selectedPath?.[level] === id;
	const selfPath = useMemo(
		() => (!isEmpty(path) ? [...path, id] : [id]),
		[path, id],
	);

	const handleClick = useCallback(
		(event) => {
			let openTo = null;

			if (open) {
				if (navigate) {
					// If open but it's a navigable option then don't do anything.
					return;
				}

				// If open, then close to next level
				openTo = clone(selfPath).slice(0, selfPath.length - 1);
			} else if (selected) {
				// If not open but selected, then open right to selectedPath.
				openTo = selectedPath;
			} else {
				// Otherwise just open to this target
				openTo = selfPath;
			}

			onClick(openTo, { event, navigate });
		},
		[onClick, open, selected, openPath, selfPath, navigate],
	);

	return children({ selected, open, selfPath, handleClick });
}

NavOption.propTypes = {
	id: PropTypes.string.isRequired,
	path: PropTypes.arrayOf(PropTypes.string),
	level: PropTypes.number.isRequired,
	navigate: PropTypes.bool,
	openPath: PropTypes.arrayOf(PropTypes.string),
	selectedPath: PropTypes.arrayOf(PropTypes.string),
	onClick: PropTypes.func.isRequired,
	children: PropTypes.func.isRequired,
};

NavOption.defaultProps = {
	openPath: null,
	selectedPath: null,
	navigate: false,
	path: null,
};

export default memo(NavOption);
