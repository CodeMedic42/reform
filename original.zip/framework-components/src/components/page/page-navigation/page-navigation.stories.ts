// @ts-nocheck
import PageNavigation from '.';

export default {
	title: 'Page/Page Navigation',
	component: PageNavigation,
};

export { default as basic } from './stories/basic';
