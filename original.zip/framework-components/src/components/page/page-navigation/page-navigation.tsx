// @ts-nocheck
import React, { memo, useCallback, useMemo } from 'react';
import classnames from 'classnames';
import isEmpty from 'lodash-es/isEmpty';
import isNil from 'lodash-es/isNil';
import find from 'lodash-es/find';
import { faBars } from '@audacious/icons/solid/faBars';
import { faXmarkLarge } from '@audacious/icons/solid/faXmarkLarge';
import PropTypes from '../../../common/prop-types';
import PlatformMessage from './platform-message';
import Backdrop from '../../backdrop';
import ResolutionBinding from '../../resolution-binding';
import PrimaryNavControl from './primary-nav/primary-nav-control';
import PrimaryNavMenu from './primary-nav/primary-nav-menu';

function PageNavigation(props) {
	const {
		appMenuOptions,
		sysMenuOptions,
		platformMessage,
		onNavigate,
		onClose,
		onOpen,
		selectedPath,
		openPath,
		allowSelfOpen,
	} = props;

	const handleToggle = useCallback(() => {
		if (isNil(openPath)) {
			onOpen([]);
		} else {
			onClose();
		}
	}, [openPath, onOpen, onClose]);

	const handleMenuClick = useCallback(
		(path, { event, navigate }) => {
			if (navigate) {
				event.preventDefault();

				onNavigate(path);
			}

			onOpen(path, !navigate);
		},
		[onNavigate, onClose, onOpen],
	);

	const secondaryOpen = useMemo(() => {
		const openPathRoot = openPath?.[0];

		if (isNil(openPathRoot)) {
			return false;
		}

		let openMenu = find(
			appMenuOptions,
			(menuOption) => menuOption.id === openPathRoot,
		);

		if (isNil(openMenu)) {
			openMenu = find(
				sysMenuOptions,
				(menuOption) => menuOption.id === openPathRoot,
			);
		}

		return !isEmpty(openMenu?.menuOptions);
	}, [openPath?.[0], appMenuOptions, sysMenuOptions]);

	let sysMenu = null;

	if (!isEmpty(sysMenuOptions) || !isEmpty(platformMessage)) {
		sysMenu = (
			<div className="nav-sys-menu">
				<PrimaryNavMenu
					menuOptions={sysMenuOptions}
					onClick={handleMenuClick}
					onNavigate={onNavigate}
					openPath={openPath}
					selectedPath={selectedPath}
					platformMessage={platformMessage}
				/>
				<PlatformMessage platformMessage={platformMessage} />
			</div>
		);
	}

	if (isNil(sysMenu) && isEmpty(appMenuOptions)) {
		return null;
	}

	return (
		<>
			<ResolutionBinding
				enabled={!isNil(openPath)}
				breakPoints={[true, null, false]}
			>
				{({ mount }) => (
					<Backdrop
						className="ai-page-nav-backdrop"
						enabled={!isNil(openPath) && mount}
						onClick={onClose}
						variant="dark"
						position="fixed"
						enableAnimation
					/>
				)}
			</ResolutionBinding>
			<div
				className={classnames('ai-page-nav', {
					'primary-open': !isNil(openPath),
					'secondary-open': secondaryOpen,
					'self-open': allowSelfOpen,
				})}
			>
				<div className="nav-primary">
					<PrimaryNavControl
						Tag="button"
						type="button"
						id="close"
						className="close-nav-btn"
						// label="Audacious Inquiry"
						onClick={handleToggle}
						icon={isNil(openPath) ? faBars : faXmarkLarge}
						open={!isNil(openPath)}
					/>
					<PrimaryNavMenu
						className="nav-app-menu"
						menuOptions={appMenuOptions}
						onClick={handleMenuClick}
						onNavigate={onNavigate}
						openPath={openPath}
						selectedPath={selectedPath}
						platformMessage={platformMessage}
					/>
					<div className="nav-flex-buffer" />
					{sysMenu}
				</div>
			</div>
		</>
	);
}

PageNavigation.propTypes = {
	appMenuOptions: PropTypes.pageNavMenuOptions,
	sysMenuOptions: PropTypes.pageNavMenuOptions,
	platformMessage: PropTypes.node,
	selectedPath: PropTypes.arrayOf(PropTypes.string),
	openPath: PropTypes.arrayOf(PropTypes.string),
	onNavigate: PropTypes.func,
	onClose: PropTypes.func,
	onOpen: PropTypes.func,
	allowSelfOpen: PropTypes.bool,
};

PageNavigation.defaultProps = {
	appMenuOptions: null,
	sysMenuOptions: null,
	platformMessage: null,
	selectedPath: null,
	openPath: null,
	onNavigate: null,
	onClose: null,
	onOpen: null,
	allowSelfOpen: null,
};

export default memo(PageNavigation);
