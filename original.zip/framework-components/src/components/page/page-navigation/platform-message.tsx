// @ts-nocheck
import React, { memo } from 'react';
import isEmpty from 'lodash-es/isEmpty';
import PropTypes from '../../../common/prop-types';

function PlatformMessage(props) {
	const { platformMessage } = props;

	if (isEmpty(platformMessage)) {
		return null;
	}

	return <div className="platform-message">{platformMessage}</div>;
}

PlatformMessage.propTypes = {
	platformMessage: PropTypes.node,
};

PlatformMessage.defaultProps = {
	platformMessage: null,
};

export default memo(PlatformMessage);
