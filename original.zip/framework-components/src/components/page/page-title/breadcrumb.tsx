// @ts-nocheck
import React, { memo, useCallback } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isEmpty from 'lodash-es/isEmpty';
import isNil from 'lodash-es/isNil';
import buildId from '../../../common/build-id';
import Link from '../../link';

function Breadcrumb(props) {
	const { id, className, label, href, route, onClick, onNavigate } = props;

	const handleClick = useCallback(
		({ event }) => {
			if (!isEmpty(route) && !isNil(onNavigate)) {
				onNavigate(route);

				event.preventDefault();
			}
			if (isEmpty(href) && isEmpty(route)) {
				event.preventDefault();
			}

			if (!isNil(onClick)) {
				return onClick({ event });
			}

			return null;
		},
		[route, onClick, onNavigate, href],
	);

	let finalHref = '';

	if (!isEmpty(href)) {
		finalHref = href;
	} else if (!isEmpty(route)) {
		finalHref = route;
	}

	return (
		<Link
			id={buildId(id, 'breadcrumb')}
			className={classnames('ai-breadcrumb', className)}
			onClick={handleClick}
			href={finalHref}
		>
			{label}
		</Link>
	);
}

Breadcrumb.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	label: PropTypes.string.isRequired,
	route: PropTypes.string,
	href: PropTypes.string,
	onClick: PropTypes.func,
	onNavigate: PropTypes.func,
};

Breadcrumb.defaultProps = {
	id: null,
	className: null,
	route: null,
	href: null,
	onClick: null,
	onNavigate: null,
};

export default memo(Breadcrumb);
