// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isEmpty from 'lodash-es/isEmpty';
import reduce from 'lodash-es/reduce';
import Breadcrumb from './breadcrumb';
import { Column } from '../../grid';
import buildId from '../../../common/build-id';

function Breadcrumbs(props) {
	const { id, className, breadcrumbs, onNavigate } = props;

	if (isEmpty(breadcrumbs)) {
		return null;
	}

	return (
		<Column
			id={buildId(id, 'breadcrumbs')}
			className={classnames('ai-breadcrumbs', className)}
		>
			{reduce(
				breadcrumbs,
				(acc, breadcrumb, index) => {
					acc.push(
						<Breadcrumb
							{...breadcrumb}
							key={index}
							onNavigate={onNavigate}
						/>,
					);

					if (index < breadcrumbs.length - 1) {
						acc.push(' / ');
					}

					return acc;
				},
				[],
			)}
		</Column>
	);
}

Breadcrumbs.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	breadcrumbs: PropTypes.arrayOf(
		PropTypes.shape({
			id: PropTypes.string,
			className: PropTypes.string,
			label: PropTypes.string.isRequired,
			route: PropTypes.string,
			href: PropTypes.string,
			onClick: PropTypes.func,
		}),
	),
	onNavigate: PropTypes.func,
};

Breadcrumbs.defaultProps = {
	id: null,
	className: null,
	breadcrumbs: null,
	onNavigate: null,
};

export default memo(Breadcrumbs);
