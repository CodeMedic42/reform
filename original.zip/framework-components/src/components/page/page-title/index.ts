// @ts-nocheck
import PageTitle from './page-title';

export default PageTitle;
