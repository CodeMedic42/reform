// @ts-nocheck
import React, { memo } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isEmpty from 'lodash-es/isEmpty';
import isNil from 'lodash-es/isNil';
import { faArrowLeft } from '@audacious/icons/regular/faArrowLeft';
import PageContainer from '../page-container';
import SubHeading from '../../typography/sub-heading';
import TabBar from '../../tab-bar';
import { Row, Column } from '../../grid';
import Breadcrumbs from './breadcrumbs';
import IconButton from '../../icon-button';
import Icon from '../../icon';

function PageTitle(props) {
	const {
		id,
		className,
		pageName,
		tabs,
		selectedTab,
		onTabSelect,
		customFeature,
		breadcrumbs,
		onNavigate,
		onBack,
		showSpinner,
	} = props;

	return (
		<PageContainer
			id={id}
			className={classnames('ai-page-title', className)}
			noGutter
			showSpinner={showSpinner}
			useSpinnerBackDrop
		>
			<Row gutter="8" className="page-name-row">
				<Column width={[null, 'fill']}>
					<Row gutter="8">
						<Breadcrumbs
							id={id}
							breadcrumbs={breadcrumbs}
							onNavigate={onNavigate}
						/>
						{!isNil(onBack) ? (
							<Column width="content">
								<IconButton
									className="back-btn"
									size="sm"
									onClick={onBack}
								>
									<Icon icon={faArrowLeft} color="primary" />
								</IconButton>
							</Column>
						) : null}
						{!isEmpty(pageName) ? (
							<Column width="fill">
								<SubHeading
									className="page-name"
									color="navy"
									level="2"
									responsive
								>
									{pageName}
								</SubHeading>
							</Column>
						) : null}
					</Row>
				</Column>
				{!isNil(customFeature) ? (
					<Column width={[null, 'content']} justify={[null, 'right']}>
						{customFeature}
					</Column>
				) : null}
			</Row>
			<TabBar
				selectedTab={selectedTab}
				tabs={tabs}
				size="lg"
				onSelect={onTabSelect}
			/>
		</PageContainer>
	);
}

PageTitle.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	pageName: PropTypes.string,
	selectedTab: PropTypes.string,
	onTabSelect: PropTypes.func,
	tabs: PropTypes.arrayOf(
		PropTypes.shape({
			id: PropTypes.string,
			heading: PropTypes.node,
			disabled: PropTypes.bool,
		}),
	),
	customFeature: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	breadcrumbs: PropTypes.arrayOf(
		PropTypes.shape({
			id: PropTypes.string,
			className: PropTypes.string,
			label: PropTypes.string.isRequired,
			route: PropTypes.string,
			href: PropTypes.string,
			onClick: PropTypes.func,
		}),
	),
	onNavigate: PropTypes.func,
	onBack: PropTypes.func,
	showSpinner: PropTypes.bool,
};

PageTitle.defaultProps = {
	id: null,
	className: null,
	pageName: null,
	tabs: null,
	selectedTab: null,
	onTabSelect: null,
	customFeature: null,
	breadcrumbs: null,
	onNavigate: null,
	onBack: null,
	showSpinner: false,
};

export default memo(PageTitle);
