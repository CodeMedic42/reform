// @ts-nocheck
import Page from '.';

export default {
	title: 'Page/Page',
	component: Page,
};

export { default as basic } from './stories/basic';
export { default as loading } from './stories/loading';
export { default as withoutHeader } from './stories/without-header';
