// @ts-nocheck
import React, { memo, useCallback, useEffect, useState, useRef } from 'react';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import isEmpty from 'lodash-es/isEmpty';
import PageHeader from './page-header';
import PageNavigation from './page-navigation';
import PropTypes from '../../common/prop-types';

function initScrollbarListener() {
	const currentViewportWidth = null;
	const currentViewportHeight = null;

	function scrollbarHandler() {
		const documentClientWidth = document.documentElement.clientWidth;
		const documentClientHeight = document.documentElement.clientHeight;

		if (currentViewportWidth !== documentClientWidth) {
			document.documentElement.style.setProperty(
				'--doc-client-width',
				`${documentClientWidth}px`,
			);
		}

		if (currentViewportHeight !== documentClientHeight) {
			document.documentElement.style.setProperty(
				'--doc-client-height',
				`${documentClientHeight}px`,
			);
		}
	}

	scrollbarHandler();

	window.addEventListener('resize', scrollbarHandler);

	return scrollbarHandler;
}

const force = initScrollbarListener();

function Page(props) {
	const {
		id,
		className,
		userActions,
		userName,
		applications,
		headerLogo,
		additionalFeatures,
		children,
		hideHeader,
		sticky,
		appMenuOptions,
		sysMenuOptions,
		selectedPath,
		platformMessage,
		logOutAction,
		onNavigate,
		adminApp,
		defaultNavOpen,
	} = props;

	const [openPath, setOpenPath] = useState(defaultNavOpen ? [] : null);
	const [openLock, setOpenLock] = useState(defaultNavOpen);

	const handleNavigate = useCallback(
		(...args) => {
			if (!openLock) {
				setOpenPath(null);
			}

			onNavigate(...args);
		},
		[openLock, onNavigate],
	);

	const handleNavClose = useCallback(() => {
		setOpenPath(null);
		setOpenLock(false);
	}, []);

	const handleNavOpen = useCallback(
		(path, forceOpen) => {
			if (openLock || forceOpen) {
				setOpenPath(path);
			}
		},
		[openLock],
	);

	const pageRef = useRef();

	useEffect(() => {
		force();

		const resizeObserver = new ResizeObserver(force);

		resizeObserver.observe(pageRef.current);

		return () => {
			if (!isNil(pageRef.current)) {
				resizeObserver.unobserve(pageRef.current);
			}
		};
	}, []);

	const handleNavToggle = useCallback(() => {
		setOpenLock(!openLock);
		setOpenPath(isNil(openPath) ? [] : null);
	}, [openPath, openLock]);

	return (
		<div
			ref={pageRef}
			id={id}
			className={classnames('ai-page', className, {
				sticky,
			})}
		>
			{!hideHeader ? (
				<PageHeader
					userActions={userActions}
					logo={headerLogo}
					applications={applications}
					adminApp={adminApp}
					userName={userName}
					additionalFeatures={additionalFeatures}
					onToggle={handleNavToggle}
					logOutAction={logOutAction}
					removeNavToggle={
						isEmpty(appMenuOptions) &&
						isEmpty(sysMenuOptions) &&
						isNil(platformMessage)
					}
				/>
			) : null}
			<PageNavigation
				appMenuOptions={appMenuOptions}
				sysMenuOptions={sysMenuOptions}
				platformMessage={platformMessage}
				onNavigate={handleNavigate}
				onClose={handleNavClose}
				onOpen={handleNavOpen}
				selectedPath={selectedPath}
				openPath={openPath}
				allowSelfOpen={hideHeader}
			/>
			<div className="ai-page-viewport">{children}</div>
		</div>
	);
}

Page.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	userName: PropTypes.shape({
		firstName: PropTypes.string,
		lastName: PropTypes.string,
	}).isRequired,
	userActions: PropTypes.arrayOf(
		PropTypes.shape({
			label: PropTypes.string,
			onClick: PropTypes.func,
			onClickMeta: PropTypes.any,
		}),
	),
	applications: PropTypes.arrayOf(
		PropTypes.shape({
			label: PropTypes.string,
			url: PropTypes.string,
			onClick: PropTypes.func,
			onClickMeta: PropTypes.any,
		}),
	),
	additionalFeatures: PropTypes.arrayOf(PropTypes.node),
	headerLogo: PropTypes.shape({
		urlHref: PropTypes.string,
		imageSource: PropTypes.string.isRequired,
		imageAlternate: PropTypes.string,
	}),
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	hideHeader: PropTypes.bool,
	sticky: PropTypes.bool,
	appMenuOptions: PropTypes.pageNavMenuOptions,
	sysMenuOptions: PropTypes.pageNavMenuOptions,
	selectedPath: PropTypes.arrayOf(PropTypes.string),
	platformMessage: PropTypes.node,
	logOutAction: PropTypes.shape({
		label: PropTypes.string,
		onClick: PropTypes.func,
		onClickMeta: PropTypes.any,
	}).isRequired,
	onNavigate: PropTypes.func,
	adminApp: PropTypes.applicationMenuItem,
	defaultNavOpen: PropTypes.bool,
};

Page.defaultProps = {
	id: null,
	className: null,
	userActions: null,
	applications: null,
	additionalFeatures: null,
	children: null,
	hideHeader: false,
	headerLogo: null,
	sticky: false,
	appMenuOptions: null,
	sysMenuOptions: null,
	selectedPath: null,
	platformMessage: null,
	onNavigate: null,
	adminApp: null,
	defaultNavOpen: false,
};

export default memo(Page);
