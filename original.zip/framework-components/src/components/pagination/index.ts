// @ts-nocheck
import RecordsPerPageSelector from './records-per-page-selector';
import PageNavigation from './page-navigation';

export { PageNavigation, RecordsPerPageSelector };
