// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import clamp from 'lodash-es/clamp';
import concat from 'lodash-es/concat';
import isNil from 'lodash-es/isNil';
import times from 'lodash-es/times';
import map from 'lodash-es/map';
import toFinite from 'lodash-es/toFinite';
import { faAngleRight } from '@audacious/icons/solid/faAngleRight';
import { faAngleLeft } from '@audacious/icons/solid/faAngleLeft';
import { faAnglesLeft } from '@audacious/icons/solid/faAnglesLeft';
import { faAnglesRight } from '@audacious/icons/solid/faAnglesRight';
import IconButton from '../icon-button';
import Button from '../button';
import Tooltip from '../tooltip';

class PageNavigation extends PureComponent {
	constructor(props) {
		super(props);

		this.handleFirstPageClick = this.handleFirstPageClick.bind(this);
		this.handleLastPageClick = this.handleLastPageClick.bind(this);
		this.handlePreviousPageClick = this.handlePreviousPageClick.bind(this);
		this.handleNextPageClick = this.handleNextPageClick.bind(this);
		this.handleGotoPage = this.handleGotoPage.bind(this);
		this.handleCurrentPageChange = this.handleCurrentPageChange.bind(this);
		this.handlePreviousJumpPageClick =
			this.handlePreviousJumpPageClick.bind(this);
		this.handleNextJumpPageClick = this.handleNextJumpPageClick.bind(this);

		this.state = {};
	}

	static getDerivedStateFromProps(nextProps) {
		const { numRecords, recordsPerPage } = nextProps;

		return {
			lastPage: Math.ceil(numRecords / recordsPerPage),
		};
	}

	handleGotoPage(pageNumber) {
		const { onGotoPage } = this.props;
		const { lastPage } = this.state;

		if (isNil(onGotoPage)) {
			return;
		}

		onGotoPage(clamp(pageNumber, 1, lastPage));
	}

	handleFirstPageClick() {
		this.handleGotoPage(0);
	}

	handleLastPageClick() {
		const { lastPage } = this.state;

		this.handleGotoPage(lastPage);
	}

	handlePreviousPageClick() {
		const { currentPage } = this.props;

		this.handleGotoPage(currentPage - 1);
	}

	handleNextPageClick() {
		const { currentPage } = this.props;

		this.handleGotoPage(currentPage + 1);
	}

	handleCurrentPageChange(event) {
		this.handleGotoPage(toFinite(event.target.value));
	}

	handlePreviousJumpPageClick() {
		const { currentPage, numJumpPages } = this.props;

		const newPage = currentPage - numJumpPages * 2;

		this.handleGotoPage(newPage);
	}

	handleNextJumpPageClick() {
		const { currentPage, numJumpPages } = this.props;

		const { lastPage } = this.state;

		let newPage = currentPage + numJumpPages * 2;

		if (newPage > lastPage) {
			newPage = lastPage;
		}

		this.handleGotoPage(newPage);
	}

	renderPageList() {
		const { currentPage, numJumpPages, disabled, size } = this.props;
		const { lastPage } = this.state;
		const leftPageNums = [];
		const rightPageNums = [];

		let pageButtons = [];

		if (lastPage <= numJumpPages) {
			// Show "jump to page" buttons for each page if there is enough space
			pageButtons = times(lastPage, (idx) => idx + 1);
		} else {
			let pagesLeftToAdd = numJumpPages - 1;
			let addedCurPage = false;
			let addToLeft = true;
			let curLeftPage = 1;
			let curRightPage = lastPage;

			// Iterate over each "jump to page" button slot, adding page buttons
			// on the left of the current page, then the right, then the left and so on
			// until all the page slots are filled.
			while (pagesLeftToAdd > 0) {
				if (addToLeft) {
					leftPageNums.push(curLeftPage);
					if (currentPage === curLeftPage) {
						addedCurPage = true;
						pagesLeftToAdd += 1;
					}

					curLeftPage += 1;
					addToLeft = false;
				} else {
					rightPageNums.unshift(curRightPage);
					if (currentPage === curRightPage) {
						addedCurPage = true;
						pagesLeftToAdd += 1;
					}

					curRightPage -= 1;
					addToLeft = true;
				}

				pagesLeftToAdd -= 1;

				if (
					leftPageNums.length + rightPageNums.length + 1 >=
					lastPage
				) {
					pagesLeftToAdd = 0;
				}
			}

			// Add the left ellipsis if there are skipped pages between the left
			// pages and the current page
			if (
				leftPageNums.length > 0 &&
				currentPage > leftPageNums[leftPageNums.length - 1] + 1
			) {
				leftPageNums[leftPageNums.length - 1] = '...';
			}

			// Add the right ellipsis if there are skipped pages between the current
			// page and left pages
			if (
				rightPageNums.length > 0 &&
				currentPage < rightPageNums[0] - 1
			) {
				rightPageNums[0] = '...';
			}

			pageButtons = concat(
				leftPageNums,
				addedCurPage ? [] : currentPage,
				rightPageNums,
			);
		}

		return map(pageButtons, (pageButton, idx) => {
			if (pageButton === '...') {
				return (
					<span key={idx} className="page-button">
						...
					</span>
				);
			}

			return (
				<Button
					key={idx}
					className={classnames('page-button', {
						'current-page': pageButton === currentPage,
					})}
					color={pageButton === currentPage ? 'primary' : 'secondary'}
					variant="opaque"
					size={size}
					disabled={disabled}
					// eslint-disable-next-line react/jsx-no-bind
					onClick={this.handleGotoPage.bind(this, pageButton)}
				>
					{pageButton}
				</Button>
			);
		});
	}

	render() {
		const {
			id,
			className,
			currentPage,
			firstAndLastNav,
			jumpToPageNav,
			disabled,
			size,
			disableTooltips,
		} = this.props;

		let { firstNav, lastNav } = this.props;

		const { lastPage } = this.state;

		if (firstAndLastNav === true) {
			firstNav = true;
			lastNav = true;
		}

		const sizeClass = !isNil(size) ? `size-${size}` : 'size-md';

		let firstButton = null;

		if (firstNav) {
			if (disableTooltips) {
				firstButton = (
					<IconButton
						className="first-page-nav"
						icon={faAnglesLeft}
						size={size}
						disabled={disabled || currentPage <= 1}
						onClick={this.handleFirstPageClick}
						aria-label="First Page"
					/>
				);
			} else {
				firstButton = (
					<Tooltip
						anchor={IconButton}
						disabled={disabled || currentPage <= 1}
						anchorProps={{
							className: 'first-page-nav',
							icon: faAnglesLeft,
							size,
							disabled: disabled || currentPage <= 1,
							onClick: this.handleFirstPageClick,
							'aria-label': 'First Page',
						}}
					>
						First
					</Tooltip>
				);
			}
		}

		let previousButton = (
			<Tooltip
				anchor={IconButton}
				disabled={disabled || currentPage <= 1}
				anchorProps={{
					className: 'prev-page-nav',
					icon: faAngleLeft,
					size,
					disabled: disabled || currentPage <= 1,
					onClick: this.handlePreviousPageClick,
					'aria-label': 'Previous Page',
				}}
			>
				Previous
			</Tooltip>
		);

		let nextButton = (
			<Tooltip
				anchor={IconButton}
				disabled={disabled || currentPage >= lastPage}
				anchorProps={{
					className: 'next-page-nav',
					icon: faAngleRight,
					size,
					disabled: disabled || currentPage >= lastPage,
					onClick: this.handleNextPageClick,
					'aria-label': 'Next Page',
				}}
			>
				Next
			</Tooltip>
		);

		if (disableTooltips) {
			previousButton = (
				<IconButton
					className="prev-page-nav"
					icon={faAngleLeft}
					size={size}
					disabled={disabled || currentPage <= 1}
					onClick={this.handlePreviousPageClick}
					aria-label="Previous Page"
				/>
			);

			nextButton = (
				<IconButton
					className="next-page-nav"
					icon={faAngleRight}
					size={size}
					disabled={disabled || currentPage >= lastPage}
					onClick={this.handleNextPageClick}
					aria-label="Next Page"
				/>
			);
		}

		let lastButton = null;

		if (lastNav) {
			if (disableTooltips) {
				lastButton = (
					<IconButton
						className="last-page-nav"
						icon={faAnglesRight}
						size={size}
						disabled={disabled || currentPage >= lastPage}
						onClick={this.handleLastPageClick}
						aria-label="Last Page"
					/>
				);
			} else {
				lastButton = (
					<Tooltip
						anchor={IconButton}
						disabled={disabled || currentPage >= lastPage}
						anchorProps={{
							className: 'last-page-nav',
							icon: faAnglesRight,
							size,
							disabled: disabled || currentPage >= lastPage,
							onClick: this.handleLastPageClick,
							'aria-label': 'Last Page',
						}}
					>
						Last
					</Tooltip>
				);
			}
		}

		return (
			<div
				id={id}
				className={classnames(
					'ai-page-navigation',
					className,
					sizeClass,
				)}
			>
				<span className="page-nav-group-left">
					{firstButton}
					{previousButton}
				</span>
				{jumpToPageNav ? (
					<span className="jump-to-page-buttons">
						{this.renderPageList()}
					</span>
				) : null}
				<span className="page-nav-group-right">
					{nextButton}
					{lastButton}
				</span>
			</div>
		);
	}
}

PageNavigation.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	currentPage: PropTypes.number.isRequired,
	numRecords: PropTypes.number,
	recordsPerPage: PropTypes.number.isRequired,
	firstAndLastNav: PropTypes.bool,
	jumpToPageNav: PropTypes.bool,
	disabled: PropTypes.bool,
	numJumpPages: PropTypes.number,
	onGotoPage: PropTypes.func.isRequired,
	size: PropTypes.string,
	firstNav: PropTypes.bool,
	lastNav: PropTypes.bool,
	disableTooltips: PropTypes.bool,
};

PageNavigation.defaultProps = {
	id: null,
	className: null,
	numRecords: 0,
	firstAndLastNav: false,
	jumpToPageNav: false,
	disabled: false,
	numJumpPages: 5,
	size: 'sm',
	firstNav: false,
	lastNav: false,
	disableTooltips: false,
};

export default PageNavigation;
