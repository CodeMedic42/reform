// @ts-nocheck
import { PageNavigation } from '.';

export default {
	title: 'Lists/Pagination',
	component: PageNavigation,
};

export { default as pageNavigation } from './stories/page-navigation';
export { default as recordsPerPageSelector } from './stories/records-per-page-selector';
