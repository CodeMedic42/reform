// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import clamp from 'lodash-es/clamp';
import filter from 'lodash-es/filter';
import isNil from 'lodash-es/isNil';
import { faCircleExclamation } from '@audacious/icons/solid/faCircleExclamation';
import TooltipTextAnchor from '../tooltip/tooltip-text-anchor';
import Tooltip from '../tooltip';
import ActionSelector from '../action-selector';
import SpinnerRing from '../spinner-ring';
import Icon from '../icon';
import Badge from '../badge';

class RecordsPerPageSelector extends PureComponent {
	constructor(props) {
		super(props);

		this.getRecordRange = this.getRecordRange.bind(this);
		this.getSelectedText = this.getSelectedText.bind(this);
		this.handleRecordsPerPageChange =
			this.handleRecordsPerPageChange.bind(this);

		this.state = {};
	}

	handleRecordsPerPageChange(newRecordsPerPage) {
		const { recordsPerPage, onChangeRecordsPerPage } = this.props;

		if (newRecordsPerPage === recordsPerPage) {
			return;
		}

		// Set the new page to the page that has the first record on the current page
		const recordRange = this.getRecordRange();
		const newPage = Math.floor(
			(recordRange.first - 1) / newRecordsPerPage + 1,
		);

		onChangeRecordsPerPage(newRecordsPerPage, newPage);
	}

	getRecordRange() {
		const { numRecords, currentPage, recordsPerPage } = this.props;

		return {
			first: clamp((currentPage - 1) * recordsPerPage + 1, 1, numRecords),
			last: clamp(currentPage * recordsPerPage, 1, numRecords),
		};
	}

	getSelectedText() {
		const recordRange = this.getRecordRange();

		const selectedText = `${recordRange.first.toLocaleString('en', {
			useGrouping: true,
		})} - ${recordRange.last.toLocaleString('en', {
			useGrouping: true,
		})}`;

		return selectedText;
	}

	renderNumberOfRecords() {
		const { numRecords, status } = this.props;

		const numRecordsWithCommas = !isNil(numRecords)
			? numRecords.toLocaleString('en', {
					useGrouping: true,
			  })
			: '- -';

		if (status === 'loading') {
			return (
				<Badge
					position="bottom-right"
					value={<SpinnerRing color="red" size="xs" />}
					color="danger"
				>
					{numRecordsWithCommas}
				</Badge>
			);
		}

		if (status === 'error') {
			return (
				<Badge
					position="bottom-right"
					value={
						<Icon
							icon={faCircleExclamation}
							size="md"
							color="danger"
						/>
					}
					color="danger"
				>
					{numRecordsWithCommas}
				</Badge>
			);
		}

		return numRecordsWithCommas;
	}

	render() {
		const {
			id,
			className,
			size,
			numRecords,
			recordsPerPage,
			recordsPerPageOptions,
			disabled,
			tooltipText,
			currentPage,
			disableTooltips,
		} = this.props;

		let options = recordsPerPageOptions;
		if (
			numRecords !== null &&
			recordsPerPageOptions[recordsPerPageOptions.length - 1] > numRecords
		) {
			options = filter(recordsPerPageOptions, (opt) => opt <= numRecords);

			if (options[options.length - 1] !== numRecords) {
				options.push(numRecords);
			}
		}

		const selectorRender = disableTooltips ? (
			<ActionSelector
				id={!isNil(id) ? `${id}-records-selector` : null}
				className="records-selector"
				value={recordsPerPage}
				options={options}
				minDrawerWidth={null}
				size={size}
				disabled={disabled}
				dockRight
				listItemBorder
				onChange={this.handleRecordsPerPageChange}
				selectedTextPath={this.getSelectedText}
				// Prop below is not used by the action selector directly.
				// It is used via the getSelectedText method
				// But since that reference never change and since Action Selector is set
				// as a Pure Component, what ends up happening is that the Action Selector
				// does not see the change to currentPage and never re-renders.
				// Putting this here has the benefit of have the Pure Component see a change
				// without completely killing the shadow DOM state tree.
				currentPage={currentPage}
				numRecords={numRecords}
			/>
		) : (
			<Tooltip
				anchor={ActionSelector}
				anchorProps={{
					id: !isNil(id) ? `${id}-records-selector` : null,
					className: 'records-selector',
					value: recordsPerPage,
					options,
					minDrawerWidth: null,
					size,
					disabled,
					dockRight: true,
					listItemBorder: true,
					onChange: this.handleRecordsPerPageChange,
					selectedTextPath: this.getSelectedText,
					currentPage,
					numRecords,
				}}
			>
				Records Per Page
			</Tooltip>
		);

		return (
			<div
				id={id}
				className={classnames(
					'ai-records-per-page-selector',
					`size-${size}`,
					className,
					{
						disabled,
					},
				)}
			>
				{selectorRender}
				<div className="num-records">
					{tooltipText ? (
						<>
							of
							<Tooltip
								anchor={TooltipTextAnchor}
								anchorProps={{
									className: 'record-count',
									children: this.renderNumberOfRecords(),
								}}
							>
								{tooltipText}
							</Tooltip>
						</>
					) : (
						<>
							of
							<span className="record-count">
								{this.renderNumberOfRecords()}
							</span>
						</>
					)}
				</div>
			</div>
		);
	}
}

RecordsPerPageSelector.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['2xs', 'xs']),
	currentPage: PropTypes.number.isRequired,
	numRecords: PropTypes.number,
	recordsPerPage: PropTypes.number.isRequired,
	recordsPerPageOptions: PropTypes.arrayOf(PropTypes.number),
	tooltipText: PropTypes.string,
	disabled: PropTypes.bool,
	onChangeRecordsPerPage: PropTypes.func.isRequired,
	status: PropTypes.oneOf(['loading', 'error']),
	disableTooltips: PropTypes.bool,
};

RecordsPerPageSelector.defaultProps = {
	id: null,
	className: null,
	size: 'xs',
	recordsPerPageOptions: [20, 50, 100, 200],
	numRecords: 0,
	disabled: false,
	tooltipText: null,
	status: null,
	disableTooltips: false,
};

export default RecordsPerPageSelector;
