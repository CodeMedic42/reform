// @ts-nocheck
import React from 'react';
import slice from 'lodash-es/slice';
import map from 'lodash-es/map';
import { PageNavigation } from '..';
import Scope from '../../../../.storybook/components/scope';

const items = [];

for (let counter = 0; counter < 462; counter += 1) {
	items[counter] = `Item: ${counter + 1}`;
}

function renderPageNavigation(
	firstNav,
	lastNav,
	jumpToPageNav,
	numJumpPages,
	disabled,
	size,
) {
	return function renderPageNavigationStory(scopeState, setScopeState) {
		const { recordsPerPage, currentPage } = scopeState;

		const handleGotoPage = (newPage) => {
			setScopeState({
				currentPage: newPage,
			});
		};

		const targetItems = slice(
			items,
			(currentPage - 1) * recordsPerPage,
			currentPage * recordsPerPage,
		);

		return (
			<>
				<div style={{ width: 'fit-content', margin: 'auto' }}>
					<PageNavigation
						numRecords={items.length}
						currentPage={currentPage}
						recordsPerPage={recordsPerPage}
						numJumpPages={numJumpPages}
						onGotoPage={handleGotoPage}
						firstNav={firstNav}
						lastNav={lastNav}
						jumpToPageNav={jumpToPageNav}
						disabled={disabled}
						size={size}
					/>
				</div>
				<div
					style={{
						marginTop: '10px',
						height: '200px',
						overflow: 'auto',
					}}
				>
					{map(targetItems, (item) => (
						<div key={item}>{item}</div>
					))}
				</div>
			</>
		);
	};
}

function example() {
	return (
		<>
			<Scope
				title="All Nav Buttons"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderPageNavigation(true, true, true, 8)}
			</Scope>
			<Scope
				title="All Nav Buttons, size md"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderPageNavigation(true, true, true, 8, false, 'md')}
			</Scope>
			<Scope
				title="Only Next, Prev, First and Last Nav Buttons"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderPageNavigation(true, true, false)}
			</Scope>
			<Scope
				title="Only Next, Prev, and First Nav Buttons"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderPageNavigation(true)}
			</Scope>
			<Scope
				title="Only Next and Prev Nav Buttons"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderPageNavigation()}
			</Scope>
			<Scope
				title="Only Current Page Jump Button"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderPageNavigation(true, true, true, 1)}
			</Scope>
			<Scope
				title="Disabled"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderPageNavigation(true, true, true, 8, true)}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Page Navigation',
};

export default example;
