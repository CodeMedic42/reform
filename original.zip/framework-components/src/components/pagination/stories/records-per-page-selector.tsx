// @ts-nocheck
import React from 'react';
import slice from 'lodash-es/slice';
import isNil from 'lodash-es/isNil';
import map from 'lodash-es/map';
import { RecordsPerPageSelector, PageNavigation } from '..';
import Scope from '../../../../.storybook/components/scope';

const allItems = [];

for (let counter = 0; counter < 4623; counter += 1) {
	allItems[counter] = `Item: ${counter + 1}`;
}

function renderSelector({
	size = 'xs',
	showPageNav = false,
	disabled = false,
	tooltipText = null,
	status = null,
	items = allItems,
}) {
	return function Selector(scopeState, setScopeState) {
		const { recordsPerPage, currentPage } = scopeState;

		const handleChangeRecordsPerPage = (newRecordsPerPage, newPage) => {
			setScopeState({
				recordsPerPage: newRecordsPerPage,
				currentPage: newPage,
			});
		};

		const handleGotoPage = (newPage) => {
			setScopeState({
				currentPage: newPage,
			});
		};

		const targetItems = slice(
			items,
			(currentPage - 1) * recordsPerPage,
			currentPage * recordsPerPage,
		);

		return (
			<>
				<div
					style={{
						display: 'flex',
						alignItems: 'center',
						width: 'fit-content',
						margin: 'auto',
					}}
				>
					<RecordsPerPageSelector
						size={size}
						numRecords={!isNil(items) ? items.length : null}
						currentPage={currentPage}
						recordsPerPage={recordsPerPage}
						tooltipText={tooltipText}
						disabled={disabled}
						onChangeRecordsPerPage={handleChangeRecordsPerPage}
						status={status}
					/>
					{showPageNav ? (
						<PageNavigation
							numRecords={!isNil(items) ? items.length : null}
							currentPage={currentPage}
							recordsPerPage={recordsPerPage}
							numJumpPages={5}
							onGotoPage={handleGotoPage}
							firstAndLastNav
							jumpToPageNav
						/>
					) : null}
				</div>
				<div
					style={{
						marginTop: '10px',
						height: '200px',
						overflow: 'auto',
					}}
				>
					{map(targetItems, (item) => (
						<div key={item}>{item}</div>
					))}
				</div>
			</>
		);
	};
}

function example() {
	return (
		<>
			<Scope
				title="With Tooltip"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderSelector({
					tooltipText: 'As of 12/20/2010',
				})}
			</Scope>
			<Scope
				title="Small Size"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderSelector({
					size: '2xs',
				})}
			</Scope>
			<Scope
				title="Disabled"
				initialState={{
					recordsPerPage: 50,
					currentPage: 3,
				}}
			>
				{renderSelector({
					disabled: true,
				})}
			</Scope>
			<Scope
				title="With Page Navigation"
				initialState={{
					recordsPerPage: 20,
					currentPage: 1,
				}}
			>
				{renderSelector({
					showPageNav: true,
				})}
			</Scope>
			<Scope
				title="Few Items (hides page size options over items list length)"
				initialState={{
					recordsPerPage: 20,
					currentPage: 1,
				}}
			>
				{renderSelector({
					items: slice(allItems, 0, 64),
				})}
			</Scope>
			<Scope
				title="No items"
				initialState={{
					recordsPerPage: 20,
					currentPage: 1,
				}}
			>
				{renderSelector({
					items: [],
				})}
			</Scope>
			<Scope
				title="Null count"
				initialState={{
					recordsPerPage: 20,
					currentPage: 1,
				}}
			>
				{renderSelector({
					items: null,
				})}
			</Scope>
			<Scope
				title="Show as Loading"
				initialState={{
					recordsPerPage: 20,
					currentPage: 1,
				}}
			>
				{renderSelector({
					status: 'loading',
					items: null,
				})}
			</Scope>
			<Scope
				title="Show as Error"
				initialState={{
					recordsPerPage: 20,
					currentPage: 1,
				}}
			>
				{renderSelector({
					status: 'error',
					items: null,
				})}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Records Per Page Selector',
};

export default example;
