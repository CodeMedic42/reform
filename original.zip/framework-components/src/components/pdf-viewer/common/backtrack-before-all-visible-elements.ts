// @ts-nocheck
/**
 * Helper function for getVisibleElements.
 *
 * @param {number} index - initial guess at the first visible element
 * @param {Array} views - array of pages, into which `index` is an index
 * @param {number} top - the top of the scroll pane
 * @returns {number} less than or equal to `index` that is definitely at or
 *   before the first visible element in `views`, but not by too much. (Usually,
 *   this will be the first element in the first partially visible row in
 *   `views`, although sometimes it goes back one row further.)
 */
export default function backtrackBeforeAllVisibleElements(index, views, top) {
	let idx = index;

	// binarySearchFirstItem's assumption is that the input is ordered, with only
	// one index where the conditions flips from false to true: [false ...,
	// true...]. With vertical scrolling and spreads, it is possible to have
	// [false ..., true, false, true ...]. With wrapped scrolling we can have a
	// similar sequence, with many more mixed true and false in the middle.
	//
	// So there is no guarantee that the binary search yields the index of the
	// first visible element. It could have been any of the other visible elements
	// that were preceded by a hidden element.

	// Of course, if either this element or the previous (hidden) element is also
	// the first element, there's nothing to worry about.
	if (idx < 2) {
		return idx;
	}

	// That aside, the possible cases are represented below.
	//
	//     ****  = fully hidden
	//     A*B*  = mix of partially visible and/or hidden pages
	//     CDEF  = fully visible
	//
	// (1) Binary search could have returned A, in which case we can stop.
	// (2) Binary search could also have returned B, in which case we need to
	// check the whole row.
	// (3) Binary search could also have returned C, in which case we need to
	// check the whole previous row.
	//
	// There's one other possibility:
	//
	//     ****  = fully hidden
	//     ABCD  = mix of fully and/or partially visible pages
	//
	// (4) Binary search could only have returned A.

	// Initially assume that we need to find the beginning of the current row
	// (case 1, 2, or 4), which means finding a page that is above the current
	// page's top. If the found page is partially visible, we're definitely not in
	// case 3, and this assumption is correct.
	// let elt = views[idx].div;
	let elt = views[idx];
	let pageTop = elt.offsetTop + elt.clientTop;

	if (pageTop >= top) {
		// The found page is fully visible, so we're actually either in case 3 or 4,
		// and unfortunately we can't tell the difference between them without
		// scanning the entire previous row, so we just conservatively assume that
		// we do need to backtrack to that row. In both cases, the previous page is
		// in the previous row, so use its top instead.
		// elt = views[idx - 1].div;
		elt = views[idx - 1];
		pageTop = elt.offsetTop + elt.clientTop;
	}

	// Now we backtrack to the first page that still has its bottom below
	// `pageTop`, which is the top of a page in the first visible row (unless
	// we're in case 4, in which case it's the row before that).
	// `index` is found by binary search, so the page at `index - 1` is
	// invisible and we can start looking for potentially visible pages from
	// `index - 2`. (However, if this loop terminates on its first iteration,
	// which is the case when pages are stacked vertically, `index` should remain
	// unchanged, so we use a distinct loop variable.)
	for (let i = idx - 2; i >= 0; i -= 1) {
		// elt = views[i].div;
		elt = views[i];
		if (elt.offsetTop + elt.clientTop + elt.clientHeight <= pageTop) {
			// We have reached the previous row, so stop now.
			// This loop is expected to terminate relatively quickly because the
			// number of pages per row is expected to be small.
			break;
		}

		idx = i;
	}
	return idx;
}
