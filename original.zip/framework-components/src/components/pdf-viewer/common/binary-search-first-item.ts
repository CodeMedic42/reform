// @ts-nocheck
/**
 * Use binary search to find the index of the first item in a given array which
 * passes a given condition. The items are expected to be sorted in the sense
 * that if the condition is true for one item in the array, then it is also true
 * for all following items.
 *
 * @returns {Number} Index of the first array element to pass the test,
 *                   or |items.length| if no such element exists.
 */
export default function binarySearchFirstItem(items, condition) {
	let minIndex = 0;
	let maxIndex = items.length - 1;

	if (items.length === 0 || !condition(items[maxIndex])) {
		return items.length;
	}
	if (condition(items[minIndex])) {
		return minIndex;
	}

	while (minIndex < maxIndex) {
		// eslint-disable-next-line no-bitwise
		const currentIndex = (minIndex + maxIndex) >> 1;
		const currentItem = items[currentIndex];

		if (condition(currentItem)) {
			maxIndex = currentIndex;
		} else {
			minIndex = currentIndex + 1;
		}
	}
	return minIndex; /* === maxIndex */
}
