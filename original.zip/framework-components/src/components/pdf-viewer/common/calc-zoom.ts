// @ts-nocheck
const DEFAULT_SCALE_DELTA = 1.1;
const MIN_SCALE = 0.1;
const MAX_SCALE = 10.0;

export function calcZoomIn(currentScale, ticks) {
	let tix = ticks || 0;
	let newScale = currentScale;

	do {
		newScale = (newScale * DEFAULT_SCALE_DELTA).toFixed(2);
		newScale = Math.ceil(newScale * 10) / 10;
		newScale = Math.min(MAX_SCALE, newScale);

		tix -= 1;
	} while (tix > 0 && newScale < MAX_SCALE);

	return newScale;
}

export function calcZoomOut(currentScale, ticks) {
	let tix = ticks || 0;
	let newScale = currentScale;

	do {
		newScale = (newScale / DEFAULT_SCALE_DELTA).toFixed(2);
		newScale = Math.floor(newScale * 10) / 10;
		newScale = Math.max(MIN_SCALE, newScale);

		tix -= 1;
	} while (tix > 0 && newScale > MIN_SCALE);

	return newScale;
}
