// @ts-nocheck
export default function download(fileName, data) {
	const rawLength = data.length;

	const array = new Uint8Array(new ArrayBuffer(rawLength));

	for (let i = 0; i < rawLength; i += 1) {
		array[i] = data.charCodeAt(i);
	}

	const blob = new Blob([array], { type: 'application/pdf' });

	if (window.navigator.msSaveBlob) {
		window.navigator.msSaveBlob(blob, fileName);
	} else {
		const downloadLink = document.createElement('a');

		downloadLink.download = fileName;
		downloadLink.href = URL.createObjectURL(blob);

		document.body.appendChild(downloadLink);

		downloadLink.click();

		document.body.removeChild(downloadLink);
	}
}
