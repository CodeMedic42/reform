// @ts-nocheck
import binarySearchFirstItem from './binary-search-first-item';
import backtrackBeforeAllVisibleElements from './backtrack-before-all-visible-elements';

/**
 * Generic helper to find out what elements are visible within a scroll pane.
 *
 * Well, pretty generic. There are some assumptions placed on the elements
 * referenced by `views`:
 *   - If `horizontal`, no left of any earlier element is to the right of the
 *     left of any later element.
 *   - Otherwise, `views` can be split into contiguous rows where, within a row,
 *     no top of any element is below the bottom of any other element, and
 *     between rows, no bottom of any element in an earlier row is below the
 *     top of any element in a later row.
 *
 * (Here, top, left, etc. all refer to the padding edge of the element in
 * question. For pages, that ends up being equivalent to the bounding box of the
 * rendering canvas. Earlier and later refer to index in `views`, not page
 * layout.)
 *
 * @param scrollEl {HTMLElement} - a container that can possibly scroll
 * @param views {Array} - objects with a `div` property that contains an
 *   HTMLElement, which should all be descendents of `scrollEl` satisfying the
 *   above layout assumptions
 * @param sortByVisibility {boolean} - if true, the returned elements are sorted
 *   in descending order of the percent of their padding box that is visible
 * @param horizontal {boolean} - if true, the elements are assumed to be laid
 *   out horizontally instead of vertically
 * @returns {Object} `{ first, last, views: [{ id, x, y, view, percent }] }`
 */
export default function getVisibleElements(
	scrollEl,
	views,
	sortByVisibility = false,
	horizontal = false,
) {
	const top = scrollEl.scrollTop;
	const bottom = top + scrollEl.clientHeight;
	const left = scrollEl.scrollLeft;
	const right = left + scrollEl.clientWidth;

	// Throughout this "generic" function, comments will assume we're working with
	// PDF document pages, which is the most important and complex case. In this
	// case, the visible elements we're actually interested is the page canvas,
	// which is contained in a wrapper which adds no padding/border/margin, which
	// is itself contained in `view.div` which adds no padding (but does add a
	// border). So, as specified in this function's doc comment, this function
	// does all of its work on the padding edge of the provided views, starting at
	// offsetLeft/Top (which includes margin) and adding clientLeft/Top (which is
	// the border). Adding clientWidth/Height gets us the bottom-right corner of
	// the padding edge.
	function isElementBottomAfterViewTop(view) {
		// const element = view.div;
		const element = view;

		const elementBottom =
			element.offsetTop + element.clientTop + element.clientHeight;

		return elementBottom > top;
	}

	function isElementRightAfterViewLeft(view) {
		// const element = view.div;
		const element = view;

		const elementRight =
			element.offsetLeft + element.clientLeft + element.clientWidth;

		return elementRight > left;
	}

	const visible = [];
	const numViews = views.length;

	let firstVisibleElementInd = 0;

	if (numViews > 0) {
		const func = horizontal
			? isElementRightAfterViewLeft
			: isElementBottomAfterViewTop;

		firstVisibleElementInd = binarySearchFirstItem(views, func);
	}

	// Please note the return value of the `binarySearchFirstItem` function when
	// no valid element is found (hence the `firstVisibleElementInd` check below).
	if (
		firstVisibleElementInd > 0 &&
		firstVisibleElementInd < numViews &&
		!horizontal
	) {
		// In wrapped scrolling (or vertical scrolling with spreads), with some page
		// sizes, isElementBottomAfterViewTop doesn't satisfy the binary search
		// condition: there can be pages with bottoms above the view top between
		// pages with bottoms below. This function detects and corrects that error;
		// see it for more comments.
		firstVisibleElementInd = backtrackBeforeAllVisibleElements(
			firstVisibleElementInd,
			views,
			top,
		);
	}

	// lastEdge acts as a cutoff for us to stop looping, because we know all
	// subsequent pages will be hidden.
	//
	// When using wrapped scrolling or vertical scrolling with spreads, we can't
	// simply stop the first time we reach a page below the bottom of the view;
	// the tops of subsequent pages on the same row could still be visible. In
	// horizontal scrolling, we don't have that issue, so we can stop as soon as
	// we pass `right`, without needing the code below that handles the -1 case.
	let lastEdge = horizontal ? right : -1;

	for (let i = firstVisibleElementInd; i < numViews; i += 1) {
		const view = views[i];
		// const element = view.div;
		const element = view;
		const currentWidth = element.offsetLeft + element.clientLeft;
		const currentHeight = element.offsetTop + element.clientTop;
		const viewWidth = element.clientWidth;
		const viewHeight = element.clientHeight;
		const viewRight = currentWidth + viewWidth;
		const viewBottom = currentHeight + viewHeight;

		if (lastEdge === -1) {
			// As commented above, this is only needed in non-horizontal cases.
			// Setting lastEdge to the bottom of the first page that is partially
			// visible ensures that the next page fully below lastEdge is on the
			// next row, which has to be fully hidden along with all subsequent rows.
			if (viewBottom >= bottom) {
				lastEdge = viewBottom;
			}
		} else if ((horizontal ? currentWidth : currentHeight) > lastEdge) {
			break;
		}

		if (
			viewBottom <= top ||
			currentHeight >= bottom ||
			viewRight <= left ||
			currentWidth >= right
		) {
			// eslint-disable-next-line no-continue
			continue;
		}

		const hiddenHeight =
			Math.max(0, top - currentHeight) + Math.max(0, viewBottom - bottom);
		const hiddenWidth =
			Math.max(0, left - currentWidth) + Math.max(0, viewRight - right);

		const percent =
			// eslint-disable-next-line no-bitwise
			(((viewHeight - hiddenHeight) * (viewWidth - hiddenWidth) * 100) /
				viewHeight /
				viewWidth) |
			0;

		visible.push({
			index: i,
			x: currentWidth,
			y: currentHeight,
			view,
			percent,
		});
	}

	const first = visible[0];
	const last = visible[visible.length - 1];

	if (sortByVisibility) {
		visible.sort((a, b) => {
			const pc = a.percent - b.percent;

			if (Math.abs(pc) > 0.001) {
				return -pc;
			}

			return a.id - b.id; // ensure stability
		});
	}

	return { first, last, views: visible };
}
