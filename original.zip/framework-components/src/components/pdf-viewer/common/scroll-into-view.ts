/* eslint-disable no-underscore-dangle */
// @ts-nocheck
export default function scrollIntoView(
	element,
	spot,
	skipOverflowHiddenElements = false,
) {
	// Assuming offsetParent is available (it's not available when viewer is in
	// hidden iframe or object). We have to scroll: if the offsetParent is not set
	// producing the error. See also animationStarted.
	let parent = element.offsetParent;
	if (!parent) {
		return;
	}
	let offsetY = element.offsetTop + element.clientTop;
	let offsetX = element.offsetLeft + element.clientLeft;
	while (
		(parent.clientHeight === parent.scrollHeight &&
			parent.clientWidth === parent.scrollWidth) ||
		(skipOverflowHiddenElements &&
			getComputedStyle(parent).overflow === 'hidden')
	) {
		if (parent.dataset._scaleY) {
			offsetY /= parent.dataset._scaleY;
			offsetX /= parent.dataset._scaleX;
		}
		offsetY += parent.offsetTop;
		offsetX += parent.offsetLeft;
		parent = parent.offsetParent;
		if (!parent) {
			return; // no need to scroll
		}
	}
	if (spot) {
		if (spot.top !== undefined) {
			offsetY += spot.top;
		}
		if (spot.left !== undefined) {
			offsetX += spot.left;
			parent.scrollLeft = offsetX;
		}
	}
	parent.scrollTop = offsetY;
}
