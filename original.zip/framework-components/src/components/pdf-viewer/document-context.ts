// @ts-nocheck
// eslint-disable-next-line import/no-extraneous-dependencies
import { getDocument } from 'pdfjs-dist';
import EventEmitter from 'eventemitter3';
import Symbol from 'es6-symbol';
import Promise from 'bluebird';
import isNil from 'lodash-es/isNil';
import isUndefined from 'lodash-es/isUndefined';
import clone from 'lodash-es/clone';
import merge from 'lodash-es/merge';
import isInteger from 'lodash-es/isInteger';

const FIELDS = {
	EVENT_EMITTER: Symbol('event-emitter'),
	STATE: Symbol('state'),
};

const STATUS = {
	UNLOADED: 'unloaded',
	LOADED: 'loaded',
	LOADING: 'loading',
};

class DocumentContext {
	constructor(defaultScale, defaultPageNumber) {
		this[FIELDS.EVENT_EMITTER] = new EventEmitter();
		this[FIELDS.STATE] = {
			status: STATUS.UNLOADED,
			progress: 0,
			document: null,
			pages: null,
			currentPage: defaultPageNumber,
			scale: defaultScale,
		};
		this.defaultScale = defaultScale;
		this.defaultPageNumber = isInteger(defaultPageNumber)
			? defaultPageNumber
			: 0;
	}

	currentPage(value) {
		const { currentPage } = this.state();

		if (isUndefined(value)) {
			return currentPage;
		}

		if (currentPage === value) {
			return value;
		}

		this.state({
			currentPage: value,
		});

		this[FIELDS.EVENT_EMITTER].emit('pageChange', value);

		return value;
	}

	goToPage(pageNumber) {
		this[FIELDS.EVENT_EMITTER].emit('gotoPage', pageNumber);
	}

	pageCount() {
		const { document } = this.state();

		if (isNil(document)) {
			return null;
		}

		return document.numPages;
	}

	page(pageNumber) {
		const pages = this.pages();

		if (isNil(pages)) {
			return null;
		}

		return pages[pageNumber];
	}

	pages() {
		const { pages } = this.state();

		return pages;
	}

	status() {
		const { status } = this.state();

		return status;
	}

	state(value) {
		if (isUndefined(value)) {
			return this[FIELDS.STATE];
		}

		const newState = merge({}, this[FIELDS.STATE], value);

		this[FIELDS.STATE] = newState;

		this[FIELDS.EVENT_EMITTER].emit('change', newState);

		return newState;
	}

	unload() {
		const { status } = this.state();

		if (status === STATUS.UNLOADED) {
			return;
		}

		this.state({
			document: null,
			progress: 0,
			pages: null,
			status: STATUS.UNLOADED,
			currentPage: this.defaultPageNumber,
			scale: this.defaultScale,
			file: {
				name: null,
				data: null,
			},
		});

		this[FIELDS.EVENT_EMITTER].emit('unloaded');
	}

	scale(value) {
		const { scale } = this.state();

		if (isUndefined(value)) {
			return scale;
		}

		if (scale === value) {
			return value;
		}

		this.state({
			scale: value,
		});

		this[FIELDS.EVENT_EMITTER].emit('scaleChange', value);

		return value;
	}

	getFile() {
		const { file } = this.state();

		return clone(file);
	}

	load(file) {
		if (isNil(file) || isNil(file.name) || isNil(file.data)) {
			throw new Error('Must provide a file name and data.');
		}

		this.unload();

		this.state({
			status: STATUS.LOADING,
		});

		this[FIELDS.EVENT_EMITTER].emit('loading');

		const loadingTask = getDocument({ data: file.data });

		return loadingTask.promise
			.then((document) => {
				this[FIELDS.DOCUMENT] = document;

				this.state({
					document,
				});

				const pageCount = document.numPages;
				let counter = 1;
				let loadedCount = 0;
				const pagePromises = [];

				const pageLoaded = (page) => {
					loadedCount += 1;

					this[FIELDS.PROGRESS] = (100 / pageCount) * loadedCount;

					this.state({
						progress: (100 / pageCount) * loadedCount,
					});

					return page;
				};

				for (counter; counter <= pageCount; counter += 1) {
					const pagePromise = document
						.getPage(counter)
						.then(pageLoaded);

					pagePromises.push(pagePromise);
				}

				return Promise.all(pagePromises);
			})
			.then((pages) => {
				const currentPage =
					this.defaultPageNumber < pages.length
						? this.defaultPageNumber
						: pages.length - 1;

				this.state({
					progress: 100,
					status: STATUS.LOADED,
					pages,
					currentPage,
					scale: this.defaultScale,
					file: clone(file),
				});

				this[FIELDS.EVENT_EMITTER].emit('loaded', pages);
			});
	}

	print() {
		this[FIELDS.EVENT_EMITTER].emit('print');
	}

	on(eventId, callback) {
		this[FIELDS.EVENT_EMITTER].on(eventId, callback);

		return () => {
			this[FIELDS.EVENT_EMITTER].removeListener(eventId, callback);
		};
	}

	removeListener(eventId, callback) {
		this[FIELDS.EVENT_EMITTER].removeListener(eventId, callback);
	}
}

DocumentContext.STATUS = STATUS;

export default DocumentContext;
