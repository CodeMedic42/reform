// @ts-nocheck
import PDFViewer from './pdf-viewer';

export default PDFViewer;
