// @ts-nocheck
import Promise from 'bluebird';
import EventEmitter from 'eventemitter3';
import isNil from 'lodash-es/isNil';

const STATES = {
	UNLOADED: 'unloaded',
	LOADING: 'loading',
	LOADED: 'loaded',
};

function setElementRect(element, width, height) {
	// eslint-disable-next-line no-param-reassign
	element.style.width = `${width}px`;
	// eslint-disable-next-line no-param-reassign
	element.style.height = `${height}px`;
}

function calculateVisibility(documentElement, pageElement) {
	const top = documentElement.scrollTop;
	const bottom = top + documentElement.clientHeight;

	const viewTop = pageElement.offsetTop + pageElement.clientTop;
	const viewHeight = pageElement.clientHeight;
	const viewBottom = viewTop + viewHeight;

	if (viewBottom <= top || viewTop >= bottom) {
		return 0;
	}

	const hiddenHeight =
		Math.max(0, top - viewTop) + Math.max(0, viewBottom - bottom);

	// eslint-disable-next-line no-bitwise
	const percent = (((viewHeight - hiddenHeight) * 100) / viewHeight) | 0;

	return percent;
}

function buildContent() {
	const element = window.document.createElement('canvas');

	element.className = 'ai-pdf-document-page-content';

	return element;
}

function buildContentWrapperElement() {
	const element = window.document.createElement('div');

	element.className = 'ai-pdf-document-page-content-wrapper';

	return element;
}

function buildLoadingElement() {
	const element = window.document.createElement('div');

	element.className = 'ai-spinner-ring spinner-color-blue size-md solid-spinner ai-pdf-document-page-content-loading';

	return element;
}

function finalizeScale(scale, pagesElement, standardWidth) {
	if (scale === 'fit-to-screen') {
		const documentWidth = pagesElement.clientWidth - 10;

		return documentWidth / standardWidth;
	}

	return scale;
}

function cleanPage() {
	if (!isNil(this.loadingElement) && this.isRendered()) {
		this.loadingElement.remove();

		this.loadingElement = null;
	}

	if (!isNil(this.outgoingWrapperElement)) {
		this.outgoingWrapperElement.remove();

		this.outgoingWrapperElement = null;
	}
}

function renderPage(force) {
	if (this.isRendered()) {
		cleanPage.call(this);

		return Promise.resolve();
	}

	if (!this.alwaysRender && this.visibility <= 0 && !force) {
		cleanPage.call(this);

		return Promise.resolve();
	}

	const canvas = buildContent();

	this.contentWrapperElement.appendChild(canvas);

	this.contentElement = canvas;

	canvas.height = this.viewport.height;
	canvas.width = this.viewport.width;

	const context = canvas.getContext('2d');

	const renderContext = {
		canvasContext: context,
		viewport: this.viewport,
	};

	this.renderTask = this.page.render(renderContext);

	return this.renderTask.promise
		.then(() => {
			this.renderTask = null;
		})
		.catch((message) => {
			// eslint-disable-next-line no-console
			console.warn(`Catch from pdf render ${message}`);
		})
		.then(() => {
			cleanPage.call(this);
		});
}

function updatePage(scale) {
	if (!this.status.rendering) {
		this.status.rendering = true;

		this.emitter.emit('status', this.status);
	}

	let changed = false;

	if (!isNil(scale)) {
		this.scale = scale;
	}

	const calculatedScale = finalizeScale(
		this.scale,
		this.pagesElement,
		this.standardWidth,
	);

	if (calculatedScale !== this.calculatedScale) {
		changed = true;

		this.calculatedScale = calculatedScale;

		this.viewport = this.viewport.clone({
			scale: calculatedScale,
		});

		setElementRect(
			this.pageElement,
			this.viewport.width,
			this.viewport.height,
		);
	}

	this.visibility = calculateVisibility(
		this.documentElement,
		this.pageElement,
	);

	if (changed) {
		if (isNil(this.outgoingWrapperElement)) {
			this.outgoingWrapperElement = this.contentWrapperElement;

			this.outgoingWrapperElement.classList.add('zoomed');
		} else {
			this.contentWrapperElement.remove();
		}

		// create new wrapper
		this.contentWrapperElement = buildContentWrapperElement();

		this.pageElement.appendChild(this.contentWrapperElement);

		// clear content, will be removed when contentWrapperElement is removed
		this.contentElement = null;

		// Apply loading if necessary
		if (isNil(this.loadingElement)) {
			this.loadingElement = buildLoadingElement();

			this.pageElement.appendChild(this.loadingElement);
		}
	}

	return renderPage.call(this).then(() => {
		if (this.status.rendering) {
			this.status.rendering = false;

			this.emitter.emit('status', this.status);
		}
	});
}

function disposePage() {
	if (this.status.rendering || this.status.state !== STATES.UNLOADED) {
		this.status.rendering = false;
		this.status = STATES.UNLOADED;

		this.emitter.emit('status', this.status);
	}

	if (!isNil(this.contentWrapperElement)) {
		this.contentWrapperElement.remove();

		this.contentWrapperElement = null;
	}

	this.pageElement = null;
	this.pagesElement = null;
	this.documentElement = null;
}

function initialize() {
	const { state } = this.status;

	if (state !== STATES.UNLOADED) {
		throw new Error('Load called for Page Render Context more than once.');
	}

	this.status = {
		state: STATES.LOADING,
		rendering: true,
	};

	this.emitter.emit('status', this.status);

	const viewport = this.page.getViewport({
		scale: 1,
	});

	const standardWidth = viewport.width;
	this.standardWidth = standardWidth;

	const standardHeight = viewport.height;
	this.standardHeight = standardHeight;

	this.calculatedScale = finalizeScale(
		this.scale,
		this.pagesElement,
		standardWidth,
	);

	this.viewport = viewport.clone({
		scale: this.calculatedScale,
	});

	this.contentWrapperElement = buildContentWrapperElement();

	this.loadingElement = buildLoadingElement();

	setElementRect(this.pageElement, this.viewport.width, this.viewport.height);

	this.pageElement.appendChild(this.contentWrapperElement);
	this.pageElement.appendChild(this.loadingElement);

	this.visibility = calculateVisibility(
		this.documentElement,
		this.pageElement,
	);

	return renderPage.call(this).then(() => {
		this.status = {
			state: STATES.LOADED,
			rendering: false,
		};

		this.emitter.emit('status', this.status);
	});
}

class PageRenderContext {
	constructor({
		page,
		pageNumber,
		documentElement,
		pagesElement,
		pageElement,
		scale,
		alwaysRender,
	}) {
		this.emitter = new EventEmitter();

		this.documentElement = documentElement;
		this.pagesElement = pagesElement;
		this.pageElement = pageElement;
		this.page = page;
		this.scale = scale;
		this.pageNumber = pageNumber;
		this.disposed = false;
		this.alwaysRender = alwaysRender;

		this.status = {
			state: STATES.UNLOADED,
			rendering: false,
		};
	}

	isRendered() {
		return !isNil(this.contentElement);
	}

	load() {
		return initialize.call(this);
	}

	update(scale) {
		if (this.disposed) {
			throw new Error(
				'Actions are being performed on a disposed PageRenderContext',
			);
		}

		return updatePage.call(this, scale);
	}

	dispose() {
		if (this.disposed) {
			return;
		}

		this.disposed = true;

		cleanPage.call(this);

		disposePage.call(this);
	}
}

PageRenderContext.STATES = STATES;

export default PageRenderContext;
