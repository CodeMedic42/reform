// @ts-nocheck
import React, { Component } from 'react';
import PropTypes from 'prop-types';
// import classnames from 'classnames';
import RenderContext from './render-context';
import DocumentContext from './document-context';

class PdfDocument extends Component {
	constructor(props) {
		super(props);

		this.documentRef = React.createRef();
		this.pagesRef = React.createRef();

		this.state = {
			pages: null,
		};

		this.handleDocumentLoad = this.handleDocumentLoad.bind(this);
		this.handleDocumentUnload = this.handleDocumentUnload.bind(this);
		this.handleDocumentScaleChage =
			this.handleDocumentScaleChage.bind(this);
		this.handleDocumentGoToPage = this.handleDocumentGoToPage.bind(this);
	}

	componentDidMount() {
		const { documentContext, singlePage, useSvg } = this.props;

		const scale = documentContext.scale();

		this.renderContext = new RenderContext(
			this.documentRef.current,
			this.pagesRef.current,
			scale,
			{
				singlePage,
				useSvg,
				resizable: true,
			},
		);

		this.renderContext.on('active', (activePageNumber) => {
			documentContext.currentPage(activePageNumber);
		});

		documentContext.on('loaded', this.handleDocumentLoad);
		documentContext.on('unloaded', this.handleDocumentUnload);
		documentContext.on('scaleChange', this.handleDocumentScaleChage);
		documentContext.on('gotoPage', this.handleDocumentGoToPage);

		if (documentContext.status() === DocumentContext.STATUS.LOADED) {
			this.load();
		}
	}

	componentWillUnmount() {
		this.renderContext.dispose();

		this.unload();
	}

	handleDocumentGoToPage(pageNumber) {
		this.renderContext.scrollTo(pageNumber);
	}

	handleDocumentScaleChage(scale) {
		// this.setState({
		//   scale,
		// });

		this.renderContext.setScale(scale);
	}

	handleDocumentLoad() {
		this.load();
	}

	handleDocumentUnload() {
		this.unload();
	}

	unload() {
		const { documentContext } = this.props;

		documentContext.removeListener('loaded', this.handleDocumentLoad);
		documentContext.removeListener('unloaded', this.handleDocumentUnload);
		documentContext.removeListener(
			'scaleChange',
			this.handleDocumentScaleChage,
		);
		documentContext.removeListener('gotoPage', this.handleDocumentGoToPage);

		this.renderContext.unload();
	}

	load() {
		const { documentContext } = this.props;

		const pages = documentContext.pages();
		const currentPageNumber = documentContext.currentPage();

		this.setState({
			// scale: documentContext.scale(),
			pages: this.renderContext.load(
				pages,
				currentPageNumber,
				(pageRef, pageNumber) => (
					<div
						key={pageNumber}
						ref={pageRef}
						className="ai-pdf-page"
					/>
				),
			),
		});
	}

	render() {
		const {
			pages,
			// scale,
		} = this.state;

		// const className = classnames('ai-pdf-pages', {
		//   'fit-to-screen': scale === 'fit-to-screen',
		// });

		return (
			<div ref={this.documentRef} className="ai-pdf-document">
				<div ref={this.pagesRef} className="ai-pdf-pages">{pages}</div>
			</div>
		);
	}
}

PdfDocument.propTypes = {
	// eslint-disable-next-line react/forbid-prop-types
	documentContext: PropTypes.any.isRequired,
	useSvg: PropTypes.bool,
	singlePage: PropTypes.bool,
};

PdfDocument.defaultProps = {
	useSvg: false,
	singlePage: false,
};

export default PdfDocument;
