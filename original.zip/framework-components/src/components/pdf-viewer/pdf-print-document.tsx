// @ts-nocheck
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import noop from 'lodash-es/noop';
import PdfPrintingDialog from './pdf-printing-dialog';
import RenderContext from './render-context';
import DocumentContext from './document-context';

const CSS_UNITS = 96.0 / 72.0;

class PdfPrintDocument extends Component {
	constructor(props) {
		super(props);

		this.documentRef = React.createRef();

		this.state = {
			progress: 0,
		};

		this.handleCancel = this.handleCancel.bind(this);
		this.handleProgress = this.handleProgress.bind(this);
		this.handleStatus = this.handleStatus.bind(this);
	}

	componentDidMount() {
		const { documentContext } = this.props;

		if (documentContext.status() !== DocumentContext.STATUS.LOADED) {
			// eslint-disable-next-line no-console
			console.error(
				'DocumentContext must be loaded before it can be rendered in a print context',
			);
		}

		const pages = documentContext.pages();

		this.renderContext = new RenderContext(
			this.documentRef.current,
			this.documentRef.current,
			CSS_UNITS,
			{
				alwaysRender: true,
			},
		);

		this.renderContext.on('progress', this.handleProgress);
		this.renderContext.on('status', this.handleStatus);

		this.setState({
			pages: this.renderContext.load(pages, 0, (pageRef, pageNumber) => (
				<div
					ref={pageRef}
					key={pageNumber}
					className="ai-pdf-print-page"
				>
					{/* <div ref={pageRef} className="ai-pdf-page" /> */}
				</div>
			)),
		});
	}

	componentWillUnmount() {
		this.cleanup();
	}

	handleStatus(status) {
		if (this.finished) {
			return;
		}

		const { onReady } = this.props;

		if (status.state === RenderContext.STATES.LOADED) {
			this.setState({
				progress: 100,
			});

			this.renderContext.removeListener('progress', this.handleProgress);
			this.renderContext.removeListener('status', this.handleStatus);

			onReady();
		}
	}

	handleProgress(count) {
		if (this.finished) {
			return;
		}

		const { documentContext } = this.props;

		const pageCount = documentContext.pageCount();

		this.setState({
			progress: (count / pageCount) * 100,
		});
	}

	handleCancel() {
		this.cleanup();

		const { onCancel } = this.props;

		onCancel();
	}

	cleanup() {
		this.finished = true;

		this.renderContext.removeListener('progress', this.handleProgress);
		this.renderContext.removeListener('status', this.handleStatus);

		// Clean things up
		this.renderContext.dispose();
	}

	render() {
		const { progress, pages } = this.state;

		return (
			<>
				<PdfPrintingDialog
					progress={progress}
					onCancel={this.handleCancel}
				/>
				<div ref={this.documentRef} className="ai-pdf-print-document">
					{pages}
				</div>
			</>
		);
	}
}

PdfPrintDocument.propTypes = {
	// eslint-disable-next-line react/forbid-prop-types
	documentContext: PropTypes.any.isRequired,
	onReady: PropTypes.func,
	onCancel: PropTypes.func,
};

PdfPrintDocument.defaultProps = {
	onReady: noop,
	onCancel: noop,
};

export default PdfPrintDocument;
