// @ts-nocheck
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import Promise from 'bluebird';
import isNil from 'lodash-es/isNil';
// import printCss from '!!raw-loader!./print.css';
import PrintStyles from './print-styles';
import PdfPrintDocument from './pdf-print-document';

class PdfPrinter extends Component {
	constructor(props) {
		super(props);

		this.state = {
			portal: null,
			printContainer: null,
		};

		this.handlePrint = this.handlePrint.bind(this);
		this.handleCancel = this.handleCancel.bind(this);
		this.handleReady = this.handleReady.bind(this);
	}

	componentDidMount() {
		const { documentContext } = this.props;

		documentContext.on('print', this.handlePrint);
	}

	componentWillUnmount() {
		const { documentContext } = this.props;

		documentContext.removeListener('print', this.handlePrint);

		this.cleanup();
	}

	handleCancel() {
		this.cleanup();
	}

	handleReady() {
		this.print();
	}

	handlePrint() {
		const printContainers = window.document.querySelectorAll(
			'body > div.ai-pdf-print-container',
		);

		if (printContainers.length > 1) {
			throw new Error('More than one valid print container found.');
		}

		let { 0: printContainer } = printContainers;

		if (isNil(printContainer)) {
			printContainer = document.createElement('div');

			printContainer.className = 'ai-pdf-print-container';

			document.body.appendChild(printContainer);
		}

		if (printContainer.childNodes.length > 0) {
			throw new Error('The print container already has children.');
		}

		// Create the initial structure
		// This include styling which on affects the printing
		// but which we do not want to keep around after.
		const portal = ReactDOM.createPortal(
			this.renderPrinterContents(),
			printContainer,
		);

		this.setState({
			portal,
			printContainer,
		});
	}

	print() {
		return new Promise((resolve) => {
			setTimeout(() => {
				window.print();

				// Delay promise resolution in case print() was not synchronous.
				setTimeout(resolve, 20);
			}, 0);
		}).then(() => {
			this.cleanup();
		});
	}

	cleanup() {
		const { printContainer } = this.state;

		if (isNil(printContainer)) {
			return;
		}

		printContainer.parentNode.removeChild(printContainer);

		this.setState({
			portal: null,
			printContainer: null,
		});
	}

	renderPrinterContents() {
		const { documentContext } = this.props;

		return (
			<>
				<PdfPrintDocument
					documentContext={documentContext}
					onReady={this.handleReady}
					onCancel={this.handleCancel}
				/>
				<PrintStyles />
				<style>
					{
						'@supports ((size:A4) and (size:1pt 1pt)) {@page { size: 612pt 792pt;}}'
					}
				</style>
			</>
		);
	}

	render() {
		const { portal } = this.state;

		return portal;
	}
}

PdfPrinter.propTypes = {
	// eslint-disable-next-line react/forbid-prop-types
	documentContext: PropTypes.any.isRequired,
};

PdfPrinter.defaultProps = {};

export default PdfPrinter;
