// @ts-nocheck
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import noop from 'lodash-es/noop';
import Button from '../button';

class PdfPrintingDialog extends Component {
	constructor(props) {
		super(props);

		this.handleCancel = this.handleCancel.bind(this);
	}

	handleCancel() {
		const { onCancel } = this.props;

		onCancel();
	}

	render() {
		const { progress } = this.props;

		const button =
			progress < 100 ? (
				<div className="ai-pdf-print-dialog-row">
					<Button
						color="secondary"
						variant="opaque"
						onClick={this.handleCancel}
					>
						Cancel
					</Button>
				</div>
			) : null;

		return (
			<div className="ai-pdf-viewer-print-bg">
				<div className="ai-pdf-print-dialog">
					<div className="ai-pdf-print-dialog-row">
						<span>Preparing document for printing…</span>
					</div>
					<div className="ai-pdf-print-dialog-row">
						<div className="ai-pdf-print-dialog-progress">
							<div
								className="ai-pdf-print-dialog-progress-bar"
								style={{ width: `${progress}%` }}
							/>
						</div>
					</div>
					{button}
				</div>
			</div>
		);
	}
}

PdfPrintingDialog.propTypes = {
	progress: PropTypes.number,
	onCancel: PropTypes.func,
};

PdfPrintingDialog.defaultProps = {
	progress: 0,
	onCancel: noop,
};

export default PdfPrintingDialog;
