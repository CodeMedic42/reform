// @ts-nocheck
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import toInteger from 'lodash-es/toInteger';
import noop from 'lodash-es/noop';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUp } from '@audacious/icons/solid/faUp';
import { faDown } from '@audacious/icons/solid/faDown';
import { faMinus } from '@audacious/icons/solid/faMinus';
import { faPlus } from '@audacious/icons/solid/faPlus';
import { faPrint } from '@audacious/icons/solid/faPrint';
import { faDownload } from '@audacious/icons/solid/faDownload';
import { faRectangleXmark } from '@audacious/icons/solid/faRectangleXmark';
import DocumentContext from './document-context';
import { calcZoomIn, calcZoomOut } from './common/calc-zoom';
import download from './common/download';

class PdfToolbar extends Component {
	constructor(props) {
		super(props);

		this.state = {
			currentPageNumber: null,
			pageCount: null,
			enabled: false,
		};

		this.gotoNextPage = this.gotoNextPage.bind(this);
		this.gotoPreviousPage = this.gotoPreviousPage.bind(this);
		this.pageChange = this.pageChange.bind(this);
		this.gotoPage = this.gotoPage.bind(this);
		this.print = this.print.bind(this);
		this.download = this.download.bind(this);
		this.zoomIn = this.zoomIn.bind(this);
		this.zoomOut = this.zoomOut.bind(this);
		this.close = this.close.bind(this);
		this.handleDocumentLoaded = this.handleDocumentLoaded.bind(this);
		this.handleDocumentUnloaded = this.handleDocumentUnloaded.bind(this);
		this.handleDocumentPageChange =
			this.handleDocumentPageChange.bind(this);
	}

	componentDidMount() {
		const { documentContext } = this.props;

		documentContext.on('loaded', this.handleDocumentLoaded);
		documentContext.on('unloaded', this.handleDocumentUnloaded);
		documentContext.on('pageChange', this.handleDocumentPageChange);

		if (documentContext.status() === DocumentContext.STATUS.LOADED) {
			this.setState({
				currentPageNumber: documentContext.currentPage(),
				pageCount: documentContext.pageCount(),
				enabled: true,
			});
		}
	}

	componentWillUnmount() {
		const { documentContext } = this.props;

		documentContext.removeListener('loaded', this.handleDocumentLoaded);
		documentContext.removeListener('unloaded', this.handleDocumentUnloaded);
		documentContext.removeListener(
			'pageChange',
			this.handleDocumentPageChange,
		);
	}

	handleDocumentLoaded() {
		const { documentContext } = this.props;

		this.setState({
			currentPageNumber: documentContext.currentPage(),
			pageCount: documentContext.pageCount(),
			enabled: true,
		});
	}

	handleDocumentUnloaded() {
		this.setState({
			currentPageNumber: null,
			pageCount: null,
			enabled: false,
		});
	}

	handleDocumentPageChange(pageNumber) {
		this.setState({
			currentPageNumber: pageNumber,
		});
	}

	close() {
		const { onClose } = this.props;

		onClose();
	}

	gotoNextPage() {
		const { currentPageNumber, pageCount } = this.state;

		if (currentPageNumber >= pageCount) {
			return;
		}

		this.gotoPage(currentPageNumber + 1);
	}

	gotoPreviousPage() {
		const { currentPageNumber } = this.state;

		if (currentPageNumber <= 0) {
			return;
		}

		this.gotoPage(currentPageNumber - 1);
	}

	pageChange(event) {
		let pageNumber = toInteger(event.target.value) - 1;

		const { pageCount } = this.state;

		if (pageNumber <= 0) {
			pageNumber = 0;
		} else if (pageNumber >= pageCount) {
			pageNumber = pageCount - 1;
		}

		this.gotoPage(pageNumber);
	}

	gotoPage(pageNumber) {
		const { documentContext } = this.props;

		documentContext.goToPage(pageNumber);
	}

	zoomIn() {
		const { documentContext } = this.props;

		let scale = documentContext.scale();

		if (scale === 'fit-to-screen') {
			documentContext.scale(1.5);

			return;
		}

		scale = calcZoomIn(scale);

		documentContext.scale(scale);
	}

	zoomOut() {
		const { documentContext } = this.props;

		let scale = documentContext.scale();

		if (scale === 'fit-to-screen') {
			documentContext.scale(1.5);

			return;
		}

		scale = calcZoomOut(scale);

		documentContext.scale(scale);
	}

	print() {
		const { documentContext } = this.props;

		documentContext.print();
	}

	download() {
		const { documentContext } = this.props;

		const file = documentContext.getFile();

		download(file.name, file.data);
	}

	buildPagingControls() {
		const {
			paging: {
				enabled,
				options: { step, goto },
			},
		} = this.props;

		const { currentPageNumber, pageCount } = this.state;

		if (!enabled) {
			return null;
		}

		let stepControls = null;

		if (step) {
			const previousPageDisabled = currentPageNumber <= 0;
			const nextPageDisabled = currentPageNumber >= pageCount - 1;

			stepControls = (
				<div className="split-toolbar-button hidden-small-view">
					<button
						type="button"
						className="toolbar-button page-up"
						title="Previous Page"
						id="previous"
						data-l10n-id="previous"
						disabled={previousPageDisabled}
						onClick={this.gotoPreviousPage}
					>
						<FontAwesomeIcon icon={faUp} size="lg"/>
						<span data-l10n-id="previous_label">Previous</span>
					</button>
					<div className="split-toolbar-button-separator" />
					<button
						type="button"
						className="toolbar-button page-down"
						title="Next Page"
						id="next"
						data-l10n-id="next"
						disabled={nextPageDisabled}
						onClick={this.gotoNextPage}
					>
						<FontAwesomeIcon icon={faDown} size="lg"/>
						<span data-l10n-id="next_label">Next</span>
					</button>
				</div>
			);
		}

		let pageNumber = '';
		let gotoInput = null;

		if (goto) {
			gotoInput = (
				<input
					type="number"
					id="page-number"
					className="toolbar-field page-number"
					title="Page"
					value={currentPageNumber + 1}
					size="4"
					min="1"
					data-l10n-id="page"
					onChange={this.pageChange}
				/>
			);
		} else {
			pageNumber = currentPageNumber;
		}

		return (
			<>
				{stepControls}
				<div className="page-number-group">
					{gotoInput}
					<span id="num-pages" className="toolbar-label">
						{`${pageNumber} of ${pageCount}`}
					</span>
				</div>
			</>
		);
	}

	buildZoomControls() {
		const { zoom } = this.props;

		if (!zoom) {
			return null;
		}

		return (
			<div className="split-toolbar-button">
				<button
					type="button"
					id="zoom-out"
					className="toolbar-button zoom-out"
					title="Zoom Out"
					data-l10n-id="zoom_out"
					onClick={this.zoomOut}
				>
					<FontAwesomeIcon icon={faMinus} size="lg"/>
					<span data-l10n-id="zoom_out_label">Zoom Out</span>
				</button>
				<div className="split-toolbar-button-separator" />
				<button
					type="button"
					id="zoom-in"
					className="toolbar-button zoom-in"
					title="Zoom In"
					data-l10n-id="zoom_in"
					onClick={this.zoomIn}
				>
					<FontAwesomeIcon icon={faPlus} size="lg"/>
					<span data-l10n-id="zoom_in_label">Zoom In</span>
				</button>
			</div>
		);
	}

	buildMiscControls() {
		const {
			print: printEnabled,
			download: downloadEnabled,
			close: closeEnabled,
		} = this.props;

		let printControl = null;
		let downloadControl = null;
		let closeControl = null;

		if (printEnabled) {
			printControl = (
				<button
					type="button"
					id="print"
					className="toolbar-button print"
					title="Print"
					data-l10n-id="print"
					onClick={this.print}
				>
					<FontAwesomeIcon icon={faPrint} size="lg"/>
					<span data-l10n-id="print_label">Print</span>
				</button>
			);
		}

		if (downloadEnabled) {
			downloadControl = (
				<button
					type="button"
					id="download"
					className="toolbar-button download"
					title="Download"
					data-l10n-id="download"
					onClick={this.download}
				>
					<FontAwesomeIcon icon={faDownload} size="lg"/>
					<span data-l10n-id="download_label">Download</span>
				</button>
			);
		}

		if (closeEnabled) {
			closeControl = (
				<button
					type="button"
					id="close"
					className="toolbar-button close"
					title="Close"
					data-l10n-id="close"
					onClick={this.close}
				>
					<FontAwesomeIcon icon={faRectangleXmark} size="lg"/>
					<span data-l10n-id="close_label">Close</span>
				</button>
			);
		}

		return (
			<>
				{printControl}
				{downloadControl}
				{closeControl}
			</>
		);
	}

	buildControls() {
		const { enabled } = this.state;

		if (!enabled) {
			return null;
		}

		return (
			<>
				<div id="toolbar-viewer-left">{this.buildPagingControls()}</div>
				<div id="toolbar-viewer-right">{this.buildMiscControls()}</div>
				<div id="toolbar-viewer-middle">{this.buildZoomControls()}</div>
			</>
		);
	}

	render() {
		return (
			<div className="ai-pdf-toolbar">
				<div id="toolbar-container">
					<div id="toolbar-viewer">{this.buildControls()}</div>
				</div>
			</div>
		);
	}
}

PdfToolbar.propTypes = {
	// eslint-disable-next-line react/forbid-prop-types
	documentContext: PropTypes.any.isRequired,
	paging: PropTypes.shape({
		enabled: PropTypes.bool,
		options: PropTypes.shape({
			step: PropTypes.bool,
			goto: PropTypes.bool,
		}),
	}),
	zoom: PropTypes.bool,
	print: PropTypes.bool,
	download: PropTypes.bool,
	close: PropTypes.bool,
	onClose: PropTypes.func,
};

PdfToolbar.defaultProps = {
	paging: {
		enabled: false,
	},
	zoom: false,
	print: false,
	download: false,
	close: false,
	onClose: noop,
};

export default PdfToolbar;
