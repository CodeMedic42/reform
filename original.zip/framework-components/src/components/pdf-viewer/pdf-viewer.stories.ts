// @ts-nocheck
import PdfViewer from '.';

export default {
	title: 'Miscellaneous/PDF Viewer',
	component: PdfViewer,
};

export { default as exampleA } from './stories/example-a';
export { default as exampleB } from './stories/example-b';
export { default as exampleC } from './stories/example-c';
export { default as exampleD } from './stories/example-d';
export { default as exampleE } from './stories/example-e';
export { default as exampleF } from './stories/example-f';
export { default as exampleG } from './stories/example-g';
export { default as exampleH } from './stories/example-h';
