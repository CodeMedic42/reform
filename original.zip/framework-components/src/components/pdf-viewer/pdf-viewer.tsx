// @ts-nocheck
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import noop from 'lodash-es/noop';
import map from 'lodash-es/map';
// eslint-disable-next-line import/no-extraneous-dependencies
import { GlobalWorkerOptions } from 'pdfjs-dist';
import DocumentContext from './document-context';
import PdfToolBar from './pdf-toolbar';
import PdfDocument from './pdf-document';
import PdfPrintView from './pdf-print-view';

class PdfViewer extends Component {
	constructor(props) {
		super(props);

		const { file, defaultScale, defaultPageNumber } = props;

		this.documentContext = new DocumentContext(
			defaultScale,
			defaultPageNumber,
		);

		if (!isNil(file.data)) {
			this.documentContext.load(file);
		}

		this.handlePrint = this.handlePrint.bind(this);
	}

	static setWorker(worker) {
		GlobalWorkerOptions.workerPort = worker;
	}

	componentWillUnmount() {
		this.documentContext.unload();
	}

	// eslint-disable-next-line class-methods-use-this
	handlePrint() {}

	render() {
		const {
			useSvg,
			toolbar: { enabled, options },
			singlePage,
			className,
			noScroll,
			onClose
		} = this.props;

		const toolbar = enabled ? (
			<PdfToolBar
				{...options}
				documentContext={this.documentContext}
				onClose={onClose}
				onPrint={this.handlePrint}
			/>
		) : null;

		return (
			<div className={classnames('ai-pdf-viewer', className, { 'no-scroll': noScroll })}>
				<div
					className={classnames('ai-pdf-container', {
						'toolbar-padding': enabled,
					})}
				>
					{toolbar}
					<PdfDocument
						documentContext={this.documentContext}
						useSvg={useSvg}
						singlePage={singlePage}
					/>
				</div>
				<PdfPrintView documentContext={this.documentContext} />
			</div>
		);
	}
}

PdfViewer.SCALE = {
	FIT_TO_SCREEN: 'fit-to-screen',
	ACTUAL_SIZE: 'actual-size',
};

PdfViewer.propTypes = {
	file: PropTypes.shape({
		name: PropTypes.string,
		// eslint-disable-next-line react/forbid-prop-types
		data: PropTypes.any,
	}).isRequired,
	useSvg: PropTypes.bool,
	defaultScale: PropTypes.oneOfType([
		PropTypes.number,
		PropTypes.oneOf(map(PdfViewer.SCALE, (scale) => scale)),
	]),
	toolbar: PropTypes.shape({
		enabled: PropTypes.bool,
		options: PropTypes.shape({
			paging: PropTypes.shape({
				enabled: PropTypes.bool,
				options: PropTypes.shape({
					step: PropTypes.bool,
					goto: PropTypes.bool,
				}),
			}),
			zoom: PropTypes.bool,
			print: PropTypes.bool,
			download: PropTypes.bool,
			close: PropTypes.bool,
		}),
	}),
	defaultPageNumber: PropTypes.number,
	singlePage: PropTypes.bool,
	onClose: PropTypes.func,
	className: PropTypes.string,
	noScroll: PropTypes.bool,
};

PdfViewer.defaultProps = {
	useSvg: false,
	toolbar: null,
	defaultScale: 1.5,
	onClose: noop,
	singlePage: false,
	defaultPageNumber: 0,
	className: null,
	noScroll: false,
};

export default PdfViewer;
