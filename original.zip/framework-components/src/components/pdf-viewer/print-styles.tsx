// @ts-nocheck
import React from 'react';

function PrintStyles() {
	return (
		<style>
			{`
    @media print {
      html,
      body {
        background: transparent none !important;
        height: 100% !important;
        width: 100% !important;
        overflow: visible !important;
      }
    
      /* Hide anything that is not the print container */
      body > *:not(.ai-pdf-print-container) {
        display: none !important;
      }
    
      body > .ai-pdf-print-container .ai-pdf-print-document {
        display: block;
        height: 100%;
        width: 100%;
      }
    
      body > .ai-pdf-print-container .ai-pdf-print-page {
        position: relative;
        top: 0;
        left: 0;
        width: 1px;
        height: 1px;
        overflow: visible;
        page-break-after: always;
        page-break-inside: avoid;
      }
    
      body > .ai-pdf-print-container .ai-pdf-document-page-content {
        display: block;
      }
    
      body > .ai-pdf-print-container > .ai-pdf-print-dialog {
        display: none !important;
      }
    }
    
    `}
		</style>
	);
}

/*
function PrintStyles() {
  return (
      <style>
          {`
    .ai-pdf-viewer-print-bg {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .ai-pdf-print-container .ai-pdf-print-dialog {
      display: inline-block;
      padding: 15px;
      border-spacing: 4px;
      color: hsl(0, 0%, 85%);
      font-size: 12px;
      line-height: 14px;
      test: 0px;
      background-color: #337ab7;
      box-shadow: inset 1px 0 0 hsla(0, 0%, 100%, 0.08), inset 0 1px 1px hsla(0, 0%, 0%, 0.15), inset 0 -1px 0 hsla(0, 0%, 100%, 0.05), 0 1px 0 hsla(0, 0%, 0%, 0.15), 0 1px 1px hsla(0, 0%, 0%, 0.1);
      border: 1px solid hsla(0, 0%, 0%, 0.5);
      border-radius: 4px;
    }
    
    .ai-button {
      background-color: white;
      color: #337ab7;
    }

    body > .ai-pdf-print-container .ai-pdf-print-dialog-row {
      text-align: center;
    } 
    
    body > .ai-pdf-print-container .ai-pdf-print-dialog-row:not(:first-child) {
      padding-top: 10px;
    }
    
    body > .ai-pdf-print-container .ai-pdf-print-dialog-progress {
      width: 100%;
      height: 5px;
      border-radius: 5px;
      background-color: #878787;
      box-sizing: border-box;
      border: 1px solid black;
      overflow: hidden;
    }
    
    body > .ai-pdf-print-container .ai-pdf-print-dialog-progress-bar {
      height: 100%;
      width: 0;
      background-color: #474747;
    }
    
    body > .ai-pdf-print-container .ai-pdf-print-document {
      display: none;
    }
    
    body > .ai-pdf-print-container {
      height: 100%;
      width: 100%;
    }
    
    @media print {
      html,
      body {
        background: transparent none !important;
        height: 100% !important;
        width: 100% !important;
        overflow: visible !important;
      }
    
      body > *:not(.ai-pdf-print-container) {
        display: none !important;
      }
    
      body > .ai-pdf-print-container .ai-pdf-print-document {
        display: block;
        height: 100%;
        width: 100%;
      }
    
      body > .ai-pdf-print-container .ai-pdf-print-page {
        position: relative;
        top: 0;
        left: 0;
        width: 1px;
        height: 1px;
        overflow: visible;
        page-break-after: always;
        page-break-inside: avoid;
      }
    
      body > .ai-pdf-print-container .ai-pdf-document-page-content {
        display: block;
      }
    
      body > .ai-pdf-print-container > .ai-pdf-print-dialog {
        display: none !important;
      }
    }
    
    `}
      </style>
  );
}
*/

export default PrintStyles;
