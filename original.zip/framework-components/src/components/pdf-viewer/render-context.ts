// @ts-nocheck
import EventEmitter from 'eventemitter3';
import Promise from 'bluebird';
import ResizeSensor from 'css-element-queries/src/ResizeSensor';
import map from 'lodash-es/map';
import isNil from 'lodash-es/isNil';
import reduce from 'lodash-es/reduce';
import forEach from 'lodash-es/forEach';
import debounce from 'lodash-es/debounce';
import noop from 'lodash-es/noop';
import scrollIntoView from './common/scroll-into-view';
import PageRenderContext from './page-render-context';

const STATES = {
	LOADED: 'loaded',
	LOADING: 'loading',
	UNLOADED: 'unloaded',
};

class RenderContext {
	constructor(documentElement, pagesElement, scale, options) {
		this.emitter = new EventEmitter();

		this.status = {
			state: STATES.UNLOADED,
			progress: 0,
		};

		this.singlePage = !isNil(options) && options.singlePage === true;
		this.pagesElement = pagesElement;
		this.documentElement = documentElement;
		this.pageContexts = [];
		this.activePages = [];
		this.scale = scale;
		this.visible = false;
		this.useSvg = !isNil(options) && options.useSvg === true;
		this.resizable = !isNil(options) && options.resizable === true;
		this.alwaysRender = !isNil(options) && options.alwaysRender === true;

		this.update = this.update.bind(this);
		this.handleScroll = debounce(this.handleScroll.bind(this));
		this.handleResize = debounce(this.handleResize.bind(this), 100);

		this.visible = this.isVisible();

	}

	load(pages, currentPageNumber, pageRender) {
		this.status = {
			state: STATES.LOADING,
		};

		this.emitter.emit('status', this.status);

		if (this.singlePage) {
			throw new Error('Need to fix');
			// const pageRef = this.singlePageSetup(pages, currentPageNumber);

			// return [
			//   pageRender(pageRef, currentPageNumber),
			// ];
		}

		let loadedCount = 0;

		const registrar = this.multiPageSetup(currentPageNumber, () => {
			loadedCount += 1;

			this.emitter.emit('progress', loadedCount);
		});

		const pageElements = map(pages, (page, pageNumber) => {
			const pageRef = registrar.registerPage(page, pageNumber);

			return pageRender(pageRef, pageNumber);
		});

		registrar.finish().then(() => {
			this.status = {
				state: STATES.LOADED,
			};

			if (this.resizable) {
				this.resizeSensor = new ResizeSensor(
					this.pagesElement,
					this.handleResize,
				);
			}

			this.documentElement.addEventListener('scroll', this.handleScroll);

			this.emitter.emit('status', this.status);
		});

		return pageElements;
	}

	unload() {
		if (!isNil(this.resizeSensor)) {
			this.resizeSensor.detach();

			this.resizeSensor = null;
		}

		forEach(this.pageContexts, (pageContext) => pageContext.dispose());

		this.status = {
			state: STATES.LOADED,
			progress: 0,
		};

		this.emitter.emit('status', this.status);
	}

	isVisible() {
		if (isNil(this.pagesElement)) {
			return false;
		}

		return (
			this.pagesElement.offsetHeight > 0 &&
			this.pagesElement.offsetWidth > 0
		);
	}

	handleResize() {
		this.emitter.emit('resize');

		if (this.isVisible()) {
			if (!this.visible) {
				this.visible = true;

				this.emitter.emit('visible', this.visible);
			}
		} else if (this.visible) {
			this.visible = false;

			this.emitter.emit('visible', this.visible);
		}

		if (this.scale === 'fit-to-screen') {
			if (this.singlePage) {
				this.activePages[0].preRender(this.scale).render();
			} else {
				this.update();
			}
		} else {
			this.update();
		}
	}

	handleScroll() {
		this.update();
	}

	update() {
		if (this.pageContexts.length <= 0 || this.singlePage) {
			return;
		}

		if (!isNil(this.resizeSensor)) {
			this.resizeSensor.detach();
			this.resizeSensor = null;
		}

		const proms = map(this.pageContexts, (pageContext) => 
			pageContext.update(this.scale)
		);

		Promise.all(proms).then(() => {
			const visibility = reduce(
				this.pageContexts,
				(visibleMeta, pageContext) => {
					if (pageContext.visibility <= 0) {
						return visibleMeta;
					}
	
					if (isNil(visibleMeta.activePageContext)) {
						// Since nothing is active then this is first we have seen.
						// eslint-disable-next-line no-param-reassign
						visibleMeta.activePageContext = pageContext;
						// eslint-disable-next-line no-param-reassign
						visibleMeta.firstVisibleContext = pageContext;
					} else if (
						visibleMeta.activePageContext.visibility < pageContext.visibility &&
						visibleMeta.activePageContext.visibility < 33
					) {
						// eslint-disable-next-line no-param-reassign
						visibleMeta.activePageContext = pageContext;
					}
	
					// eslint-disable-next-line no-param-reassign
					visibleMeta.lastVisibleContext = pageContext;
	
					return visibleMeta;
				},
				{
					proms: [],
					activePageContext: null,
					firstVisibleContext: null,
					lastVisibleContext: null,
				},
			);

			if (this.resizable) {
				this.resizeSensor = new ResizeSensor(
					this.pagesElement,
					this.handleResize,
				);
			}
	
			if (isNil(visibility.activePageContext)) {
				if (!isNil(this.activePageContext)) {
					this.emitter.emit('active', null);
				}
			} else if (visibility.activePageContext !== this.activePageContext) {
				this.activePageContext = visibility.activePageContext;
	
				this.emitter.emit('active', this.activePageContext.pageNumber);
			}
		});
	}

	// singlePageSetup(pages, initialPageNumber) {
	//   this.status = 'initializing';

	//   const pageProm = new Promise(noop);

	//   pageProm.then((pageElement) => {
	//     this.pageContexts = map(pages, (page, pageNumber) => {
	//       const pageContext = new PageRenderContext({
	//         page,
	//         pageNumber,
	//         pageElement,
	//         documentElement: this.documentElement,
	//         scale: this.scale,
	//       });

	//       return pageContext;
	//     });

	//     if (this.visible) {
	//       this.scrollTo(initialPageNumber);
	//     } else {
	//       const onVisible = (visible) => {
	//         if (visible) {
	//           this.emitter.removeListener('visible', onVisible);
	//         }

	//         this.scrollTo(initialPageNumber);
	//       };

	//       this.emitter.on('visible', onVisible);
	//     }

	//     this.status = 'idle';
	//   });

	//   return pageProm._resolveCallback.bind(pageProm);
	// }

	multiPageSetup(initialPageNumber, onLoaded) {
		this.singlePage = false;

		const documentProms = [];

		const pageContexts = [];
		this.pageContexts = pageContexts;

		const registerPage = (page, pageNumber) => {
			const pageProm = new Promise(noop);

			const pageContextProm = pageProm.then((pageElement) => {
				pageContexts[pageNumber] = new PageRenderContext({
					page,
					pageNumber,
					pageElement,
					pagesElement: this.pagesElement,
					documentElement: this.documentElement,
					scale: this.scale,
					alwaysRender: this.alwaysRender,
				});

				return pageContexts[pageNumber].load().then(() => {
					onLoaded(pageContexts[pageNumber]);
				});
			});

			documentProms.push(pageContextProm);

			// eslint-disable-next-line no-underscore-dangle
			return pageProm._resolveCallback.bind(pageProm);
		};

		const finish = () =>
			Promise.all(documentProms).then(() => {
				const onVisible = (visible) => {
					if (visible) {
						this.emitter.removeListener('visible', onVisible);
					}

					this.scrollTo(initialPageNumber);
				};

				this.emitter.on('visible', onVisible);
			});

		return {
			registerPage,
			finish,
		};
	}

	on(eventId, callback) {
		this.emitter.on(eventId, callback);

		return () => {
			this.emitter.removeListener(eventId, callback);
		};
	}

	removeListener(eventId, callback) {
		this.emitter.removeListener(eventId, callback);
	}

	setScale(scale) {
		if (this.scale === scale) {
			return;
		}

		this.scale = scale;

		if (this.singlePage) {
			this.activePages[0].preRender(scale).render();
		} else {
			this.update();
		}
	}

	scrollTo(pageNumber) {
		if (this.visible) {
			if (this.singlePage) {
				const pageContext = this.pageContexts[pageNumber];

				pageContext.preRender(this.scale).render();

				this.pagesElement.scrollTop = 0;

				this.activePages = [pageContext];
			} else {
				const pageContext = this.pageContexts[pageNumber];

				scrollIntoView(pageContext.pageElement);
			}
		}
	}

	dispose() {
		this.unload();

		this.emitter.removeAllListeners();

		this.documentElement.removeEventListener('scroll', this.handleScroll);
		this.pagesElement = null;
		this.documentElement = null;

		if (!isNil(this.resizeSensor)) {
			this.resizeSensor.reset();
			this.resizeSensor.detach(this.pagesElement);

			this.resizeSensor = null;
		}
	}
}

RenderContext.STATES = STATES;

export default RenderContext;
