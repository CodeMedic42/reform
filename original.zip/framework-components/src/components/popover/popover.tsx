// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import noop from 'lodash-es/noop';
import isNil from 'lodash-es/isNil';
import DropDown from '../drop-down';
import Text from '../typography/text';
import applyAnchorBinding from '../drop-down/anchor-binding';

class Popover extends PureComponent {
	constructor(props) {
		super(props);

		const { anchor } = props;

		this.boundAnchor = anchor.isAnchorBinding
			? anchor
			: applyAnchorBinding(anchor);
	}

	render() {
		const {
			id,
			className,
			anchorProps,
			children,
			onAnchorClick,
			openOnClick,
			openOnFocus,
			openOnHover,
			heading,
			closeTrayOnClick,
			maxDrawerWidth,
			dark,
			dropPositions,
			disabled,
		} = this.props;

		const headingElement =
			!isNil(heading) && heading.length > 0 ? (
				<div className="ai-popover-heading">
					<Text size="lg" weight="bold">
						{heading}
					</Text>
				</div>
			) : null;

		return (
			<DropDown
				id={id}
				className={classnames('ai-popover', className, {
					'theme-dark': dark,
				})}
				trayClassName={classnames('ai-popover-tray', {
					'theme-dark': dark,
				})}
				Anchor={this.boundAnchor}
				anchorProps={anchorProps}
				onAnchorClick={onAnchorClick}
				disabled={disabled}
				dropPositions={dropPositions}
				openOnHover={openOnHover}
				openOnFocus={openOnFocus}
				openOnClick={openOnClick}
				horizontallyCenter
				enableTail
				maxDrawerWidth={
					!isNil(maxDrawerWidth)
						? maxDrawerWidth
						: Popover.defaultProps.maxDrawerWidth
				}
				closeTrayOnClick={closeTrayOnClick}
			>
				{headingElement}
				<Text size="md">{children}</Text>
			</DropDown>
		);
	}
}

const dropPositionTypes = PropTypes.oneOf(['top', 'bottom', 'left', 'right']);

Popover.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	anchor: PropTypes.elementType.isRequired,
	// eslint-disable-next-line react/forbid-prop-types
	anchorProps: PropTypes.object.isRequired,
	children: PropTypes.node.isRequired,
	onAnchorClick: PropTypes.func,
	openOnClick: PropTypes.bool,
	openOnFocus: PropTypes.bool,
	openOnHover: PropTypes.bool,
	heading: PropTypes.string,
	closeTrayOnClick: PropTypes.bool,
	maxDrawerWidth: PropTypes.number,
	dark: PropTypes.bool,
	dropPositions: PropTypes.arrayOf(dropPositionTypes),
	disabled: PropTypes.bool,
};

Popover.defaultProps = {
	id: null,
	className: null,
	onAnchorClick: noop,
	openOnClick: true,
	openOnFocus: false,
	openOnHover: false,
	heading: null,
	closeTrayOnClick: false,
	maxDrawerWidth: 560,
	dark: false,
	dropPositions: ['top', 'bottom'],
	disabled: false,
};

export default Popover;
