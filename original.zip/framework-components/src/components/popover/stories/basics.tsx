// @ts-nocheck
import React from 'react';
import isNil from 'lodash-es/isNil';
import Popover from '..';
import Scope from '../../../../.storybook/components/scope';
import { Text } from '../../typography';
import Link from '../../link';
import Button from '../../button';

function renderPopover(options = {}, content = null) {
	const children = !isNil(content) ? (
		content
	) : (
		<Text>This is a sample popover</Text>
	);

	return (
		<div className="gutter-horizontal">
			<Popover
				anchor={Link}
				anchorProps={{
					children: 'Text',
					asButton: true,
				}}
				heading="This is the heading"
				{...options}
			>
				{children}
			</Popover>
		</div>
	);
}

function example() {
	return (
		<>
			<Scope title="Default Options ( Light style, open on click )">
				{renderPopover()}
			</Scope>
			<Scope title="Dark Popover">{renderPopover({ dark: true })}</Scope>
			<Scope title="Right Drop Position">
				{renderPopover({ dropPositions: ['right'] })}
			</Scope>
			<Scope title="Open only on hover">
				{renderPopover({ openOnHover: true, openOnClick: false })}
			</Scope>
			<Scope title="Open only on focus">
				{renderPopover({ openOnFocus: true, openOnClick: false })}
			</Scope>
			<Scope title="With Clickable inside">
				{renderPopover(
					null,
					<Button
						variant="fill"
						color="primary"
						// eslint-disable-next-line no-console
						onClick={() => console.log('So it has been made')}
					>
						Make it so
					</Button>,
				)}
			</Scope>
			<Scope title="With Clickable inside and close on click">
				{renderPopover(
					{
						closeTrayOnClick: true,
					},
					<Button
						variant="fill"
						color="primary"
						// eslint-disable-next-line no-console
						onClick={() => console.log('So it has been made')}
					>
						Make it so
					</Button>,
				)}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basics',
};

export default example;
