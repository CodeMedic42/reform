// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import wrappedContext from '../../common/create-context/wrapped-context';

const radioContext = React.createContext();

export function ApplyConsumer(Component) {
	return wrappedContext(radioContext, Component, 'radioContext');
}

export function Provider(props) {
	const { children, ...rest } = props;

	return (
		<radioContext.Provider value={rest}>{children}</radioContext.Provider>
	);
}

Provider.propTypes = {
	// eslint-disable-next-line react/forbid-prop-types
	children: PropTypes.any,
	value: PropTypes.string,
	groupId: PropTypes.string.isRequired,
	onChange: PropTypes.func.isRequired,
	disabled: PropTypes.bool,
};

Provider.defaultProps = {
	children: null,
	value: null,
	disabled: false,
};
