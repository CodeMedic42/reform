// @ts-nocheck
import RadioInputGroup from '.';

export default {
	title: 'Inputs/Radio Input Group',
	component: RadioInputGroup,
};

export { default as Basic } from './stories/basic';
export { default as Sizes } from './stories/sizes';
export { default as Colors } from './stories/colors';
