// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import shortid from 'shortid';
import { Provider } from './radio-input-group-context';

class RadioInputGroup extends PureComponent {
	constructor(props) {
		super(props);

		this.handleChange = this.handleChange.bind(this);

		this.groupId = shortid();
	}

	handleChange(value) {
		const { onChange, onChangeMeta } = this.props;

		if (isNil(onChange)) {
			return;
		}

		onChange(value, {
			meta: onChangeMeta,
		});
	}

	render() {
		const { id, className, size, color, disabled, children, value } =
			this.props;

		const sizeClass = !isNil(size) ? `size-${size}` : 'size-md';
		const colorClass = !isNil(color) ? `color-${color}` : null;

		return (
			<div
				id={id}
				className={classnames(
					'ai-radio-input-group',
					sizeClass,
					colorClass,
					className,
					{
						disabled,
					},
				)}
			>
				<Provider
					value={value}
					onChange={this.handleChange}
					groupId={this.groupId}
					disabled={disabled}
				>
					{children}
				</Provider>
			</div>
		);
	}
}

RadioInputGroup.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	value: PropTypes.string,
	size: PropTypes.oneOf(['sm', 'md', 'lg']),
	color: PropTypes.oneOf(['primary', 'secondary']),
	disabled: PropTypes.bool,
	onChange: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onChangeMeta: PropTypes.any,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

RadioInputGroup.defaultProps = {
	id: null,
	className: null,
	value: false,
	size: 'md',
	onChange: null,
	onChangeMeta: null,
	color: null,
	disabled: false,
	children: null,
};

export default RadioInputGroup;
