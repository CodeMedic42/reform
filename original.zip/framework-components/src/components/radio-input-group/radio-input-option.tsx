/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import shortid from 'shortid';
import isNil from 'lodash-es/isNil';
import { ApplyConsumer } from './radio-input-group-context';

function handleMouseDown(event) {
	event.preventDefault();
}

class RadioInputOption extends PureComponent {
	constructor(props) {
		super(props);

		this.handleClick = this.handleClick.bind(this);

		this.id = shortid();
	}

	handleClick() {
		const { radioContext, value } = this.props;

		const { onChange, value: selectedValue } = radioContext;

		if (selectedValue === value) {
			return;
		}

		onChange(value);
	}

	render() {
		const { className, label, radioContext, value } = this.props;

		let { id } = this.props;

		id = !isNil(id) ? id : this.id;

		const { value: selectedValue, groupId, disabled } = radioContext;

		const inputId = `${id}-input`;

		return (
			<label
				id={`${id}-label`}
				className={classnames('ai-radio-input-option', className, {
					disabled,
				})}
				htmlFor={inputId}
				onMouseDown={handleMouseDown}
				onClick={this.handleClick}
			>
				<input
					id={inputId}
					type="radio"
					name={groupId}
					value={value}
					disabled={disabled}
					checked={value === selectedValue}
					readOnly
				/>
				<span className="indicator" />
				<span>{label}</span>
			</label>
		);
	}
}

RadioInputOption.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	value: PropTypes.string,
	label: PropTypes.string,
	disabled: PropTypes.bool,
	radioContext: PropTypes.shape({
		value: PropTypes.string,
		groupId: PropTypes.string.isRequired,
		onChange: PropTypes.func.isRequired,
		disabled: PropTypes.bool,
	}).isRequired,
};

RadioInputOption.defaultProps = {
	id: null,
	className: null,
	value: false,
	disabled: false,
	label: null,
};

export default ApplyConsumer(RadioInputOption);
