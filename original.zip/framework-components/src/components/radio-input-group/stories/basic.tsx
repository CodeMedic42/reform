// @ts-nocheck
import React, { useState } from 'react';
import RadioInputGroup, { RadioInputOption } from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [value, setValue] = useState(null);

	return (
		<Scope title="Defaults">
			<RadioInputGroup value={value} onChange={setValue}>
				<RadioInputOption label="OptionA" value="optionA" />
				<RadioInputOption label="OptionB" value="optionB" />
				<RadioInputOption label="OptionC" value="optionC" />
			</RadioInputGroup>
		</Scope>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
