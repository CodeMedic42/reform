// @ts-nocheck
import React, { useState } from 'react';
import RadioInputGroup, { RadioInputOption } from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [value, setValue] = useState(null);

	return (
		<>
			<Scope title="Primary">
				<RadioInputGroup
					value={value}
					color="primary"
					onChange={setValue}
				>
					<RadioInputOption label="OptionA" value="optionA" />
					<RadioInputOption label="OptionB" value="optionB" />
					<RadioInputOption label="OptionC" value="optionC" />
				</RadioInputGroup>
			</Scope>
			<Scope title="Secondary">
				<RadioInputGroup
					value={value}
					color="secondary"
					onChange={setValue}
				>
					<RadioInputOption label="OptionA" value="optionA" />
					<RadioInputOption label="OptionB" value="optionB" />
					<RadioInputOption label="OptionC" value="optionC" />
				</RadioInputGroup>
			</Scope>
			<Scope title="Primary - Disabled">
				<RadioInputGroup
					value={value}
					color="primary"
					disabled
					onChange={setValue}
				>
					<RadioInputOption label="OptionA" value="optionA" />
					<RadioInputOption label="OptionB" value="optionB" />
					<RadioInputOption label="OptionC" value="optionC" />
				</RadioInputGroup>
			</Scope>
			<Scope title="Secondary - Disabled">
				<RadioInputGroup
					value={value}
					color="secondary"
					disabled
					onChange={setValue}
				>
					<RadioInputOption label="OptionA" value="optionA" />
					<RadioInputOption label="OptionB" value="optionB" />
					<RadioInputOption label="OptionC" value="optionC" />
				</RadioInputGroup>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Colors',
};

export default example;
