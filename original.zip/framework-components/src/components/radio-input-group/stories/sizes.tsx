// @ts-nocheck
import React, { useState } from 'react';
import RadioInputGroup, { RadioInputOption } from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [value, setValue] = useState(null);

	return (
		<>
			<Scope title="Small">
				<RadioInputGroup value={value} size="sm" onChange={setValue}>
					<RadioInputOption label="OptionA" value="optionA" />
					<RadioInputOption label="OptionB" value="optionB" />
					<RadioInputOption label="OptionC" value="optionC" />
				</RadioInputGroup>
			</Scope>
			<Scope title="Medium(Default)">
				<RadioInputGroup value={value} size="md" onChange={setValue}>
					<RadioInputOption label="OptionA" value="optionA" />
					<RadioInputOption label="OptionB" value="optionB" />
					<RadioInputOption label="OptionC" value="optionC" />
				</RadioInputGroup>
			</Scope>
			<Scope title="Large">
				<RadioInputGroup value={value} size="lg" onChange={setValue}>
					<RadioInputOption label="OptionA" value="optionA" />
					<RadioInputOption label="OptionB" value="optionB" />
					<RadioInputOption label="OptionC" value="optionC" />
				</RadioInputGroup>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Sizes',
};

export default example;
