// @ts-nocheck
import RemovableChip from './removable-chip';

export default RemovableChip;
