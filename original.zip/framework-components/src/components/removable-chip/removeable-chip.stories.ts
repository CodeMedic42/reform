// @ts-nocheck
import RemovableChip from '.';

export default {
	title: 'Labeling/RemovableChip',
	component: RemovableChip,
};

export { default as clearable } from './stories/clearable';
