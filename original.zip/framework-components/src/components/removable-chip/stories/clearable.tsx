/* eslint-disable no-alert */
// @ts-nocheck
import React, { Fragment } from 'react';
import map from 'lodash-es/map';
import RemovableChip from '../removable-chip';
import Scope from '../../../../.storybook/components/scope';
import {
	paletteColorOrder,
	schemeColorOrder,
} from '../../../common/color-list';
import { Row, Column } from '../../grid';

const sizes = ['xs', 'sm', 'md', 'lg', 'xl'];
const variants = ['rectangle', 'pill'];
const shades = ['light', 'dark'];
const clearTypes = ['normal', 'inverse'];

function handleClick() {
	alert('Clicked');
}

function example() {
	return (
		<>
			{map(clearTypes, (clearType) => (
				<Fragment key={clearType}>
					{map(shades, (shade) => (
						<Scope
							key={shade}
							title={`Palette Colors Shade: ${shade}, Clear Type: ${clearType}`}
						>
							{map(sizes, (size) => (
								<Fragment key={size}>
									{map(variants, (variant) => (
										<Row key={variant} gutter>
											{map(paletteColorOrder, (color) => (
												<Column
													key={color}
													width="content"
												>
													<RemovableChip
														color={color}
														size={size}
														variant={variant}
														shade={shade}
														clearType={clearType}
														onClear={handleClick}
													>
														Clearable
													</RemovableChip>
												</Column>
											))}
										</Row>
									))}
								</Fragment>
							))}
						</Scope>
					))}
				</Fragment>
			))}
			{map(clearTypes, (clearType) => (
				<Scope
					key={clearType}
					title={`Schema Colors, Clear Type: ${clearType}`}
				>
					{map(sizes, (size) => (
						<Fragment key={size}>
							{map(variants, (variant) => (
								<Row key={variant} gutter>
									{map(schemeColorOrder, (color) => (
										<Column key={color} width="content">
											<RemovableChip
												color={color}
												size={size}
												variant={variant}
												clearType={clearType}
												onClear={handleClick}
											>
												Clearable
											</RemovableChip>
										</Column>
									))}
								</Row>
							))}
						</Fragment>
					))}
				</Scope>
			))}
		</>
	);
}

example.story = {
	name: 'Clearable',
};

export default example;
