// @ts-nocheck
import ResolutionBinding from './resolution-binding';

export default ResolutionBinding;
