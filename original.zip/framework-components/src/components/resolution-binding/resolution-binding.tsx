// @ts-nocheck
import { PureComponent } from 'react';
import PropTypes from 'prop-types';
import isEmpty from 'lodash-es/isEmpty';
import isNil from 'lodash-es/isNil';

const mediumMin = 600;
const largeMax = 992;
const exLargeMax = 1200;
const exLarge2Min = 1800;

function determineMount(enabled, breakPoints) {
	if (!enabled) {
		return false;
	}

	if (breakPoints === true) {
		return true;
	}

	if (isEmpty(breakPoints)) {
		return false;
	}

	const [sm, md, lg, xl, xl2] = breakPoints;

	const width = window.innerWidth;

	let mount = sm === true;

	if (mediumMin < width && !isNil(md)) {
		mount = md;
	}

	if (largeMax < width && !isNil(lg)) {
		mount = lg;
	}

	if (exLargeMax < width && !isNil(xl)) {
		mount = xl;
	}

	if (exLarge2Min < width && !isNil(xl2)) {
		mount = xl2;
	}

	return mount;
}

// This component allows the control of what to do at different resolution break points.
// Normally you would use a media query for this. However if you need to do something
// which can only be done through javascript then this makes that easier.
// Just specify which break points you want to mount a component at and this
// will figure that out for you.
// For example if you want to mount a component at large and extra large sizes you would do this
/*
<ResolutionBinding enabled breakPoints={[null, null, true, null, false]}>
    {({ mount }) => {
        return mount ? <span>Now you see me</span> : null
    }}
</ResolutionBinding>
*/
// The default for breakPoints is false so the first two null is to NOT mount as small and medium sizes.
// The true will set mount to true at large and the next null will maintain that true into extra large.
// The final false turns it back off at extra extra large.
// I do not expect this to be used unless ABSOLUTELY necessary.

class ResolutionBinding extends PureComponent {
	constructor(props) {
		super(props);

		this.handleResize = this.handleResize.bind(this);

		this.state = {
			mount: false,
		};
	}

	static getDerivedStateFromProps(nextProps, currentState) {
		const { enabled, breakPoints } = nextProps;

		const { mount: isMounted } = currentState;

		const mount = determineMount(enabled, breakPoints);

		if (isMounted !== mount) {
			return {
				mount,
			};
		}

		return null;
	}

	componentDidMount() {
		window.addEventListener('resize', this.handleResize);
	}

	componentWillUnmount() {
		window.addEventListener('resize', this.handleResize);
	}

	handleResize() {
		const { enabled, breakPoints } = this.props;

		const { mount: isMounted } = this.state;

		const mount = determineMount(enabled, breakPoints);

		if (isMounted !== mount) {
			this.setState({
				mount,
			});
		}
	}

	render() {
		const { children } = this.props;

		const { mount } = this.state;

		return children({ mount });
	}
}

ResolutionBinding.propTypes = {
	// eslint-disable-next-line react/forbid-prop-types
	breakPoints: PropTypes.any,
	enabled: PropTypes.bool,
	children: PropTypes.func.isRequired,
};

ResolutionBinding.defaultProps = {
	breakPoints: null,
	enabled: false,
};

export default ResolutionBinding;
