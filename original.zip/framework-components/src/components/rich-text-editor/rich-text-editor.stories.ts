// @ts-nocheck
import RichTextEditor from '.';

export default {
	title: 'Miscellaneous/Rich Text Editor',
	component: RichTextEditor,
};

export { default as basic } from './stories/basic';
