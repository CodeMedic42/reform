// @ts-nocheck
import React from 'react';
import ReactQuill from 'react-quill';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import noop from 'lodash-es/noop';

// Based on Quill and react-quill
// https://quilljs.com/docs/quickstart/
// https://github.com/zenoamaro/react-quill
class RichTextEditor extends React.Component {
	constructor(props) {
		super(props);

		this.inputRef = React.createRef();
		this.focus = this.focus.bind(this);
		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(value) {
		const { onChange } = this.props;

		onChange(value);
	}

	focus() {
		const { current: inputElement } = this.inputRef;

		if (isNil(inputElement)) {
			// eslint-disable-next-line no-console
			console.warn('Attempting to focus on an unmounted component');

			return;
		}

		inputElement.focus();
	}

	render() {
		const {
			id,
			className,
			toolbar,
			formats,
			value,
			disabled,
			hidden,
			placeholder,
			onFocus,
			onBlur,
		} = this.props;

		const modules = {};
		modules.toolbar = toolbar || undefined;

		return (
			<div
				className={classnames('ai-rich-text-editor', className, {
					hidden,
				})}
			>
				<ReactQuill
					value={value}
					ref={this.inputRef}
					id={id}
					theme="snow"
					onChange={this.handleChange}
					modules={modules}
					formats={formats}
					readOnly={disabled}
					placeholder={placeholder}
					onFocus={onFocus}
					onBlur={onBlur}
					preserveWhitespace
					bounds=".ai-rich-text-editor"
				/>
			</div>
		);
	}
}

RichTextEditor.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	// eslint-disable-next-line react/forbid-prop-types
	toolbar: PropTypes.arrayOf(PropTypes.array),
	formats: PropTypes.arrayOf(PropTypes.string),
	value: PropTypes.string,
	placeholder: PropTypes.string,
	onChange: PropTypes.func.isRequired,
	disabled: PropTypes.bool,
	hidden: PropTypes.bool,
	onFocus: PropTypes.func,
	onBlur: PropTypes.func,
};

RichTextEditor.defaultProps = {
	id: null,
	className: null,
	toolbar: [
		[{ header: [1, 2, 3, 4, 5, 6, false] }],
		['bold', 'italic', 'underline', 'strike'],
		[{ list: 'ordered' }, { list: 'bullet' }, 'blockquote'],
		['link'],
		['clean'],
	],
	formats: [
		'bold',
		'italic',
		'strike',
		'underline',
		'header',
		'list',
		'blockquote',
		'link',
	],
	value: undefined,
	placeholder: null,
	disabled: false,
	hidden: false,
	onFocus: noop,
	onBlur: noop,
};
export default RichTextEditor;
