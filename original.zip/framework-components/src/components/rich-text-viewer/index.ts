// @ts-nocheck
import RichTextViewer from './rich-text-viewer';

export default RichTextViewer;
