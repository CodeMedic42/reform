// @ts-nocheck
import RichTextEditor from '.';

export default {
	title: 'Miscellaneous/Rich Text Viewer',
	component: RichTextEditor,
};

export { default as basic } from './stories/basic';
