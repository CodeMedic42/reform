// @ts-nocheck
import React, { memo, useRef, useCallback, useEffect } from 'react';
import PropTypes from 'prop-types';
import isNil from 'lodash-es/isNil';
import startsWith from 'lodash-es/startsWith';
import debounce from 'lodash-es/debounce';

function updateIframe(iframe, content) {
	let validContent = content;

	if (!startsWith(content, '<')) {
		validContent = `<p>${content}</p>`;
	}

	const fullHtml = `
<html>
<head>
<link
  rel="stylesheet"
  href="https://unpkg.com/react-quill@1.3.3/dist/quill.snow.css"
/>
<style type="text/css">
@import 'https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400';
@import 'https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@600';
@import 'https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@700';

* { 
    font-family: "Source Sans Pro", serif;
    overflow: hidden;
}

.ql-editor {
	height: initial;
	padding: 0;
}
</style>
</head>
<body style="margin:0;display:inline-block" class="ql-snow"><div class="ql-editor">${validContent}</div>
</body>
</html>
`;

	if (isNil(iframe)) {
		return;
	}

	iframe.contentWindow.document.open();
	iframe.contentWindow.document.write(fullHtml);

	iframe.contentWindow.document.close();
}

function RichTextViewer(props) {
	const { id, content } = props;

	const iFrameRef = useRef();

	const resizeIFrame = useCallback(
		debounce(() => {
			const actualIFrame = iFrameRef.current;

			if (!isNil(actualIFrame)) {
				actualIFrame.style.height = `${actualIFrame.contentWindow.document.body.offsetHeight}px`;
			}
		}, 10),
	);

	useEffect(() => {
		window.addEventListener('resize', resizeIFrame);

		iFrameRef.current.addEventListener('load', () => {
			resizeIFrame();
		});

		return () => {
			window.removeEventListener('resize', resizeIFrame);
		};
	}, []);

	useEffect(() => {
		updateIframe(iFrameRef.current, content);
	}, [content]);

	return (
		<iframe
			id={id}
			className="ai-rich-text-viewer"
			title={id}
			sandbox="allow-same-origin"
			ref={iFrameRef}
			frameBorder={0}
		/>
	);
}

RichTextViewer.propTypes = {
	id: PropTypes.string,
	content: PropTypes.string,
};

RichTextViewer.defaultProps = {
	id: null,
	content: null,
};

export default memo(RichTextViewer);
