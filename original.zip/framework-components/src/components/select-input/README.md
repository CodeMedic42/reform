# SelectInput

This component provides an input which allows the user to select a single item from a list.

This component utilizes the [Select](../select/README.md) component and just provides the appropriate anchor. The SelectInput component expands on the same props from the Select component.

## How to use

```jsx
<SelectInput />
```

## Props

| Property | Type               | Required | Default | Description            |
| -------- | ------------------ | -------- | ------- | ---------------------- |
| value    | String \|\| Number | No       | null    | The selected value(s). |
