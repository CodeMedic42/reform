// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import { faAngleUp } from '@audacious/icons/regular/faAngleUp';
import { faAngleDown } from '@audacious/icons/regular/faAngleDown';
import { faXmarkLarge } from '@audacious/icons/solid/faXmarkLarge';
import IconBox from '../icon-box';
import { Text } from '../typography';
import IconButton from '../icon-button';
import applyAnchorBinding from '../drop-down/anchor-binding';
import changeSize from '../../util/change-size';

class SelectAnchor extends PureComponent {
	constructor(props) {
		super(props);

		this.handleClear = this.handleClear.bind(this);
		this.handleMouseDown = this.handleMouseDown.bind(this);
	}

	handleClear({ event }) {
		const { onClear, onClearMeta } = this.props;

		if (isNil(onClear)) {
			return;
		}

		event.preventDefault();

		onClear({
			event,
			meta: onClearMeta,
		});
	}

	// eslint-disable-next-line class-methods-use-this
	handleMouseDown(event) {
		event.preventDefault();
	}

	render() {
		const {
			id,
			disabled,
			'aria-labelledby': labelledBy,
			'aria-describedby': describedBy,
			title,
			open,
			value,
			nullable,
			size,
			placeholder,
			'aria-label': ariaLabel,
			listBoxId,
		} = this.props;

		let selectedText = value;

		if (isNil(selectedText) || selectedText.length <= 0) {
			if (!isNil(placeholder) && placeholder.length > 0) {
				selectedText = placeholder;
			} else {
				selectedText = '';
			}
		}

		const clearButton =
			nullable && !isNil(value) && value.length > 0 ? (
				<IconButton
					className="clear"
					tabIndex="-1"
					icon={faXmarkLarge}
					onClick={this.handleClear}
					onMouseDown={this.handleMouseDown}
					size={changeSize(size, 1)}
					disabled={disabled}
				/>
			) : null;

		return (
			<div
				className={classnames(
					'select-anchor',
					'single-select-anchor',
					`size-${size}`,
				)}
			>
				<div
					className={classnames('anchor-boundary', {
						focus: open,
					})}
				>
					<button
						id={id}
						className={classnames(
							'anchor-control',
							'button-anchor',
							{
								nullable,
								focus: open,
								'has-value': !isNil(value) && value.length > 0,
							},
						)}
						role="combobox"
						aria-controls={listBoxId}
						aria-expanded={open}
						aria-haspopup="listbox"
						type="button"
						aria-describedby={describedBy}
						aria-labelledby={labelledBy}
						title={title}
						disabled={disabled}
						aria-label={ariaLabel}
						value={!isNil(value) && value.length > 0 ? value : null}
					/>
					<div className="anchor-content">
						<Text
							className="anchor-selected-item"
							size={size === 'lg' ? 'xl' : 'lg'}
						>
							{selectedText}
						</Text>
						<IconBox
							className="arrow"
							icon={open ? faAngleUp : faAngleDown}
							size={changeSize(size, 1)}
						/>
						{clearButton}
					</div>
				</div>
			</div>
		);
	}
}

SelectAnchor.propTypes = {
	id: PropTypes.string,
	disabled: PropTypes.bool,
	'aria-labelledby': PropTypes.string,
	'aria-describedby': PropTypes.string,
	title: PropTypes.string,
	open: PropTypes.bool.isRequired,
	// eslint-disable-next-line react/forbid-prop-types
	value: PropTypes.any,
	nullable: PropTypes.bool.isRequired,
	placeholder: PropTypes.string,
	'aria-label': PropTypes.string,
	size: PropTypes.oneOf(['sm', 'md', 'lg']),
	onClear: PropTypes.func,
	onClearMeta: PropTypes.func,
	listBoxId: PropTypes.string.isRequired,
};

SelectAnchor.defaultProps = {
	size: null,
	id: null,
	disabled: false,
	'aria-labelledby': null,
	'aria-describedby': null,
	title: null,
	value: null,
	placeholder: null,
	'aria-label': null,
	onClear: null,
	onClearMeta: null,
};

export default applyAnchorBinding(SelectAnchor, {
	focusSelector: '.button-anchor',
});
