// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { shouldUpdate } from '../../common/select-utls';
import Select, {
	propTypes as selectPropTypes,
	defaultProps as selectDefaultProps,
} from '../select';
import SelectAnchor from './select-anchor';

class SelectInput extends React.Component {
	shouldComponentUpdate(nextProps) {
		return shouldUpdate(nextProps, this.props);
	}

	render() {
		const { className, ...rest } = this.props;

		return (
			<Select
				{...rest}
				className={classnames('ai-select-input', className)}
				Anchor={SelectAnchor}
				useFilter
			/>
		);
	}
}

SelectInput.propTypes = {
	...selectPropTypes,
	value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

SelectInput.defaultProps = {
	...selectDefaultProps,
	value: null,
};

export default SelectInput;
