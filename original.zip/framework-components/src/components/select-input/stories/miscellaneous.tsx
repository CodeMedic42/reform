// @ts-nocheck
import React from 'react';
import SelectInput from '..';
import Scope from '../../../../.storybook/components/scope';
import { textOnly } from '../../../common/storybook/options-data';

function example() {
	return (
		<>
			<Scope title="Placeholder">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						placeholder="Placeholder"
						value={state.value}
						options={textOnly}
						onChange={(value) => setState({ value })}
					/>
				)}
			</Scope>
			<Scope title="Disabled">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={textOnly}
						disabled
						onChange={(value) => setState({ value })}
					/>
				)}
			</Scope>
			<Scope title="Hidden">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={textOnly}
						hidden
						onChange={(value) => setState({ value })}
					/>
				)}
			</Scope>
			<Scope title="Not Nullable">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={textOnly}
						onChange={(value) => setState({ value })}
						nullable={false}
					/>
				)}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Miscellaneous',
};

export default example;
