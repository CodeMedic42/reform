// @ts-nocheck
import React from 'react';
import Promise from 'bluebird';
import toLower from 'lodash-es/toLower';
import filter from 'lodash-es/filter';
import debounce from 'lodash-es/debounce';
import get from 'lodash-es/get';
import startsWith from 'lodash-es/startsWith';
import isNil from 'lodash-es/isNil';
import SelectInput from '..';
import Scope from '../../../../.storybook/components/scope';
import {
	textOnly,
	options,
	abbreviated,
	lookUp,
} from '../../../common/storybook/options-data';

const serviceCall = debounce((value, setState) => {
	Promise.delay(20).then(() => {
		const target = toLower(value);

		const dynamicOptions = filter(options, (option) =>
			startsWith(toLower(option.text), target),
		);

		setState({
			options: dynamicOptions,
			loadingOptions: false,
		});
	});
}, 1000);

function example() {
	return (
		<>
			<Scope title="Complex Options">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={options}
						onChange={(value) => setState({ value })}
					/>
				)}
			</Scope>
			<Scope title="Complex Options with additional selected Text">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={abbreviated}
						onChange={(value) => setState({ value })}
						selectedTextPath="selectedText"
					/>
				)}
			</Scope>
			<Scope title="Simple Options with Custom Value">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={textOnly}
						onChange={(value) => setState({ value })}
						allowCustomValue
					/>
				)}
			</Scope>
			<Scope title="Simple Options with insensitive Custom Value">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={textOnly}
						onChange={(value) => setState({ value })}
						allowCustomValue="insensitive"
					/>
				)}
			</Scope>
			<Scope title="Complex Options with Custom Value and additional selected Text">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						options={abbreviated}
						onChange={(value) => setState({ value })}
						allowCustomValue
						selectedTextPath="selectedText"
					/>
				)}
			</Scope>
			<Scope title="No Options with Custom Value (Just use an TextInput)">
				{(state, setState) => (
					<SelectInput
						label="Select your favorite doughnut"
						value={state.value}
						onChange={(value) => setState({ value })}
						allowCustomValue
					/>
				)}
			</Scope>
			<Scope title="Dynamic Options with custom messages">
				{(state, setState) => {
					const handleFilterChange = ({ value }) => {
						setState({
							options: null,
						});

						if (isNil(value) || value.length <= 0) {
							return;
						}

						setState({
							loadingOptions: true,
						});

						serviceCall(value, setState);
					};

					return (
						<SelectInput
							label="Select your favorite doughnut"
							value={state.value}
							options={state.options}
							enableExternalFilter
							onChange={(value) => setState({ value })}
							selectedTextPath={(v) =>
								get(lookUp, [v, 'selectedText'], v)
							}
							optionTextPath="text"
							noOptionsMessage={
								state.loadingOptions
									? 'loading options...'
									: 'Huh, nothing matches...'
							}
							useFilterMessage="Use the filter ya crazy!"
							onFilterChange={handleFilterChange}
							allowCustomValue={!state.loadingOptions}
						/>
					);
				}}
			</Scope>
		</>
	);
}

example.story = {
	name: 'Options',
};

export default example;
