// @ts-nocheck
import React, { useState, useMemo } from 'react';
import reduce from 'lodash-es/reduce';
import Scope from '../../../../.storybook/components/scope';
import MultiSelectInput from '..';
import { abbreviated } from '../../../common/storybook/options-data';

function generateMessages(count = 0) {
	const messages = [];

	for (let counter = 0; counter < count; counter += 1) {
		messages.push(`Message Number ${counter + 1}`);
	}

	return messages;
}

function example(props) {
	const [value, setValue] = useState(null);

	const {
		successMessageCount,
		invalidMessageCount,
		generalMessageCount,
		...rest
	} = props;

	const successMessages = useMemo(
		() => generateMessages(successMessageCount),
		[successMessageCount],
	);
	const invalidMessages = useMemo(
		() => generateMessages(invalidMessageCount),
		[invalidMessageCount],
	);
	const generalMessages = useMemo(
		() => generateMessages(generalMessageCount),
		[generalMessageCount],
	);
	const messages = useMemo(() => {
		if (
			successMessages.length <= 0 &&
			invalidMessages.length <= 0 &&
			generalMessages.length <= 0
		) {
			return null;
		}

		const mess = {};

		if (successMessages.length > 0) {
			mess.success = successMessages;
		}

		if (invalidMessages.length > 0) {
			mess.invalid = invalidMessages;
		}

		if (generalMessages.length > 0) {
			mess.general = generalMessages;
		}

		return mess;
	}, [successMessages, invalidMessages, generalMessages]);

	return (
		<Scope fillViewport>
			<MultiSelectInput
				{...reduce(
					rest,
					(acc, prop, key) => {
						if (prop === 'true') {
							acc[key] = true;
						} else if (prop === 'false') {
							acc[key] = false;
						} else {
							acc[key] = prop;
						}

						return acc;
					},
					{},
				)}
				options={abbreviated}
				value={value}
				onChange={setValue}
				messages={messages}
			/>
		</Scope>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		placeholder: {
			control: 'text',
		},
		label: {
			control: 'text',
		},
		value: { table: { disable: true } },

		title: {
			control: 'text',
		},
		'aria-label': {
			control: 'text',
		},
		nullable: {
			control: 'boolean',
		},
		searchMinChar: {
			control: 'number',
		},
		disabled: {
			control: 'boolean',
		},
		allowCustomValue: {
			control: 'boolean',
		},
		hideSelected: {
			control: 'boolean',
		},
		noOptionsMessage: {
			control: 'text',
		},
		useFilterMessage: {
			control: 'text',
		},
		enableSort: {
			control: 'boolean',
		},
		invalid: {
			control: 'boolean',
		},
		successMessageCount: {
			control: 'number',
		},
		invalidMessageCount: {
			control: 'number',
		},
		generalMessageCount: {
			control: 'number',
		},
		hidden: {
			control: 'boolean',
		},
		size: {
			control: 'select',
			options: ['sm', 'md', 'lg'],
		},
	},
	args: {
		nullable: true,
		disabled: false,
		allowCustomValue: false,
		hideSelected: false,
		enableSort: false,
		invalid: false,
		hidden: false,
		size: 'md',
	}
};

export default example;
