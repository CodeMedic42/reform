// @ts-nocheck
import React from 'react';
import SelectInput from '..';
import Scope from '../../../../.storybook/components/scope';
import { textOnly } from '../../../common/storybook/options-data';

function example() {
	const [value, setValue] = React.useState(null);

	return (
		<>
			<Scope title="No Size(Default size-md)">
				<SelectInput
					label="Select Input"
					value={value}
					options={textOnly}
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Size SM">
				<SelectInput
					label="Select Input"
					value={value}
					options={textOnly}
					onChange={setValue}
					size="sm"
				/>
			</Scope>
			<Scope title="Size MD">
				<SelectInput
					label="Select Input"
					value={value}
					options={textOnly}
					onChange={setValue}
					size="md"
				/>
			</Scope>
			<Scope title="Size LG">
				<SelectInput
					label="Select Input"
					value={value}
					options={textOnly}
					onChange={setValue}
					size="lg"
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Sizes',
};

export default example;
