// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import DropDownListItem from '../drop-down/drop-down-list-item';
import ListItemButton from '../drop-down/list-item-button';
import { schemeColorPropType } from '../../common/color-list';

class SelectItemButton extends PureComponent {
	render() {
		const {
			id,
			targeted,
			selected,
			borderBottom,
			color,
			'aria-label': ariaLabel,
			children,
			onClick,
			onClickMeta,
			disabled,
		} = this.props;

		return (
			<DropDownListItem
				id={id}
				className={classnames({
					disabled,
				})}
				targeted={targeted}
				borderBottom={borderBottom}
				color={color}
				aria-label={ariaLabel}
				selected={selected}
				disabled={disabled}
			>
				<ListItemButton
					onClick={onClick}
					onClickMeta={onClickMeta}
					tabIndex="-1"
					disabled={disabled}
				>
					{children}
				</ListItemButton>
			</DropDownListItem>
		);
	}
}

SelectItemButton.propTypes = {
	id: PropTypes.string,
	targeted: PropTypes.bool,
	selected: PropTypes.bool,
	borderBottom: PropTypes.bool,
	children: PropTypes.node,
	onClick: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
	color: schemeColorPropType,
	'aria-label': PropTypes.string,
	disabled: PropTypes.bool,
};

SelectItemButton.defaultProps = {
	id: null,
	targeted: false,
	selected: false,
	borderBottom: false,
	disabled: false,
	children: null,
	onClick: null,
	onClickMeta: null,
	color: null,
	'aria-label': null,
};

export default SelectItemButton;
