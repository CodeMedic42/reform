// @ts-nocheck
import React, { Component, createRef } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import toLower from 'lodash-es/toLower';
import map from 'lodash-es/map';
import findIndex from 'lodash-es/findIndex';
import trim from 'lodash-es/trim';
import isString from 'lodash-es/isString';
import get from 'lodash-es/get';
import clone from 'lodash-es/clone';
import pullAt from 'lodash-es/pullAt';
import forEach from 'lodash-es/forEach';
import isFunction from 'lodash-es/isFunction';
import CollectionContext from '@audacious/web-common/lists/CollectionContext';
import DropDown from '../drop-down';
import DropDownList from '../drop-down/drop-down-list';
import DropDownListItem from '../drop-down/drop-down-list-item';
import ListItemContent from '../drop-down/list-item-content';
import buildId from '../../common/build-id';
import InputLabel, {
	propTypes as inputLabelPropTypes,
	defaultProps as inputLabelDefaultProps,
} from '../base-input/input-label';
import {
	beforeInsertOption,
	getId,
	buildFinalOptions,
} from '../../common/select-utls';
import preventDefault from '../../common/prevent-default';
import SelectItemButton from './select-item-button';

function buildMultiValueByKey(existingValue, selectedId) {
	let newValue = [];
	let didRemove = false;

	forEach(existingValue, (item) => {
		if (item !== selectedId) {
			newValue.push(item);
		} else {
			didRemove = true;
		}
	});

	if (!didRemove) {
		newValue.push(selectedId);
	}

	if (newValue.length <= 0) {
		newValue = null;
	}

	return newValue;
}

function buildAnchorProps({
	anchorProps,
	id,
	color,
	value,
	title,
	describedBy,
	labelledBy,
	nullable,
	disabled,
	size,
	placeholder,
	ariaLabel,
	onClear,
	onClearIndex,
	listBoxId,
}) {
	const props = {
		...anchorProps,
		id,
		value,
		title,
		'aria-describedby': describedBy,
		'aria-labelledby': labelledBy,
		nullable,
		disabled,
		size,
		placeholder,
		'aria-label': ariaLabel,
		onClear,
		onClearIndex,
		listBoxId,
	};

	if (!isNil(color)) {
		props.color = color;
	}

	return props;
}

/**
 * Returns the text to display in the dropdown anchor for the given value.
 * NOTE: This function has a side effect of adding a 'selected' tag to the
 * selected option.
 */
function getSelectedText(nextValue, selectedTextPath, optionsContext) {
	let selectedText = '';

	// Determine Id of selected Value
	// const valueId = getId(nextValue, keyPath);

	// Get the option for this item
	const option = optionsContext.getById(nextValue);

	if (!isNil(option)) {
		// If the item is in the option list then show that item as selected.
		option.addTag('selected');

		if (isNil(selectedTextPath)) {
			selectedText = option.getValue('text');
		} else if (isString(selectedTextPath) && selectedTextPath.length > 0) {
			selectedText = get(option.getValue('value'), selectedTextPath);
		}
	}

	if (selectedText.length <= 0) {
		if (isFunction(selectedTextPath)) {
			selectedText = selectedTextPath(nextValue);

			if (!isString(selectedText) || selectedText.length <= 0) {
				throw new Error('selectedText must return a string.');
			}
		} else {
			selectedText = `${nextValue}`;
		}
	}

	const { color: selectedColor } = option ? option.getValue('value') : {};

	return {
		selectedText,
		selectedColor,
	};
}

class Select extends Component {
	constructor(...args) {
		super(...args);

		const [props] = args;

		this.dropDownRef = createRef();
		this.dropDownListRef = createRef();
		this.filterInputRef = createRef();
		this.labelRef = createRef();

		this.dropdownNavHandler = this.dropdownNavHandler.bind(this);
		this.handleSelect = this.handleSelect.bind(this);
		this.handleClearValue = this.handleClearValue.bind(this);
		this.handleDropDownKeyDown = this.handleDropDownKeyDown.bind(this);
		this.handleFilterChange = this.handleFilterChange.bind(this);
		this.handleOpen = this.handleOpen.bind(this);
		this.handleClose = this.handleClose.bind(this);
		this.handleFilterKeyDown = this.handleFilterKeyDown.bind(this);
		this.handleClearIndex = this.handleClearIndex.bind(this);

		this.labelPreventDefault = this.labelPreventDefault.bind(this);

		const { enableSort, enableExternalFilter } = props;

		const sortingRules = [];
		let filterRules = null;

		if (!enableExternalFilter) {
			sortingRules.push({ type: 'filter', order: 'desc' });

			filterRules = {
				labelFilter: ['text'],
			};
		}

		if (enableSort) {
			sortingRules.push('text');
		}

		const optionsContext = new CollectionContext({
			getId: (item) => {
				const { keyPath } = this.props;

				return getId(item, keyPath);
			},
			beforeInsert: (option) => {
				const { optionTextPath } = this.props;

				return beforeInsertOption(option, optionTextPath);
			},
			sortingRules,
			filterRules,
		});

		this.state = {
			previous: {},
			filter: null,
			targetIndex: null,
			items: [],
			optionsContext,
			filterMatched: false,
			filterValue: '',
			isOpen: false,
		};
	}

	static getDerivedStateFromProps(nextProps, currentState) {
		const {
			options: nextOptions,
			value: nextValue,
			allowCustomValue,
			selectedTextPath,
			hideSelected,
			isMultiSelect,
		} = nextProps;

		const { filter, optionsContext, targetIndex } = currentState;
		let {
			previous: { options: previousOptions, value: previousValue },
			items,
			filterMatched,
			customOption,
		} = currentState;

		let changed = false;

		if (previousOptions !== nextOptions) {
			changed = true;
			previousOptions = nextOptions;

			optionsContext.setItems(nextOptions || []);
		}

		changed =
			optionsContext.setFilterValues({
				labelFilter: filter,
			}) || changed;

		previousValue = nextValue;
		optionsContext.removeAllTaggedItems('selected');

		let customValueSetting = null;

		if (!isNil(allowCustomValue)) {
			if (allowCustomValue === true) {
				customValueSetting = 'sensitive';
			} else if (allowCustomValue !== false) {
				customValueSetting = allowCustomValue;
			}
		}

		let checkValue = filter;
		let filterCheck = () => false;

		if (customValueSetting === 'sensitive') {
			filterCheck = (value) => value === checkValue;
		} else if (customValueSetting === 'insensitive') {
			checkValue = toLower(filter);

			filterCheck = (value) => toLower(value) === checkValue;
		}

		let filterMatchesValue = false;
		let selectedText = null;
		let selectedColor = null;

		if (!isNil(nextValue)) {
			if (isMultiSelect) {
				selectedText = map(nextValue, (selectedValue) => {
					filterMatchesValue =
						filterMatchesValue || filterCheck(selectedValue);

					const { selectedText: selectedTextItem } = getSelectedText(
						selectedValue,
						selectedTextPath,
						optionsContext,
					);

					return selectedTextItem;
				});
			} else {
				filterMatchesValue = filterCheck(nextValue);

				({ selectedText, selectedColor } = getSelectedText(
					nextValue,
					selectedTextPath,
					optionsContext,
				));
			}
		}

		let newTargetIndex = targetIndex;

		if (changed || hideSelected) {
			({ items, filterMatched } = buildFinalOptions(
				filter,
				hideSelected,
				customValueSetting,
				optionsContext,
			));

			if (
				!isNil(customValueSetting) &&
				!filterMatched &&
				!isNil(filter) &&
				filter.length > 0 &&
				!filterMatchesValue
			) {
				customOption = filter;
			} else {
				customOption = null;
			}

			if (items.length <= 0) {
				if (!isNil(customOption)) {
					newTargetIndex = 0;
				} else {
					newTargetIndex = null;
				}
			} else if (isNil(newTargetIndex)) {
				newTargetIndex = 0;
			} else if (!isNil(customOption)) {
				if (newTargetIndex >= items.length + 1) {
					newTargetIndex = items.length - 1;
				}
			} else if (newTargetIndex >= items.length) {
				newTargetIndex = items.length - 1;
			}
		}

		return {
			previous: {
				options: previousOptions,
				value: previousValue,
			},
			items,
			targetIndex: newTargetIndex,
			selectedText,
			filterMatched,
			customOption,
			selectedColor,
		};
	}

	handleSelect({ meta }) {
		const { id } = meta;

		this.selectValue(id);
	}

	handleDropDownKeyDown(event) {
		const { nullable, useFilter } = this.props;
		const { isOpen } = this.state;

		// If not using the filter handle item selection and up/down
		// events when focused on an open dropdown. Otherwise handle
		// them when focused on the filter.
		if (!useFilter && isOpen) {
			this.dropdownNavHandler(event);
		}

		if (isOpen) {
			// If the tray is open then ignore this event.
			// When the tray is open the control exists with the filter input.
			return;
		}

		if (
			event.which === 40 || // down arrow
			event.which === 38 // up arrow
		) {
			// Here the DropDown will open the tray.
			return;
		}

		if (
			event.which === 9 || // Tab
			event.which === 16 || // Shift
			event.which === 27 || // escape
			event.which === 20 || // caps-lock
			event.which === 17 || // ctrl
			event.which === 18 || // option
			event.metaKey || // Things like the command key on Mac
			event.which === 13 // enter
		) {
			// Just ignore tab or shift because this is
			// moving the user around the page with the keyboard.

			// Escape should not do anything

			// Enter should be handled by the dropdown while it is closed.
			return;
		}

		if (
			event.which === 8 || // backspace
			event.which === 46 // delete
		) {
			// Here the tray is closed and the dropdown button should have focus.
			// This means we want to clear the value.
			if (nullable) {
				this.handleClearValue();
			}

			return;
		}

		// For all other cases open the tray.
		// Since "technically" the tray is rendered, but NOT hidden,
		// the input can still be given focus and can take keystrokes.

		// Open the tray
		this.dropDownRef.current.setOpen(true);

		// and then focus the filter input.
		if (useFilter && this.filterInputRef && this.filterInputRef.current) {
			this.filterInputRef.current.focus();
		}
	}

	handleFilterKeyDown(event) {
		this.dropdownNavHandler(event);
	}

	handleFilterChange(event) {
		this.changeFilter(event.target.value);
	}

	handleClearValue() {
		const { onChange, onChangeMeta } = this.props;

		if (!isNil(onChange)) {
			onChange(null, {
				meta: onChangeMeta,
			});
		}
	}

	handleOpen() {
		const { useFilter, onOpen, disableAutoScroll } = this.props;
		const { items, hideSelected } = this.state;

		let targetIndex = 0;

		if (!hideSelected) {
			// The item that is currently selected.
			const optionIndex = findIndex(items, (item) =>
				item.hasTag('selected'),
			);

			targetIndex = optionIndex >= 0 ? optionIndex : 0;
		}

		this.setState({
			targetIndex,
			isOpen: true,
		});

		if (!isNil(onOpen)) {
			onOpen();
		}

		// This timeout is here because if you focus too quickly it
		// does not give the tray enough time to render and move.
		// If we do not wait then the browser will quickly scroll
		// to the drawer away from the select.
		setTimeout(() => {
			if (
				useFilter &&
				this.filterInputRef &&
				this.filterInputRef.current
			) {
				this.filterInputRef.current.focus();
			}

			if (!disableAutoScroll) {
				this.dropDownListRef.current.scrollToIndex(targetIndex);
			}
		}, 1);
	}

	handleClose() {
		const { useFilter, onClose } = this.props;

		if (useFilter) {
			this.changeFilter('');
		}

		this.setState({
			targetIndex: null,
			isOpen: false,
		});

		if (!isNil(onClose)) {
			onClose();
		}
	}

	handleClearIndex({ index }) {
		const { value, onChange, onChangeMeta } = this.props;

		if (isNil(onChange)) {
			return;
		}

		let newValue = clone(value);

		pullAt(newValue, [index]);

		if (newValue.length <= 0) {
			newValue = null;
		}

		onChange(newValue, {
			meta: onChangeMeta,
		});
	}

	// Handle keyboard navigation and selection inside a dropdown list.
	// Return true if the keyboard event was handled.
	dropdownNavHandler(event) {
		const { isMultiSelect, disableAutoScroll } = this.props;
		const { items, customOption, targetIndex } = this.state;

		if (event.which === 27) {
			// Escape
			// Close the tray.
			this.dropDownRef.current.setOpen(false);

			return true;
		}

		if (event.which === 13) {
			// Enter
			// Select the current target item
			if (!isNil(targetIndex)) {
				let finalTargetIndex = targetIndex;

				if (!isNil(customOption)) {
					if (targetIndex === 0) {
						this.selectValue(null);

						return true;
					}

					finalTargetIndex = targetIndex - 1;
				}

				const item = items[finalTargetIndex];
				this.selectValue(item.getId());
			}

			if (isNil(targetIndex) || isMultiSelect) {
				// This will prevent the dropdowns natural tendency to close the tray on enter/return.
				event.preventDefault();
			}

			return true;
		}

		if (
			event.which === 40 || // down arrow
			event.which === 38 // up arrow
		) {
			// Move the targetIndex
			const maxIndex = isNil(customOption)
				? items.length - 1
				: items.length;

			if (maxIndex <= 0) {
				return false;
			}

			let newIndex = targetIndex;

			if (event.which === 40) {
				// Down Arrow
				// If at the end of the list then move to the top
				if (isNil(newIndex) || newIndex >= maxIndex) {
					newIndex = 0;
				} else {
					newIndex += 1;
				}
			} else if (event.which === 38) {
				// Up Arrow
				// If at the beginning of the list then move to the bottom
				if (isNil(newIndex) || newIndex <= 0) {
					newIndex = maxIndex;
				} else {
					newIndex -= 1;
				}
			}

			if (!disableAutoScroll) {
				this.dropDownListRef.current.scrollToIndex(newIndex);
			}

			this.setState({
				targetIndex: newIndex,
			});

			// This "should" prevent the arrow keys from scrolling the page.
			event.preventDefault();

			return true;
		}

		return false;
	}

	selectValue(idToSelect) {
		const { value, onChange, onChangeMeta, useFilter, isMultiSelect } =
			this.props;

		const { customOption } = this.state;

		if (isNil(onChange)) {
			return;
		}

		let selectedId = idToSelect;

		if (isNil(idToSelect)) {
			if (isNil(customOption)) {
				return;
			}

			selectedId = customOption;
		}

		const newValue = isMultiSelect
			? buildMultiValueByKey(value, selectedId)
			: selectedId;

		if (
			isMultiSelect &&
			useFilter &&
			this.filterInputRef &&
			this.filterInputRef.current
		) {
			// Focus the filter after a multi select selection to allow the
			// up and down arrow keys to continue to work.
			this.filterInputRef.current.focus();
		}

		onChange(newValue, {
			meta: onChangeMeta,
		});
	}

	changeFilter(filterValue) {
		const { onFilterChange, onFilterChangeMeta } = this.props;
		let { searchMinChar } = this.props;
		const { filter: previousFilter } = this.state;

		const newState = {
			filterValue,
		};

		searchMinChar = searchMinChar > 0 ? searchMinChar : 1;

		let nextFilter = !isNil(filterValue) ? trim(filterValue) : '';
		nextFilter = nextFilter.length >= searchMinChar ? nextFilter : null;

		if (nextFilter !== previousFilter) {
			newState.filter = nextFilter;
			newState.targetIndex = 0;
		}

		this.setState(newState);

		if (!isNil(onFilterChange)) {
			onFilterChange({
				value: nextFilter,
				meta: onFilterChangeMeta,
			});
		}
	}

	labelPreventDefault(event) {
		if (event.target === this.labelRef.current) {
			event.preventDefault();
		}
	}

	renderOptions(finalId, listBoxId, labelledBy) {
		const {
			size,
			useFilterMessage,
			noOptionsMessage,
			listItemBorder,
			isMultiSelect,
		} = this.props;

		const { targetIndex, items, customOption, filter } = this.state;

		let listItems = null;

		let targetedElementId = null;

		if (isNil(customOption) && items.length <= 0) {
			const message =
				!isNil(filter) && filter.length > 0
					? noOptionsMessage // 'No results found'
					: useFilterMessage; // 'Type a value';

			listItems = (
				<DropDownListItem id={buildId(finalId, '$__custom__$')}>
					<ListItemContent className="no-options">
						{message}
					</ListItemContent>
				</DropDownListItem>
			);
		} else {
			let customValueElement = null;

			if (!isNil(customOption)) {
				const customId = buildId(finalId, '$__custom__$');
				const customIsTarget = targetIndex === 0;

				if (customIsTarget) {
					targetedElementId = customId;
				}

				customValueElement = (
					<SelectItemButton
						id={customId}
						targeted={customIsTarget}
						borderBottom={listItemBorder && items.length > 0}
						onClick={this.handleSelect}
						onClickMeta={{ id: null }}
					>
						{customOption}
					</SelectItemButton>
				);
			}

			listItems = (
				<>
					{customValueElement}
					{map(items, (item, idx) => {
						const data = item.getValue();
						const {
							value: { color },
						} = data;
						const itemId = item.getId();
						const selected = item.hasTag('selected');

						const shiftIndex = !isNil(customValueElement)
							? idx + 1
							: idx;

						const optionId = buildId(finalId, itemId);
						const optionIsTarget = shiftIndex === targetIndex;

						if (optionIsTarget) {
							targetedElementId = optionId;
						}

						return (
							<SelectItemButton
								key={itemId}
								color={color}
								id={optionId}
								aria-label={data['aria-label']}
								selected={selected}
								targeted={optionIsTarget}
								borderBottom={
									listItemBorder && idx + 1 < items.length
								}
								onClick={this.handleSelect}
								onClickMeta={{ id: itemId }}
							>
								{data.text}
							</SelectItemButton>
						);
					})}
				</>
			);
		}

		return {
			options: (
				<DropDownList
					ref={this.dropDownListRef}
					id={listBoxId}
					size={size}
					aria-labelledby={labelledBy}
					aria-multiselectable={isMultiSelect}
				>
					{listItems}
				</DropDownList>
			),
			targetedElementId,
		};
	}

	render() {
		const {
			className,
			label,
			'aria-label': ariaLabel,
			messages,
			invalid,
			hidden,
			title,
			nullable,
			disabled,
			dockRight,
			minDrawerWidth,
			placeholder,
			Anchor,
			useFilter,
			isMultiSelect,
			anchorProps,
			onFocus,
			onBlur,
			id,
			'aria-labelledby': ariaLabelledby,
			'aria-describedby': ariaDescribedby,
			size,
		} = this.props;

		const { selectedText, selectedColor, filterValue } = this.state;

		return (
			<InputLabel
				className={classnames('ai-drop-down-input', className)}
				id={id}
				label={label}
				messages={messages}
				invalid={invalid}
				aria-labelledby={ariaLabelledby}
				aria-describedby={ariaDescribedby}
				hidden={hidden}
				disabled={disabled}
				size={size}
			>
				{({ describedBy, labelledBy, inputId, finalId }) => {
					const listBoxId = buildId(finalId, 'options-list');

					const { options, targetedElementId } = this.renderOptions(
						finalId,
						listBoxId,
						labelledBy,
					);

					return (
						<DropDown
							ref={this.dropDownRef}
							id={`${finalId}-dropdown`}
							className={classnames('ai-select')}
							trayClassName={classnames(
								'ai-select-tray',
								`size-${size}`,
							)}
							disabled={disabled}
							minDrawerWidth={minDrawerWidth}
							onFocus={onFocus}
							onBlur={onBlur}
							maxDrawerHeight={216}
							onKeyDown={this.handleDropDownKeyDown}
							onOpen={this.handleOpen}
							onClose={this.handleClose}
							closeTrayOnClick={!isMultiSelect}
							Anchor={Anchor}
							anchorProps={buildAnchorProps({
								id: inputId,
								color: selectedColor,
								value: selectedText,
								title,
								describedBy,
								labelledBy,
								nullable,
								disabled,
								size,
								placeholder,
								ariaLabel,
								onClear: this.handleClearValue,
								onClearIndex: isMultiSelect
									? this.handleClearIndex
									: null,
								anchorProps,
								listBoxId,
							})}
							dockRight={dockRight}
						>
							{useFilter ? (
								<input
									ref={this.filterInputRef}
									tabIndex="-1"
									className="ai-dd-list-filter"
									value={filterValue}
									onChange={this.handleFilterChange}
									onKeyDown={this.handleFilterKeyDown}
									onClick={preventDefault}
									size="1"
									aria-label="List Filter"
									aria-activedescendant={targetedElementId}
								/>
							) : null}
							{options}
						</DropDown>
					);
				}}
			</InputLabel>
		);
	}
}

const valueType = PropTypes.oneOfType([
	PropTypes.string,
	PropTypes.number,
	PropTypes.arrayOf(
		PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
	),
]);

const exportPropTypes = {
	...inputLabelPropTypes,
	value: valueType,
	useFilter: PropTypes.bool,
	isMultiSelect: PropTypes.bool,
	anchorProps: PropTypes.objectOf(PropTypes.any),
	onOpen: PropTypes.func,
	onClose: PropTypes.func,
	options: PropTypes.arrayOf(PropTypes.any),
	placeholder: PropTypes.string,
	title: PropTypes.string,
	'aria-label': PropTypes.string,
	nullable: PropTypes.bool,
	searchMinChar: PropTypes.number,
	disabled: PropTypes.bool,
	listItemBorder: PropTypes.bool,
	dockRight: PropTypes.bool,
	minDrawerWidth: PropTypes.oneOfType([
		PropTypes.number,
		PropTypes.oneOf(['anchor']),
	]),
	allowCustomValue: PropTypes.oneOfType([
		PropTypes.bool,
		PropTypes.oneOf(['sensitive', 'insensitive']),
	]),
	noOptionsMessage: PropTypes.string,
	useFilterMessage: PropTypes.string,
	enableSort: PropTypes.bool,
	enableExternalFilter: PropTypes.bool,
	selectedTextPath: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
	keyPath: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
	optionTextPath: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
	hideSelected: PropTypes.bool,
	onChange: PropTypes.func,
	onChangeMeta: PropTypes.any,
	onFocus: PropTypes.func,
	onBlur: PropTypes.func,
	onFilterChange: PropTypes.func,
	onFilterChangeMeta: PropTypes.any,
	disableAutoScroll: PropTypes.bool,
};

Select.propTypes = {
	...exportPropTypes,
	Anchor: PropTypes.elementType.isRequired,
};

Select.defaultProps = {
	...inputLabelDefaultProps,
	value: null,
	useFilter: false,
	isMultiSelect: false,
	anchorProps: {},
	onOpen: null,
	onClose: null,
	placeholder: null,
	title: null,
	'aria-label': null,
	hideSelected: false,
	nullable: true,
	searchMinChar: 1,
	disabled: false,
	listItemBorder: false,
	dockRight: false,
	minDrawerWidth: 'anchor',
	allowCustomValue: false,
	options: null,
	noOptionsMessage: 'No results found',
	useFilterMessage: 'Type a value',
	enableSort: false,
	enableExternalFilter: false,
	selectedTextPath: null,
	optionTextPath: 'text',
	keyPath: 'key',
	onChange: null,
	onFocus: null,
	onBlur: null,
	onFilterChange: null,
	onFilterChangeMeta: null,
	onChangeMeta: null,
	disableAutoScroll: false,
};

export default Select;

const exportDefaultProps = Select.defaultProps;

export { exportPropTypes as propTypes, exportDefaultProps as defaultProps };
