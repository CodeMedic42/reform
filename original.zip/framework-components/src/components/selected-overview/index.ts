// @ts-nocheck
import SelectedOverview from './selected-overview';

export default SelectedOverview;
