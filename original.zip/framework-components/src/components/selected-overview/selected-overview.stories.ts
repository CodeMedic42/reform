// @ts-nocheck
import SelectedOverview from '.';

export default {
	title: 'Controls/Selected Overview',
	component: SelectedOverview,
};

export { default as basic } from './stories/basic';
export { default as behaviors } from './stories/behaviors';
