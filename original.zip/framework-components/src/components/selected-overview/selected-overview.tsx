// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import Button from '../button';

class SelectedOverview extends PureComponent {
	render() {
		const {
			id,
			className,
			numSelected,
			buttonText,
			'aria-label': ariaLabel,
			title,
			hidden,
			disabled,
			onButtonClick,
		} = this.props;

		return (
			<div
				id={id}
				className={classnames(
					'ai-selected-overview',
					'border-radius-lg',
					className,
					{
						hidden,
					},
				)}
			>
				<span className="ai-selected-overview-counter corner-deep">
					{numSelected}
				</span>
				<span className="ai-selected-overview-text">Selected</span>
				<Button
					id={`${id}-button`}
					aria-label={ariaLabel}
					title={title}
					disabled={disabled}
					size="md"
					variant="fill"
					color="primary"
					rounded
					onClick={onButtonClick}
				>
					{buttonText}
				</Button>
			</div>
		);
	}
}

SelectedOverview.propTypes = {
	id: PropTypes.string.isRequired,
	className: PropTypes.string,
	numSelected: PropTypes.number,
	buttonText: PropTypes.string,
	title: PropTypes.string,
	'aria-label': PropTypes.string,
	hidden: PropTypes.bool,
	disabled: PropTypes.bool,
	onButtonClick: PropTypes.func,
};

SelectedOverview.defaultProps = {
	className: null,
	numSelected: 0,
	buttonText: null,
	title: null,
	'aria-label': null,
	hidden: false,
	disabled: false,
	onButtonClick: null,
};

export default SelectedOverview;
