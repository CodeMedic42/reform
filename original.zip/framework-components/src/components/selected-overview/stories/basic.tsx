// @ts-nocheck
import React from 'react';
import SelectedOverview from '..';
import Scope from '../../../../.storybook/components/scope';

function onButtonClick() {
	// eslint-disable-next-line no-console
	console.log('Button clicked');
}

function example() {
	return (
		<>
			<Scope title="Simple">
				<SelectedOverview
					id="simple"
					buttonText="Next"
					onButtonClick={onButtonClick}
				/>
			</Scope>
			<Scope title="Disabled">
				<SelectedOverview
					id="disabled"
					buttonText="Next"
					onButtonClick={onButtonClick}
					disabled
				/>
			</Scope>
			<Scope title="Hidden">
				<SelectedOverview
					id="hidden"
					buttonText="Next"
					onButtonClick={onButtonClick}
					hidden
				/>
			</Scope>
			<Scope title="All Props">
				<SelectedOverview
					id="all-props"
					numSelected={17}
					buttonText="Continue"
					title="Confirm selection"
					aria-label="Confirm selection and continue"
					hidden={false}
					disabled={false}
					onButtonClick={onButtonClick}
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
