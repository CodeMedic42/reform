// @ts-nocheck
import React from 'react';
import SelectedOverview from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [numSelected, setNumSelected] = React.useState(0);
	const [thousandNumSelected, setThousandNumSelected] = React.useState(0);
	const [hide, setHide] = React.useState(false);

	return (
		<>
			<Scope title="Add 1 Selected On Click">
				<SelectedOverview
					id="add-one"
					numSelected={numSelected}
					buttonText="Select 1"
					onButtonClick={() => setNumSelected(numSelected + 1)}
				/>
			</Scope>
			<Scope title="Add 1000 Selected On Click">
				<SelectedOverview
					id="add-one-thousand"
					numSelected={thousandNumSelected}
					buttonText="Select 1000"
					onButtonClick={() =>
						setThousandNumSelected(thousandNumSelected + 1000)
					}
				/>
			</Scope>
			<Scope title="Hide On Click">
				<SelectedOverview
					id="hide-on-click"
					buttonText="Next"
					onButtonClick={() => setHide(!hide)}
					hidden={hide}
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Behaviors',
};

export default example;
