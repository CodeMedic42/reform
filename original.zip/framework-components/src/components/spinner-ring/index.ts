// @ts-nocheck
import SpinnerRing from './spinner-ring';

export default SpinnerRing;
