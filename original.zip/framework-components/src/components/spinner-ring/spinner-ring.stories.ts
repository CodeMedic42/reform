// @ts-nocheck
import SpinnerRing from '.';

export default {
	title: 'Progress/Spinner Ring',
	component: SpinnerRing,
};

export { default as preview } from './stories/preview';
