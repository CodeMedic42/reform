// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import { paletteColorOrder } from '../../common/color-list';

function SpinnerRing(props) {
	const { id, className, size, color, variant } = props;

	const sizeClass = !isNil(size) ? `size-${size}` : 'size-md';
	const variantClass = !isNil(size) ? `${variant}-spinner` : 'solid-spinner';

	return (
		<div
			id={id}
			className={classnames(
				'ai-spinner-ring',
				`spinner-color-${color === null ? 'blue' : color}`,
				sizeClass,
				className,
				variantClass,
			)}
		/>
	);
}

SpinnerRing.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xl']),
	color: PropTypes.oneOf(paletteColorOrder),
	variant: PropTypes.oneOf(['solid', 'dotted']),
};

SpinnerRing.defaultProps = {
	id: null,
	className: null,
	size: 'md',
	color: 'blue',
	variant: 'solid',
};

export default SpinnerRing;
