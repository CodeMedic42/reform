// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import Spinner from '..';
import { paletteColorOrder } from '../../../common/color-list';

function example(props) {
	return (
		<Scope fillViewport>
			<Spinner {...props} />
		</Scope>
	);
}

example.story = {
	name: 'Preview',
	parameters: {
		options: {
			showPanel: true,
		},
	},
	argTypes: {
		id: {
			control: 'text',
		},
		className: {
			control: 'text',
		},
		size: {
			options: ['xl', 'lg', 'md', 'sm', 'xs'],
			control: { type: 'select' },
		},
		color: {
			options: paletteColorOrder,
			control: { type: 'select' },
		},
		variant: {
			options: ['solid', 'dotted'],
			control: { type: 'select' },
		},
	},
	args: {
		size: 'md',
		color: 'blue',
		variant: 'solid',
	}
};

export default example;
