// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import { paletteColorOrder } from '../../common/color-list';
import PageSpinner from '../page-spinner/page-spinner';
import OverlaySpinner from '../overlay-spinner';
import SpinnerRing from '../spinner-ring';

function Spinner(props) {
	const { id, className, size, color, dotted, variant, spaceFromTop } = props;

	const spinnerProps = {
		id,
		className,
		size,
		color,
		variant: dotted ? 'dotted' : 'solid',
	};

	if (variant === 'overlay' || variant === 'overlay-sticky') {
		spinnerProps.alignment = spaceFromTop;

		return <OverlaySpinner {...spinnerProps} />;
	}

	if (variant === 'page') {
		return <PageSpinner {...spinnerProps} />;
	}

	return <SpinnerRing {...spinnerProps} />;
}

Spinner.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg', 'xlg']),
	spaceFromTop: PropTypes.oneOf(['centered', 'sm', 'md', 'lg']),
	variant: PropTypes.oneOf(['inline', 'overlay', 'overlay-sticky', 'page']),
	color: PropTypes.oneOf(paletteColorOrder),
	dotted: PropTypes.bool,
};

Spinner.defaultProps = {
	id: null,
	className: null,
	size: 'md',
	spaceFromTop: 'centered',
	variant: 'inline',
	color: 'blue',
	dotted: false,
};

export default Spinner;
