// @ts-nocheck
import SwitchInput from './switch-input';

export default SwitchInput;
