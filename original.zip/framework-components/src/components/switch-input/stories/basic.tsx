// @ts-nocheck
import React, { useState } from 'react';
import SwitchInput from '..';
import Scope from '../../../../.storybook/components/scope';
import { Row, Column } from '../../grid';

function example() {
	const [checked, setChecked] = useState(undefined);

	return (
		<>
			<Scope title="Defaults">
				<SwitchInput
					value={checked}
					onChange={() => setChecked(!checked)}
				/>
			</Scope>
			<Scope title="Colors">
				<Row gutter>
					<Column width="content">
						<SwitchInput
							value={checked}
							color="primary"
							onChange={() => setChecked(!checked)}
						/>
					</Column>
					<Column width="content">
						<SwitchInput
							value={checked}
							color="secondary"
							onChange={() => setChecked(!checked)}
						/>
					</Column>
				</Row>
			</Scope>
			<Scope title="Inverse">
				<Row gutter>
					<Column width="content">
						<SwitchInput
							value={checked}
							color="primary"
							inverseValue
							onChange={() => setChecked(!checked)}
						/>
					</Column>
				</Row>
			</Scope>
			<Scope title="Sizes(sm, md(default), lg)">
				<Row gutter>
					<Column width="content">
						<SwitchInput
							value={checked}
							size="sm"
							onChange={() => setChecked(!checked)}
						/>
					</Column>
					<Column width="content">
						<SwitchInput
							value={checked}
							size="md"
							onChange={() => setChecked(!checked)}
						/>
					</Column>
					<Column width="content">
						<SwitchInput
							value={checked}
							size="lg"
							onChange={() => setChecked(!checked)}
						/>
					</Column>
				</Row>
			</Scope>
			<Scope title="Disabled(all colors)">
				<Row gutter>
					<Column width="content">
						<SwitchInput
							value={checked}
							disabled
							onChange={() => setChecked(!checked)}
						/>
					</Column>
					<Column width="content">
						<SwitchInput
							value={checked}
							color="primary"
							disabled
							onChange={() => setChecked(!checked)}
						/>
					</Column>
					<Column width="content">
						<SwitchInput
							value={checked}
							color="secondary"
							disabled
							onChange={() => setChecked(!checked)}
						/>
					</Column>
				</Row>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
