// @ts-nocheck
import CheckInput from '.';

export default {
	title: 'Inputs/Switch Input',
	component: CheckInput,
};

export { default as Basic } from './stories/basic';
