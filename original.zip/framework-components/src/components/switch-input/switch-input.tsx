// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';

class SwitchInput extends PureComponent {
	constructor(props) {
		super(props);

		this.handleChange = this.handleChange.bind(this);
	}

	handleChange(event) {
		const { inverseValue, onChange, onChangeMeta } = this.props;

		if (isNil(onChange)) {
			return;
		}

		onChange(event.target.checked === !inverseValue, {
			event,
			meta: onChangeMeta,
		});
	}

	render() {
		const {
			id,
			className,
			value,
			size,
			color,
			disabled,
			floatHalo,
			inverseValue,
		} = this.props;

		const sizeClass = !isNil(size) ? `size-${size}` : 'size-md';
		const colorClass = !isNil(color) ? `color-${color}` : null;

		const finalValue = !!value === !inverseValue;

		return (
			<span
				id={id}
				className={classnames(
					'ai-switch-input',
					sizeClass,
					colorClass,
					className,
					{
						checked: finalValue,
						disabled,
						'track-guards': !floatHalo,
					},
				)}
			>
				<input
					type="checkbox"
					checked={finalValue}
					disabled={disabled}
					onChange={this.handleChange}
				/>
				<span />
			</span>
		);
	}
}

SwitchInput.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	value: PropTypes.bool,
	size: PropTypes.oneOf(['sm', 'md', 'lg']),
	color: PropTypes.oneOf(['primary', 'secondary']),
	disabled: PropTypes.bool,
	onChange: PropTypes.func,
	// eslint-disable-next-line react/forbid-prop-types
	onChangeMeta: PropTypes.any,
	floatHalo: PropTypes.bool,
	inverseValue: PropTypes.bool,
};

SwitchInput.defaultProps = {
	id: null,
	className: null,
	value: null,
	size: 'md',
	onChange: null,
	onChangeMeta: null,
	color: null,
	disabled: false,
	floatHalo: false,
	inverseValue: false,
};

export default SwitchInput;
