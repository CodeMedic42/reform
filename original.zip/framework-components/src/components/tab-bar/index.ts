// @ts-nocheck
import TabBar from './tab-bar';

export default TabBar;
