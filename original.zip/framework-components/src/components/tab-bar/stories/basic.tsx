// @ts-nocheck
import React, { useState } from 'react';
import TabBar from '..';
import Scope from '../../../../.storybook/components/scope';

const tabs = [
	{
		id: 'a',
		heading: 'Tab A',
	},
	{
		id: 'b',
		heading: 'Tab B',
	},
	{
		id: 'c',
		heading: 'Tab C',
	},
	{
		id: 'd',
		heading: 'Tab D',
		disabled: true,
	},
];

function example() {
	const [selectedTab, setSelectedTab] = useState('a');

	return (
		<>
			<Scope title="Default">
				<TabBar
					selectedTab={selectedTab}
					tabs={tabs}
					size="lg"
					onSelect={setSelectedTab}
				/>
				<TabBar
					selectedTab={selectedTab}
					tabs={tabs}
					size="sm"
					onSelect={setSelectedTab}
				/>
			</Scope>
			<Scope title="Background">
				<TabBar
					selectedTab={selectedTab}
					tabs={tabs}
					size="lg"
					onSelect={setSelectedTab}
					background
				/>
				<TabBar
					selectedTab={selectedTab}
					tabs={tabs}
					size="sm"
					onSelect={setSelectedTab}
					background
				/>
			</Scope>
			<Scope title="border">
				<TabBar
					selectedTab={selectedTab}
					tabs={tabs}
					size="lg"
					onSelect={setSelectedTab}
					border
				/>
				<TabBar
					selectedTab={selectedTab}
					tabs={tabs}
					size="sm"
					onSelect={setSelectedTab}
					border
				/>
			</Scope>
			<Scope title="justify(Only meant to be used for large tabs at the moment)">
				<TabBar
					selectedTab={selectedTab}
					tabs={tabs}
					size="lg"
					onSelect={setSelectedTab}
					justify
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
