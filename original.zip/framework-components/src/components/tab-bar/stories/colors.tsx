// @ts-nocheck
import React, { useState } from 'react';
import map from 'lodash-es/map';
import TabBar from '..';
import Scope from '../../../../.storybook/components/scope';

const tabs = [
	{
		id: 'a',
		heading: 'Tab A',
	},
	{
		id: 'b',
		heading: 'Tab B',
	},
	{
		id: 'c',
		heading: 'Tab C',
	},
	{
		id: 'd',
		heading: 'Tab D',
		disabled: true,
	},
];

function renderColorScope(color) {
	const [selectedTab, setSelectedTab] = useState('a');

	return (
		<Scope key={color} title={color}>
			<TabBar
				selectedTab={selectedTab}
				tabs={tabs}
				color={color}
				size="lg"
				onSelect={setSelectedTab}
			/>
			<TabBar
				selectedTab={selectedTab}
				tabs={tabs}
				color={color}
				size="sm"
				onSelect={setSelectedTab}
			/>
		</Scope>
	);
}

function example() {
	return (
		<>
			{map(
				['primary', 'secondary', 'info', 'success', 'warn', 'danger'],
				(color) => renderColorScope(color),
			)}
		</>
	);
}

example.story = {
	name: 'Colors',
};

export default example;
