// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { faEllipsis } from '@audacious/icons/solid/faEllipsis';
import Icon from '../icon';
import applyAnchorBinding from '../drop-down/anchor-binding';

class TabButton extends PureComponent {
	render() {
		const { open, ...rest } = this.props;

		return (
			<button
				{...rest}
				className={classnames('ai-scheme sch-control', {
					focus: open,
				})}
				type="button"
			>
				<Icon icon={faEllipsis} size="2xl" />
			</button>
		);
	}
}

TabButton.propTypes = {
	open: PropTypes.bool.isRequired,
};

TabButton.defaultProps = {};

export default applyAnchorBinding(TabButton);
