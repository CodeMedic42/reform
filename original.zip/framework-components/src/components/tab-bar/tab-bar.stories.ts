// @ts-nocheck
import TabBar from '.';

export default {
	title: 'Layout/Tab Bar',
	component: TabBar,
};

export { default as basic } from './stories/basic';
export { default as colors } from './stories/colors';
