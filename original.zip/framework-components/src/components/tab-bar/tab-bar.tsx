// @ts-nocheck
import React, { PureComponent, createRef } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import debounce from 'lodash-es/debounce';
import forEach from 'lodash-es/forEach';
import isNil from 'lodash-es/isNil';
import isEmpty from 'lodash-es/isEmpty';
import {
	schemeColorPropType,
	getSchemeColorClasses,
} from '../../common/color-list';
import Menu, { MenuButton } from '../menu';
import TabAnchor from './tab-anchor';
import Tab from './tab';

class TabBar extends PureComponent {
	constructor(props) {
		super(props);

		this.checkForOverFlow = debounce(this.checkForOverFlow.bind(this), 25);
		this.handleTabClick = this.handleTabClick.bind(this);

		this.barRef = createRef();
		this.tabsRef = createRef();
		
		this.refList = [];

		this.state = {
			hideTabControl: true,
		};
	}

	componentDidMount() {
		window.addEventListener('resize', this.checkForOverFlow);

		this.checkForOverFlow();
	}

	componentDidUpdate() {
		this.checkForOverFlow();
	}

	componentWillUnmount() {
		window.removeEventListener('resize', this.checkForOverFlow);
	}

	handleTabClick({ meta: { id } }) {
		const { onSelect } = this.props;

		onSelect(id);
	}

	checkForOverFlow() {
		const { hideTabControl } = this.state;

		const barElement = this.barRef.current;
		const tabsElement = this.tabsRef.current;

		if (isNil(barElement) || isNil(tabsElement)) {
			return;
		}

		const barRect = barElement.getBoundingClientRect();
		let newHideTabControl = true;

		if (barElement.scrollHeight > barElement.clientHeight) {
			newHideTabControl = false;

			forEach(tabsElement.childNodes, (childNode, index) => {
				const childRect = childNode.getBoundingClientRect();

				const itemNode = this.refList[index].getRootNode();

				if (childRect.y > barRect.y) {
					itemNode.classList.remove('hidden');

					// eslint-disable-next-line no-param-reassign
					childNode.childNodes[0].tabIndex = -1;
				} else {
					itemNode.classList.add('hidden');

					// eslint-disable-next-line no-param-reassign
					childNode.childNodes[0].tabIndex = undefined;
				}
			});
		}

		if (hideTabControl !== newHideTabControl) {
			this.setState({ hideTabControl: newHideTabControl });
		}
	}

	render() {
		const {
			id: idPrefix,
			className,
			color,
			size,
			justify,
			background,
			border,
			tabs,
			selectedTab,
		} = this.props;

		if (isEmpty(tabs)) {
			return null;
		}

		const { hideTabControl } = this.state;

		const tabElements = [];
		const controlTabElements = [];

		forEach(tabs, (tab, index) => {
			const { id, heading, disabled } = tab;

			const tabId = idPrefix ? `${idPrefix}-${id}` : '';

			tabElements.push(
				<Tab
					id={tabId}
					key={id}
					disabled={disabled}
					selected={selectedTab === id}
					onClick={this.handleTabClick}
					onClickMeta={{ id }}
				>
					{heading}
				</Tab>,
			);

			controlTabElements.push(
				<MenuButton
					ref={(node) => {
						this.refList[index] = node;
					}}
					key={id}
					selected={selectedTab === id}
					onClick={this.handleTabClick}
					onClickMeta={{ id }}
					disabled={disabled}
				>
					{heading}
				</MenuButton>,
			);
		});

		const sizeClass = !isNil(size) ? `size-${size}` : 'size-lg';

		const colorClasses = getSchemeColorClasses({
			color: !isNil(size) ? color : 'primary',
			style: 'opaque',
		});

		return (
			<div
				id={idPrefix}
				ref={this.barRef}
				className={classnames(
					'ai-tab-bar',
					className,
					sizeClass,
					colorClasses,
					{
						justify,
						background,
						border,
					},
				)}
			>
				<div ref={this.tabsRef} className={classnames('ai-tabs')}>
					{tabElements}
				</div>
				<Menu
					className={classnames('ai-tab-control', {
						hidden: hideTabControl,
					})}
					Anchor={TabAnchor}
				>
					{controlTabElements}
				</Menu>
			</div>
		);
	}
}

TabBar.propTypes = {
	id: PropTypes.string,
	className: PropTypes.string,
	size: PropTypes.oneOf(['lg', 'sm']),
	justify: PropTypes.bool,
	color: schemeColorPropType,
	background: PropTypes.bool,
	border: PropTypes.bool,
	tabs: PropTypes.arrayOf(
		PropTypes.shape({
			id: PropTypes.string,
			heading: PropTypes.node,
			disabled: PropTypes.bool,
		}),
	),
	selectedTab: PropTypes.string,
	onSelect: PropTypes.func,
};

TabBar.defaultProps = {
	id: '',
	className: null,
	size: 'lg',
	justify: false,
	background: false,
	border: false,
	color: 'primary',
	selectedTab: null,
	tabs: null,
	onSelect: null,
};

export default TabBar;
