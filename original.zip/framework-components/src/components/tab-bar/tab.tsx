// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

class Tab extends PureComponent {
	constructor(props) {
		super(props);

		this.handleClick = this.handleClick.bind(this);
	}

	handleClick(event) {
		const { onClick, onClickMeta } = this.props;

		onClick({
			meta: onClickMeta,
			event,
		});
	}

	render() {
		const { disabled, children, selected, id } = this.props;

		const buttonId = id ? `${id}-tab-btn` : null;

		return (
			<span
				className={classnames('ai-tab', {
					selected,
				})}
			>
				<button
					id={buttonId}
					type="button"
					className="ai-tab-button sch-control no-select"
					disabled={disabled}
					onClick={this.handleClick}
				>
					{children}
				</button>
			</span>
		);
	}
}

Tab.propTypes = {
	id: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	onClick: PropTypes.func.isRequired,
	// eslint-disable-next-line react/forbid-prop-types
	onClickMeta: PropTypes.any,
	selected: PropTypes.bool,
	disabled: PropTypes.bool,
};

Tab.defaultProps = {
	id: '',
	children: null,
	disabled: false,
	onClickMeta: null,
	selected: false,
};

export default Tab;
