// @ts-nocheck
import TabGroup from './tab-group';

export default TabGroup;
