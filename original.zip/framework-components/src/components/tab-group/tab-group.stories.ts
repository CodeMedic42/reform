// @ts-nocheck
import TabGroup from '.';

export default {
	title: 'Layout/Tabs',
	component: TabGroup,
};

export { default as basic } from './stories/basic';
export { default as colors } from './stories/colors';
