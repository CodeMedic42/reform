// @ts-nocheck
import TableMessage from './table-message';

export default TableMessage;
