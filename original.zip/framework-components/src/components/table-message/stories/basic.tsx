// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';
import TableMessage from '../table-message';
import Button from '../../button';

function example() {
	return (
		<>
			<Scope title="Basic">
				<TableMessage header="This is the header" />
			</Scope>
			<Scope title="All simple items">
				<TableMessage
					header="This is the header"
					body="This is the body"
					footer="This is a simple footer"
				/>
			</Scope>
			<Scope title="Complex footer">
				<TableMessage
					header="This is the header"
					body="This is the body"
					footer={
						<Button color="secondary" size="sm" variant="fill">
							Clickable
						</Button>
					}
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
