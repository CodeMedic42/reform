// @ts-nocheck
import TableMessage from '.';

export default {
	title: 'Table/Table Message',
	component: TableMessage,
};

export { default as basic } from './stories/basic';
