// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import SubHeading from '../typography/sub-heading';
import Text from '../typography/text';

class TableMessage extends PureComponent {
	render() {
		const { header, body, footer } = this.props;

		return (
			<div className="table-message">
				<SubHeading
					className="table-message-header"
					variant="sub-heading-3"
					level="4"
				>
					{header}
				</SubHeading>
				<Text className="table-message-body" size="lg">
					{body}
				</Text>
				<div className="table-message-footer">{footer}</div>
			</div>
		);
	}
}

TableMessage.propTypes = {
	header: PropTypes.string.isRequired,
	body: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	footer: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

TableMessage.defaultProps = {
	body: null,
	footer: null,
};

export default TableMessage;
