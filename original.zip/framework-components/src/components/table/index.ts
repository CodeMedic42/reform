// @ts-nocheck
import Table from './generic/table';
import Head from './generic/head';
import Header from './generic/header';
import Body from './generic/body';
import Row from './generic/row';
import Cell from './generic/cell';
import HeaderCell from './generic/header-cell';
import HeaderSortableCell from './generic/header-sortable-cell';
import RowHeader from './generic/row-header';

import SimpleTable from './simple';

export {
	Table,
	Head,
	Header,
	Body,
	Row,
	Cell,
	HeaderCell,
	HeaderSortableCell,
	RowHeader,
	SimpleTable,
};
