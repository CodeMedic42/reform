// @ts-nocheck
import TextAreaInput from './text-area-input';

export default TextAreaInput;
