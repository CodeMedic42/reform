// @ts-nocheck
import React from 'react';
import TextAreaInput from '..';
import Scope from '../../../../.storybook/components/scope';
import { Row, Column } from '../../grid';

function example() {
	const [value, setValue] = React.useState(null);

	return (
		<>
			<Scope title="Simple">
				<TextAreaInput
					label="Text Input"
					value={value}
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Placeholder">
				<TextAreaInput
					label="Text Input"
					placeholder="Placeholder"
					value={value}
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Disabled">
				<TextAreaInput
					label="Text Input"
					value={value}
					disabled
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Hidden">
				<TextAreaInput
					label="Text Input"
					value={value}
					hidden
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Labels">
				<Row gutter>
					<Column width="4">
						<TextAreaInput
							value={value}
							onChange={setValue}
							label="with label"
						/>
					</Column>
					<Column width="4">
						<TextAreaInput
							value={value}
							onChange={setValue}
							label=""
						/>
					</Column>
					<Column width="4">
						<TextAreaInput value={value} onChange={setValue} />
					</Column>
				</Row>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
