// @ts-nocheck
import React from 'react';
import TextAreaInput from '..';
import Scope from '../../../../.storybook/components/scope';

function example() {
	const [value, setValue] = React.useState(null);

	return (
		<>
			<Scope title="No Size(Default size-md)">
				<TextAreaInput
					label="Text Input"
					placeholder="Placeholder"
					value={value}
					onChange={setValue}
				/>
			</Scope>
			<Scope title="Size SM">
				<TextAreaInput
					label="Text Input"
					placeholder="Placeholder"
					value={value}
					onChange={setValue}
					size="sm"
				/>
			</Scope>
			<Scope title="Size MD">
				<TextAreaInput
					label="Text Input"
					placeholder="Placeholder"
					value={value}
					onChange={setValue}
					size="md"
				/>
			</Scope>
			<Scope title="Size LG">
				<TextAreaInput
					label="Text Input"
					placeholder="Placeholder"
					value={value}
					onChange={setValue}
					size="lg"
				/>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Sizes',
};

export default example;
