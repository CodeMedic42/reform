// @ts-nocheck
import TextAreaInput from '.';

export default {
	title: 'Inputs/Text Area Input',
	component: TextAreaInput,
};

export { default as basic } from './stories/basic';
export { default as messages } from './stories/messages';
export { default as sizes } from './stories/sizes';
