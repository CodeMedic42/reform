// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import InputLabel, {
	propTypes as inputLabelPropTypes,
	defaultProps as inputLabelDefaultProps,
} from '../base-input/input-label';
import BaseCursorInput, {
	propTypes as baseCursorInputPropTypes,
	defaultProps as baseCursorInputDefaultProps,
} from '../base-input/base-cursor-input';
import InputBase from '../base-input/input-base';

class TextAreaInput extends React.PureComponent {
	constructor(props) {
		super(props);

		this.inputRef = React.createRef();
	}

	componentDidMount() {
		const { focusOnMount } = this.props;

		if (focusOnMount && this.inputRef && this.inputRef.current) {
			this.focus();
		}
	}

	getInputElement() {
		return this.inputRef.current;
	}

	focus() {
		const { disabled } = this.props;

		if (disabled) {
			return;
		}

		this.getInputElement().focus();
	}

	render() {
		const {
			className,
			id,
			label,
			value,
			messages,
			invalid,
			'aria-labelledby': ariaLabelledby,
			'aria-describedby': ariaDescribedby,
			hidden,
			disabled,
			onChange,
			placeholder,
			title,
			name,
			onFocus,
			onBlur,
			onKeyPress,
			onKeyDown,
			onKeyUp,
			minLength,
			maxLength,
			required,
			autoComplete,
			'aria-label': ariaLabel,
			showFocused,
			rows,
			paddingSize,
			size,
			onClear,
		} = this.props;

		return (
			<InputLabel
				className={classnames('ai-text-input', className)}
				id={id}
				label={label}
				messages={messages}
				invalid={invalid}
				aria-labelledby={ariaLabelledby}
				aria-describedby={ariaDescribedby}
				hidden={hidden}
				disabled={disabled}
				size={size}
			>
				{({ describedBy, labelledBy, inputId }) => (
					<BaseCursorInput
						id={inputId}
						value={value}
						valueType="string"
						disabled={disabled}
						onChange={onChange}
						size={size}
						hideClearButton
						onClear={onClear}
					>
						{({ value: baseValue, onChange: baseOnChange }) => (
							<InputBase
								ref={this.inputRef}
								Component="textarea"
								id={inputId}
								value={baseValue}
								onChange={baseOnChange}
								aria-labelledby={labelledBy}
								aria-describedby={describedBy}
								className={classnames(
									`padding-${
										!isNil(paddingSize) ? paddingSize : size
									}`,
									{
										focus: showFocused,
										'has-value': !isNil(baseValue),
									},
								)}
								placeholder={placeholder}
								title={title}
								disabled={disabled}
								name={name}
								onFocus={onFocus}
								onBlur={onBlur}
								onKeyPress={onKeyPress}
								onKeyDown={onKeyDown}
								onKeyUp={onKeyUp}
								minLength={minLength}
								maxLength={maxLength}
								required={required}
								autoComplete={autoComplete}
								aria-label={ariaLabel}
								rows={rows}
							/>
						)}
					</BaseCursorInput>
				)}
			</InputLabel>
		);
	}
}

TextAreaInput.propTypes = {
	...inputLabelPropTypes,
	...baseCursorInputPropTypes,
	placeholder: PropTypes.string,
	minLength: PropTypes.number,
	maxLength: PropTypes.number,
	required: PropTypes.bool,
	title: PropTypes.string,
	'aria-label': PropTypes.string,
	name: PropTypes.string,
	focusOnMount: PropTypes.bool,
	onFocus: PropTypes.func,
	onBlur: PropTypes.func,
	onKeyPress: PropTypes.func,
	onKeyDown: PropTypes.func,
	onKeyUp: PropTypes.func,
	autoComplete: PropTypes.oneOf(['on', 'off']),
	showFocused: PropTypes.bool,
	rows: PropTypes.number,
	paddingSize: PropTypes.oneOf(['sm', 'md', 'lg']),
};

TextAreaInput.defaultProps = {
	...inputLabelDefaultProps,
	...baseCursorInputDefaultProps,
	required: null,
	placeholder: null,
	title: null,
	minLength: null,
	maxLength: null,
	'aria-label': null,
	name: null,
	focusOnMount: false,
	onFocus: null,
	onBlur: null,
	onKeyPress: null,
	onKeyDown: null,
	onKeyUp: null,
	autoComplete: 'off',
	showFocused: false,
	rows: 4,
	paddingSize: null,
};

export default TextAreaInput;
