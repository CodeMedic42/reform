# Text Input

Provides all the html and styles necessary to render an standard input which takes a string as its value.

## Properties

### Required

| Property | Type   | Description                 |
| -------- | ------ | --------------------------- |
| id       | String | The id of the main element. |

### Optional

| Property         | Type                                            | Default | Description                                                                              |
| ---------------- | ----------------------------------------------- | ------- | ---------------------------------------------------------------------------------------- |
| className        | String                                          | null    | Any additional class names provide here will be added to the button                      |
| label            | String                                          | null    | The text for the label above the input.                                                  |
| value            | String                                          | null    | The value to display in the input.                                                       |
| placeholder      | String                                          | null    | The value to display when the value is null or empty.                                    |
| messages         | ArrayOf(Shape({ text: String, color: String })) | null    | The messages which are shown below the input.                                            |
| color            | String                                          | null    | The color to make the input.                                                             |
| name             | String                                          | null    | The name attribute used for forms.                                                       |
| title            | String                                          | null    | The title to apply to the input.                                                         |
| aria-label       | String                                          | null    | The aria-label to apply to the input. For 508 Compliance.                                |
| aria-labelledBy  | ArrayOf(String)                                 | null    | Additional ids of other elements which add additional labeling. For 508 Compliance.      |
| aria-describedby | ArrayOf(String)                                 | null    | Additional ids of other elements which add additional descriptions. For 508 Compliance.  |
| hidden           | Boolean                                         | false   | This prop will hidden the entire control.                                                |
| disabled         | Boolean                                         | false   | This prop will disable the input.                                                        |
| width            | One of "Size Enum"                              | false   | This prop will set the size of the input.                                                |
| onChange         | Callback                                        | null    | This function will be called when the value changes.                                     |
| onFocus          | Callback                                        | null    | This function will be called when the input gets focus.                                  |
| onBlur           | Callback                                        | null    | This function will be called when the input looses focus.                                |
| onKeyPress       | Callback                                        | null    | This function will be called when the input has focus and the keyPressed event is fired. |
| onKeyDown        | Callback                                        | null    | This function will be called when the input has focus and the keyDown event is fired.    |
| onKeyUp          | Callback                                        | null    | This function will be called when the input has focus and the keyUp event is fired.      |

## Coloring

The colors for either the input or the messages are(in increasing priority order)

-   primary
-   secondary
-   info
-   success
-   warn
-   danger

The input border will change color when it has focus. This will show that the input has focus.

If one or more messages are applied then the message with color denoting the greatest severity will set the color of the input permanently. This can be overridden by use of the color property.

## Messaging

The group of messages which are applied to the control will be given an id. This id will be automatically applied through the aria-describedby attribute. This will allow a screen reader to pick up these messages.

## Callbacks

### onChange

When the user deletes the last character from the input, rather than providing an empty string as the changed value, onChange will instead provide this value as a null. This is more inline with expected use as the user has meant to remove the value.
