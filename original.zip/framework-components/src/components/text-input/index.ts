// @ts-nocheck
import TextInput from './text-input';

export default TextInput;
