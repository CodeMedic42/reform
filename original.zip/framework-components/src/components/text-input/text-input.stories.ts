// @ts-nocheck
import TextInput from '.';

export default {
	title: 'Inputs/Text Input',
	component: TextInput,
};

export { default as preview } from './stories/preview';
export { default as basic } from './stories/basic';
export { default as messages } from './stories/messages';
export { default as sizes } from './stories/sizes';
export { default as icons } from './stories/icons';
