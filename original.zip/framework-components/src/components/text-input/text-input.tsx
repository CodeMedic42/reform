// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import { faEye } from '@audacious/icons/solid/faEye';
import { faEyeSlash } from '@audacious/icons/solid/faEyeSlash';
import InputLabel, {
	propTypes as inputLabelPropTypes,
	defaultProps as inputLabelDefaultProps,
} from '../base-input/input-label';
import BaseCursorInput, {
	propTypes as baseCursorInputPropTypes,
	defaultProps as baseCursorInputDefaultProps,
} from '../base-input/base-cursor-input';
import InputBase from '../base-input/input-base';

class TextInput extends React.PureComponent {
	constructor(props) {
		super(props);

		this.inputRef = React.createRef();

		this.toggleVisible = this.toggleVisible.bind(this);

		this.state = {
			visible: false,
		};
	}

	static getDerivedStateFromProps(nextProps, currentState) {
		const { disabled, secure } = nextProps;

		const { visible } = currentState;

		return {
			type: secure && (!visible || disabled) ? 'password' : 'text',
		};
	}

	componentDidMount() {
		const { focusOnMount } = this.props;

		if (focusOnMount && this.inputRef && this.inputRef.current) {
			this.focus();
		}
	}

	getInputElement() {
		return this.inputRef.current;
	}

	focus() {
		const { disabled } = this.props;

		if (disabled) {
			return;
		}

		this.getInputElement().focus();
	}

	toggleVisible() {
		const { visible } = this.state;

		this.setState({
			visible: !visible,
		});
	}

	render() {
		const {
			className,
			id,
			label,
			value,
			messages,
			invalid,
			'aria-labelledby': ariaLabelledby,
			'aria-describedby': ariaDescribedby,
			hidden,
			disabled,
			onChange,
			onClear,
			leftIcon,
			placeholder,
			title,
			name,
			onFocus,
			onBlur,
			onKeyPress,
			onKeyDown,
			onKeyUp,
			minLength,
			maxLength,
			required,
			autoComplete,
			'aria-label': ariaLabel,
			showFocused,
			secure,
			pattern,
			size,
		} = this.props;

		let { rightIcon } = this.props;

		const { type } = this.state;

		if (secure) {
			rightIcon = {
				icon: type === 'password' ? faEye : faEyeSlash,
				onClick: this.toggleVisible,
				overrideClear: true,
			};
		}

		return (
			<InputLabel
				className={classnames('ai-text-input', className)}
				id={id}
				label={label}
				messages={messages}
				invalid={invalid}
				aria-labelledby={ariaLabelledby}
				aria-describedby={ariaDescribedby}
				hidden={hidden}
				disabled={disabled}
				size={size}
			>
				{({ describedBy, labelledBy, inputId }) => (
					<BaseCursorInput
						id={inputId}
						value={value}
						valueType="string"
						disabled={disabled}
						onChange={onChange}
						onClear={onClear}
						size={size}
						leftIcon={leftIcon}
						rightIcon={rightIcon}
					>
						{({ value: baseValue, onChange: baseOnChange }) => (
							<InputBase
								Component="input"
								ref={this.inputRef}
								id={inputId}
								value={baseValue}
								onChange={baseOnChange}
								type={type}
								className={classnames({
									focus: showFocused,
									'has-value': !isNil(baseValue),
								})}
								placeholder={placeholder}
								title={title}
								disabled={disabled}
								name={name}
								onFocus={onFocus}
								onBlur={onBlur}
								onKeyPress={onKeyPress}
								onKeyDown={onKeyDown}
								onKeyUp={onKeyUp}
								minLength={minLength}
								maxLength={maxLength}
								required={required}
								pattern={pattern}
								autoComplete={autoComplete}
								aria-label={ariaLabel}
								aria-labelledby={labelledBy}
								aria-describedby={describedBy}
							/>
						)}
					</BaseCursorInput>
				)}
			</InputLabel>
		);
	}
}

TextInput.propTypes = {
	...inputLabelPropTypes,
	...baseCursorInputPropTypes,
	secure: PropTypes.bool,
	placeholder: PropTypes.string,
	minLength: PropTypes.number,
	maxLength: PropTypes.number,
	required: PropTypes.bool,
	pattern: PropTypes.oneOfType([
		PropTypes.instanceOf(RegExp),
		PropTypes.string,
	]),
	title: PropTypes.string,
	'aria-label': PropTypes.string,
	name: PropTypes.string,
	focusOnMount: PropTypes.bool,
	onFocus: PropTypes.func,
	onBlur: PropTypes.func,
	onKeyPress: PropTypes.func,
	onKeyDown: PropTypes.func,
	onKeyUp: PropTypes.func,
	autoComplete: PropTypes.oneOf(['on', 'off']),
	showFocused: PropTypes.bool,
};

TextInput.defaultProps = {
	...inputLabelDefaultProps,
	...baseCursorInputDefaultProps,
	secure: false,
	required: null,
	placeholder: null,
	title: null,
	minLength: null,
	maxLength: null,
	pattern: null,
	'aria-label': null,
	name: null,
	focusOnMount: false,
	onFocus: null,
	onBlur: null,
	onKeyPress: null,
	onKeyDown: null,
	onKeyUp: null,
	autoComplete: 'off',
	showFocused: false,
};

export default TextInput;
