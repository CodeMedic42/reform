// @ts-nocheck
import TextList from './text-list';
import TextListItem from './text-list-item';

export default TextList;

export { TextListItem };
