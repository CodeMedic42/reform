// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

class TextListItem extends PureComponent {
	render() {
		const { className, children } = this.props;

		return (
			<li className={classnames('ai-text-list-item', className)}>
				{children}
			</li>
		);
	}
}

TextListItem.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

TextListItem.defaultProps = {
	className: null,
	children: null,
};

export default TextListItem;
