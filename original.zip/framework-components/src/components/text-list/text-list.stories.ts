// @ts-nocheck
import TextList from '.';

export default {
	title: 'Typography/Text List',
	component: TextList,
};

export { default as basic } from './stories/basic';
