// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';

class TextList extends PureComponent {
	render() {
		const { className, children } = this.props;

		return (
			<ul className={classnames('ai-text-list', className)}>
				{children}
			</ul>
		);
	}
}

TextList.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
};

TextList.defaultProps = {
	className: null,
	children: null,
};

export default TextList;
