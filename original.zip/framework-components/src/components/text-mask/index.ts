// @ts-nocheck
import MaskedInput from './text-mask.tsx';

export default MaskedInput;

