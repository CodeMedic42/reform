// @ts-nocheck
import Tooltip from './tooltip';

export default Tooltip;
