// @ts-nocheck
import React from 'react';
import Tooltip from '..';
import TooltipTextAnchor from '../tooltip-text-anchor';
import Scope from '../../../../.storybook/components/scope';

function example() {
	return (
		<>
			<Scope title="Basic">
				<div className="gutter-horizontal">
					<Tooltip
						anchor={TooltipTextAnchor}
						anchorProps={{
							children: 'Text',
						}}
					>
						This is a sample tooltip
					</Tooltip>
				</div>
			</Scope>
			<Scope title="Disabled">
				<div className="gutter-horizontal">
					<Tooltip
						anchor={TooltipTextAnchor}
						anchorProps={{
							children: 'Text',
						}}
						disabled
					>
						This is a sample tooltip
					</Tooltip>
				</div>
			</Scope>
		</>
	);
}

example.story = {
	name: 'Basics',
};

export default example;
