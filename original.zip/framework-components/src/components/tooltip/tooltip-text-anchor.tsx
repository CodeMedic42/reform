// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import applyAnchorBinding from '../drop-down/anchor-binding';

class TooltipTextAnchor extends PureComponent {
	render() {
		const { className, disabled, children } = this.props;

		return (
			<span
				className={classnames('ai-tooltip-text-anchor', className, {
					disabled,
				})}
			>
				{children}
			</span>
		);
	}
}

TooltipTextAnchor.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	disabled: PropTypes.bool,
};

TooltipTextAnchor.defaultProps = {
	className: null,
	children: null,
	disabled: false,
};

export default applyAnchorBinding(TooltipTextAnchor);
