// @ts-nocheck
import Tooltip from '.';

export default {
	title: 'Controls/Tooltip',
	component: Tooltip,
};

export { default as basics } from './stories/basics';
