// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import noop from 'lodash-es/noop';
import DropDown from '../drop-down';
import applyAnchorBinding from '../drop-down/anchor-binding';

class Tooltip extends PureComponent {
	constructor(props) {
		super(props);

		const { anchor } = props;

		this.boundAnchor = anchor.isAnchorBinding
			? anchor
			: applyAnchorBinding(anchor);
	}

	render() {
		const {
			className,
			anchorProps,
			children,
			onAnchorClick,
			openOnClick,
			openOnFocus,
			disabled,
			dropPositions,
		} = this.props;

		return (
			<DropDown
				className={classnames('ai-tooltip', className)}
				trayClassName="ai-tooltip-tray"
				Anchor={this.boundAnchor}
				anchorProps={{
					...anchorProps,
				}}
				onAnchorClick={onAnchorClick}
				dropPositions={dropPositions}
				closeTrayOnClick={false}
				openOnHover
				autoClose
				openOnFocus={openOnFocus}
				openOnClick={openOnClick}
				disabled={disabled}
				horizontallyCenter
			>
				{children}
			</DropDown>
		);
	}
}

const dropPositionTypes = PropTypes.oneOf(['top', 'bottom', 'left', 'right']);

Tooltip.propTypes = {
	className: PropTypes.string,
	anchor: PropTypes.elementType.isRequired,
	// eslint-disable-next-line react/forbid-prop-types
	anchorProps: PropTypes.object.isRequired,
	children: PropTypes.node.isRequired,
	onAnchorClick: PropTypes.func,
	openOnClick: PropTypes.bool,
	openOnFocus: PropTypes.bool,
	disabled: PropTypes.bool,
	dropPositions: PropTypes.arrayOf(dropPositionTypes),
};

Tooltip.defaultProps = {
	className: null,
	onAnchorClick: noop,
	openOnClick: false,
	openOnFocus: false,
	disabled: false,
	dropPositions: ['top', 'bottom'],
};

export default Tooltip;
