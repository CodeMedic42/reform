// @ts-nocheck
import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import Typography from './typography';
import applyForwardRef from '../../common/apply-forward-ref';

class Caption extends PureComponent {
	render() {
		const { className, label, forwardRef, children, ...rest } = this.props;

		const labelValue = !isNil(label) ? (
			<span className="ai-caption-label">{label}: </span>
		) : null;

		return (
			<Typography
				ref={forwardRef}
				Component="div"
				className={classnames('ai-caption', className)}
				{...rest}
			>
				{labelValue}
				<span className="ai-caption-body">{children}</span>
			</Typography>
		);
	}
}

Caption.propTypes = {
	className: PropTypes.string,
	children: PropTypes.oneOfType([
		PropTypes.node,
		PropTypes.arrayOf(PropTypes.node),
	]),
	label: PropTypes.string.isRequired,
	forwardRef: PropTypes.instanceOf(Object),
};

Caption.defaultProps = {
	className: null,
	children: null,
	forwardRef: null,
};

export default applyForwardRef(Caption);
