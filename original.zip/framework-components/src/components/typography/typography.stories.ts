// @ts-nocheck
import Typography from '.';

export default {
	title: 'Typography/Typography',
	component: Typography,
};

export { default as heading } from './stories/heading';
export { default as subHeading } from './stories/sub-heading';
export { default as paragraph } from './stories/paragraph';
export { default as text } from './stories/text';
export { default as other } from './stories/other';
export { default as pairs } from './stories/pairs';
export { default as colors } from './stories/colors';
