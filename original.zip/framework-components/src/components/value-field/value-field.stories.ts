// @ts-nocheck
import TextInput from '.';

export default {
	title: 'Inputs/Value Field',
	component: TextInput,
};

export { default as basic } from './stories/basic';
