// @ts-nocheck
import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import isNil from 'lodash-es/isNil';
import InputLabel, {
	propTypes as inputLabelPropTypes,
	defaultProps as inputLabelDefaultProps,
} from '../base-input/input-label';
import BaseCursorInput, {
	propTypes as baseCursorInputPropTypes,
	defaultProps as baseCursorInputDefaultProps,
} from '../base-input/base-cursor-input';

class ValueField extends React.PureComponent {
	render() {
		const {
			className,
			id,
			label,
			value,
			'aria-labelledby': ariaLabelledby,
			'aria-describedby': ariaDescribedby,
			hidden,
			rightIcon,
			leftIcon,
			placeholder,
			title,
			'aria-label': ariaLabel,
			size,
		} = this.props;

		const displayText =
			!isNil(value) && value.length > 0 ? value : placeholder;

		return (
			<InputLabel
				className={classnames('ai-value-field', className)}
				id={id}
				label={label}
				aria-labelledby={ariaLabelledby}
				aria-describedby={ariaDescribedby}
				hidden={hidden}
				disabled
				size={size}
			>
				{({ describedBy, labelledBy, inputId }) => (
					<BaseCursorInput
						id={inputId}
						valueType="string"
						hideClearButton
						size={size}
						leftIcon={leftIcon}
						rightIcon={rightIcon}
					>
						{() => (
							<span
								id={inputId}
								className="value-display"
								title={title}
								aria-label={ariaLabel}
								aria-labelledby={labelledBy}
								aria-describedby={describedBy}
							>
								{displayText}
							</span>
						)}
					</BaseCursorInput>
				)}
			</InputLabel>
		);
	}
}

ValueField.propTypes = {
	...inputLabelPropTypes,
	...baseCursorInputPropTypes,
	id: PropTypes.string,
	className: PropTypes.string,
	label: PropTypes.string,
	value: PropTypes.string,
	placeholder: PropTypes.string,
	title: PropTypes.string,
	'aria-labelledby': PropTypes.string,
	'aria-describedby': PropTypes.string,
	'aria-label': PropTypes.string,
	hidden: PropTypes.bool,
	leftIcon: PropTypes.shape({
		name: PropTypes.string.isRequired,
		onClick: PropTypes.func,
	}),
	rightIcon: PropTypes.shape({
		name: PropTypes.string.isRequired,
		onClick: PropTypes.func,
	}),
};

ValueField.defaultProps = {
	...inputLabelDefaultProps,
	...baseCursorInputDefaultProps,
	id: null,
	className: null,
	label: null,
	value: null,
	placeholder: null,
	title: null,
	'aria-labelledby': null,
	'aria-describedby': null,
	'aria-label': null,
	hidden: false,
	leftIcon: null,
	rightIcon: null,
};

export default ValueField;
