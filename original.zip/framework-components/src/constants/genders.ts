// @ts-nocheck
const GENDERS = [
	{
		text: 'Female',
		value: 'female',
	},
	{
		text: 'Male',
		value: 'male',
	},
	{
		text: 'Unknown',
		value: 'unknown',
	},
];

// eslint-disable-next-line import/prefer-default-export
export { GENDERS };
