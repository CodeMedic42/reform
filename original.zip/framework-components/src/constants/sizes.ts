// @ts-nocheck
import PropTypes from 'prop-types';
import map from 'lodash-es/map';

const sizes = {
	SMALL: 'sm',
	MEDIUM: 'md',
	LARGE: 'lg',
	XX_LARGE: '2xl',
};

const sizesPropType = PropTypes.oneOf(map(sizes, (size) => size));

export { sizesPropType };

export default sizes;
