// @ts-nocheck
import useCollectionState from './use-collection-state';
import useCollectionProcessor from './use-collection-processor';

function useCollectionManager(items = [], initialConfig = null) {
	const [config, setCallbacks] = useCollectionState(initialConfig);

	const processedData = useCollectionProcessor(items, config);

	return [processedData, config, setCallbacks];
}

export default useCollectionManager;
