// @ts-nocheck
import { useMemo } from 'react';
import isNil from 'lodash-es/isNil';
import isEmpty from 'lodash-es/isEmpty';
import orderBy from 'lodash-es/orderBy';
import isArray from 'lodash-es/isArray';
import map from 'lodash-es/map';
import get from 'lodash-es/get';
import searchFilter from '@audacious/web-common/utilities/searchFilter';

function useCollectionProcessor(items, config) {
	const { paths: sortPaths, descending } = config?.sorting ?? {};

	const sortedItems = useMemo(() => {
		if (isEmpty(items) || isEmpty(sortPaths)) {
			return items;
		}

		return orderBy(
			items,
			(item) => {
				if (isArray(sortPaths)) {
					return map(sortPaths, (path) => {
						const ref = get(item, path) || '';
						if (typeof ref === 'string') {
							return ref.toLowerCase();
						}
						return ref;
					});
				}
				const ref = get(item, sortPaths) || '';
				if (typeof ref === 'string') {
					return ref.toLowerCase();
				}
				return ref;
			},
			descending === true ? 'desc' : 'asc',
		);
	}, [items, sortPaths, descending]);

	const {
		minCriteriaLength = 0,
		criteria,
		paths: filteringPaths = [],
		additionalFiltering: { filter, rules } = {},
	} = config?.filtering ?? {};

	const filteredItems = useMemo(() => {
		if (
			(isEmpty(criteria) ||
				criteria.length < minCriteriaLength ||
				isEmpty(sortedItems) ||
				isEmpty(filteringPaths)) &&
			isNil(rules)
		) {
			return sortedItems;
		}

		const additionalFilter = !isNil(filter)
			? (item) => filter(item, rules)
			: null;

		return searchFilter(
			sortedItems,
			criteria,
			filteringPaths,
			additionalFilter,
		);
	}, [
		sortedItems,
		minCriteriaLength,
		criteria,
		filteringPaths,
		filter,
		rules,
	]);

	const { currentPage = null, recordsPerPage = null } = config?.paging ?? {};

	const pageItems = useMemo(() => {
		if (
			isEmpty(filteredItems) ||
			isNil(currentPage) ||
			isNil(recordsPerPage)
		) {
			return filteredItems;
		}

		const offset = currentPage - 1;
		const start = offset * recordsPerPage;
		const end = start + recordsPerPage;

		return filteredItems.slice(start, end);
	}, [filteredItems, currentPage, recordsPerPage]);

	const total = filteredItems?.length ?? 0;

	return useMemo(
		() => ({
			items: pageItems,
			total,
			filteredItems,
			sortedItems,
		}),
		[pageItems, total, filteredItems, sortedItems],
	);
}

export default useCollectionProcessor;
