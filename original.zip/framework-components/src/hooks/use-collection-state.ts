// @ts-nocheck
import { useCallback, useMemo, useState } from 'react';
import isNil from 'lodash-es/isNil';

function useCollectionState(initialConfig) {
	const [sortingConfig, setSortingConfigState] = useState(
		initialConfig?.sorting,
	);
	const [filteringConfig, setFilteringConfigState] = useState(
		initialConfig?.filtering,
	);
	const [pagingConfig, setPagingConfigState] = useState(
		initialConfig?.paging,
	);

	const setSortingConfig = useCallback(
		(newSortingConfig) => {
			// this is purposely a merge.
			setSortingConfigState({
				...sortingConfig,
				...newSortingConfig,
			});
		},
		[sortingConfig],
	);

	const setSortParams = useCallback(
		(paths, descending) => {
			setSortingConfig({ paths, descending });
		},
		[setSortingConfig],
	);

	const setPagingConfig = useCallback(
		(newPagingConfig) => {
			// this is purposely a merge.
			setPagingConfigState({
				...pagingConfig,
				...newPagingConfig,
			});
		},
		[pagingConfig],
	);

	const setFilteringConfig = useCallback(
		(newFilteringConfig) => {
			// this is purposely a merge.
			setFilteringConfigState({
				...filteringConfig,
				...newFilteringConfig,
			});

			const currentPage = pagingConfig?.currentPage;

			if (!isNil(currentPage) && currentPage > 1) {
				setPagingConfig({
					currentPage: 1,
				});
			}
		},
		[pagingConfig?.currentPage, filteringConfig],
	);

	const setFilteringCriteria = useCallback(
		(criteria) => {
			setFilteringConfig({ criteria });
		},
		[setFilteringConfig],
	);

	const setAdditionalFilteringRules = useCallback(
		(rules) => {
			setFilteringConfig({
				additionalFiltering: {
					filter: filteringConfig?.additionalFiltering?.filter,
					rules,
				},
			});
		},
		[setFilteringConfig, filteringConfig],
	);

	const setCurrentPage = useCallback(
		(currentPage) => {
			setPagingConfig({ currentPage });
		},
		[setPagingConfig],
	);

	const setRecordsPerPage = useCallback(
		(recordsPerPage, currentPage) => {
			let newCurrentPage = currentPage;

			if (isNil(newCurrentPage)) {
				newCurrentPage = 1;
			}

			setPagingConfig({
				recordsPerPage,
				currentPage: newCurrentPage,
			});
		},
		[setPagingConfig],
	);

	const setCallbacks = {
		setSortingConfig,
		setSortParams,
		setFilteringConfig,
		setPagingConfig,
		setFilteringCriteria,
		setCurrentPage,
		setRecordsPerPage,
		setAdditionalFilteringRules,
	};

	const config = useMemo(
		() => ({
			sorting: sortingConfig,
			filtering: filteringConfig,
			paging: pagingConfig,
		}),
		[sortingConfig, filteringConfig, pagingConfig],
	);

	return [config, setCallbacks];
}

export default useCollectionState;
