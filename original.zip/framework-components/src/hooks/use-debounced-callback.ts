// @ts-nocheck
import { useCallback, useMemo } from 'react';
import debounce from 'lodash-es/debounce';

function useDebouncedCallback(callback, deps, wait, options) {
	const baseCallback = useCallback(callback, deps);

	return useMemo(
		() => debounce(baseCallback, wait, options),
		[baseCallback, wait, options],
	);
}

export default useDebouncedCallback;
