// @ts-nocheck
import { useMemo } from 'react';
import isNil from 'lodash-es/isNil';
import forEach from 'lodash-es/forEach';
import clone from 'lodash-es/clone';
import isArray from 'lodash/isArray';
import isEmpty from 'lodash/isEmpty';
import useCollectionState from './use-collection-state';
import useCollectionProcessor from './use-collection-processor';

function processColumns(columns) {
	const filteringPaths = [];
	const sortingPaths = [];

	forEach(columns, (column) => {
		const {
			filterable,
			sortable,
			cellValuePath,
			cellFilterPath,
			cellSortPath,
		} = column;

		if (filterable) {
			const filterPaths = !isNil(cellFilterPath)
				? cellFilterPath
				: cellValuePath;

			if (isArray(filterPaths)) {
				forEach(filterPaths, (filterPath) =>
					filteringPaths.push({ path: filterPath }),
				);
			} else {
				filteringPaths.push({ path: filterPaths });
			}
		}

		if (sortable && isEmpty(sortingPaths)) {
			const sortPaths = !isNil(cellSortPath)
				? cellSortPath
				: cellValuePath;

			if (isArray(sortPaths)) {
				sortingPaths.push(...sortPaths);
			} else {
				sortingPaths.push(sortPaths);
			}
		}
	});

	return {
		filteringPaths,
		sortingPaths,
	};
}

function useTableManager(items, columns, initialConfig) {
	const additionalConfig = useMemo(() => {
		const columnConfig = processColumns(columns);

		const copy = clone(initialConfig);

		if (
			!isNil(initialConfig.filtering) &&
			!isNil(columnConfig.filteringPaths) &&
			isNil(copy.filtering.paths)
		) {
			copy.filtering.paths = columnConfig.filteringPaths;
		}

		if (
			!isNil(initialConfig.sorting) &&
			!isNil(columnConfig.sortingPaths) &&
			isNil(copy.sorting.paths)
		) {
			copy.sorting.paths = columnConfig.sortingPaths;
		}

		return copy;
	}, []);

	const [config, setCallbacks] = useCollectionState(additionalConfig);

	const processedData = useCollectionProcessor(items, config);

	return [processedData, config, setCallbacks];
}

export default useTableManager;
