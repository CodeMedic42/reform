import {
    schemeColorOrder,
    paletteColorOrder,
    paletteShades,
} from './common/color-list';

// eslint-disable-next-line import/prefer-default-export
export const colors = {
    schemeColorOrder,
    paletteColorOrder,
    paletteShades,
};
