// @ts-nocheck
export default {
	title: 'Styles/Box Shadow',
	component: null,
};

export { default as boxShadow } from './stories/box-shadow';
