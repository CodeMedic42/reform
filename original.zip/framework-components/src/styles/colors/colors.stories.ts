// @ts-nocheck
export default {
	title: 'Styles/Colors V2',
	component: null,
};

export { default as colorPalettes } from './stories/color-palettes';
export { default as colorSchemes } from './stories/color-schemes';
