// @ts-nocheck
import React from 'react';
import map from 'lodash-es/map';
import Scope from '../../../../.storybook/components/scope';

const style = { padding: '5px' };

function renderColorScope({ color, title }) {
	return (
		<Scope key={color} title={title} jsxViewEnabled={false}>
			<div className={`${color} no-select ai-palette`} style={style}>
				Text
			</div>
			<div
				className={`${color} no-select ai-palette plt-darkest plt-bg plt-br`}
				style={style}
			>
				Darkest
			</div>
			<div
				className={`${color} no-select ai-palette plt-darker plt-bg plt-br`}
				style={style}
			>
				Darker
			</div>
			<div
				className={`${color} no-select ai-palette plt-dark plt-bg plt-br`}
				style={style}
			>
				Dark
			</div>
			<div
				className={`${color} no-select ai-palette plt-light plt-bg plt-br`}
				style={style}
			>
				Light
			</div>
			<div
				className={`${color} no-select ai-palette plt-lighter plt-bg plt-br`}
				style={style}
			>
				Lighter
			</div>
			<div
				className={`${color} no-select ai-palette plt-lightest plt-bg plt-br`}
				style={style}
			>
				Lightest
			</div>
		</Scope>
	);
}

function example() {
	return (
		<>
			{map(
				[
					{ color: 'plt-purple', title: 'Purple' },
					{ color: 'plt-navy', title: 'Navy' },
					{ color: 'plt-blue', title: 'Blue' },
					{ color: 'plt-cyan', title: 'Cyan' },
					{ color: 'plt-green', title: 'Green' },
					{ color: 'plt-yellow', title: 'Yellow' },
					{ color: 'plt-orange', title: 'Orange' },
					{ color: 'plt-red', title: 'Red' },
					{ color: 'plt-grey', title: 'Grey' },
				],
				(item) => renderColorScope(item),
			)}
		</>
	);
}

example.story = {
	name: 'Palette Colors',
};

export default example;
