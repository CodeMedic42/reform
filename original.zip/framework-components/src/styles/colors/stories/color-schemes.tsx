// @ts-nocheck
import React from 'react';
import classnames from 'classnames';
import upperFirst from 'lodash-es/upperFirst';
import map from 'lodash-es/map';
import isNil from 'lodash-es/isNil';
import Scope from '../../../../.storybook/components/scope';
import { Row, Column } from '../../../components/grid';

const schemeTypes = [null, 'fill', 'outline', 'opaque', 'lite'];

function renderColorScope(color) {
	return (
		<Scope key={color} title={color} jsxViewEnabled={false}>
			<Row gutter>
				{map(schemeTypes, (schemeType, index) => {
					const leftOffset = index === 0 ? '2' : null;

					return (
						<Column
							key={schemeType}
							width="2"
							leftOffset={leftOffset}
							style={{ textAlign: 'center' }}
						>
							{!isNil(schemeType)
								? upperFirst(schemeType)
								: 'Text'}
						</Column>
					);
				})}
			</Row>
			<Row gutter>
				<Column width="2" style={{ textAlign: 'right' }}>
					Base
				</Column>
				{map(schemeTypes, (schemeType) => {
					if (
						schemeType === 'lite' &&
						(color === 'primary' ||
							color === 'secondary' ||
							color === 'link')
					) {
						return null;
					}

					return (
						<Column key={schemeType} width="2">
							<div
								style={{
									padding: 10,
									textAlign: 'center',
								}}
								className={classnames(
									`sch-${color} no-select`,
									{
										[`sch-${schemeType}`]:
											!isNil(schemeType),
									},
								)}
							>
								Text
							</div>
						</Column>
					);
				})}
			</Row>
			<Row gutter>
				<Column width="2" style={{ textAlign: 'right' }}>
					Control
				</Column>
				{map(schemeTypes, (schemeType) => {
					if (schemeType === 'lite') {
						return null;
					}

					return (
						<Column key={schemeType} width="2">
							<div
								// eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
								tabIndex="0"
								style={{
									padding: 10,
									textAlign: 'center',
								}}
								className={classnames(
									`sch-${color} no-select sch-control`,
									{
										[`sch-${schemeType}`]:
											!isNil(schemeType),
									},
								)}
							>
								Text
							</div>
						</Column>
					);
				})}
			</Row>
			<Row gutter>
				<Column width="2" style={{ textAlign: 'right' }}>
					Control with border radius
				</Column>
				{map(schemeTypes, (schemeType) => {
					if (schemeType === 'lite') {
						return null;
					}

					return (
						<Column key={schemeType} width="2">
							<div
								// eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
								tabIndex="0"
								style={{
									padding: 10,
									textAlign: 'center',
									borderRadius: '50%',
								}}
								className={classnames(
									`sch-${color} no-select sch-control`,
									{
										[`sch-${schemeType}`]:
											!isNil(schemeType),
									},
								)}
							>
								Text
							</div>
						</Column>
					);
				})}
			</Row>
			<Row gutter>
				<Column width="2" style={{ textAlign: 'right' }}>
					Control Disabled
				</Column>
				{map(schemeTypes, (schemeType) => {
					if (schemeType === 'lite') {
						return null;
					}

					return (
						<Column key={schemeType} width="2">
							<div
								style={{
									padding: 10,
									textAlign: 'center',
								}}
								className={classnames(
									`sch-${color} no-select sch-control disabled`,
									{
										[`sch-${schemeType}`]:
											!isNil(schemeType),
									},
								)}
								disabled
							>
								Text
							</div>
						</Column>
					);
				})}
			</Row>
		</Scope>
	);
}

function example() {
	return (
		<>
			{map(
				[
					'primary',
					'secondary',
					'link',
					'info',
					'success',
					'warn',
					'danger',
				],
				(color) => renderColorScope(color),
			)}
		</>
	);
}

example.story = {
	name: 'Color Schemes',
};

export default example;
