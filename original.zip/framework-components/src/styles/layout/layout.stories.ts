// @ts-nocheck
export default {
	title: 'Styles/Responsive',
	component: null,
};

export { default as hiddenV2 } from './stories/hidden-v2';
