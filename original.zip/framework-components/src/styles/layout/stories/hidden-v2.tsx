// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';

const containerStyle = {
	height: '40px',
	backgroundColor: 'lightblue',
	padding: '5px',
};

function example() {
	return (
		<Scope title="Container Normal" jsxViewEnabled={false}>
			<div className="gutter-vertical" style={containerStyle}>
				<div>class: hidden</div>
				<div className="hidden">Target</div>
			</div>
			<div className="gutter-vertical" style={containerStyle}>
				<div>class: hidden-gt-sm</div>
				<div className="hidden-gt-sm">Target</div>
			</div>
			<div className="gutter-vertical" style={containerStyle}>
				<div>class: hidden-gt-md</div>
				<div className="hidden-gt-md">Target</div>
			</div>
			<div className="gutter-vertical" style={containerStyle}>
				<div>class: hidden-gt-lg</div>
				<div className="hidden-gt-lg">Target</div>
			</div>
			<div className="gutter-vertical" style={containerStyle}>
				<div>class: hidden-gt-xl</div>
				<div className="hidden-gt-xl">Target</div>
			</div>
			<div className="gutter-vertical" style={containerStyle}>
				<div>class: hidden-lt-md</div>
				<div className="hidden-lt-md">Target</div>
			</div>
			<div className="gutter-vertical" style={containerStyle}>
				<div>class: hidden-lt-lg</div>
				<div className="hidden-lt-lg">Target</div>
			</div>
			<div className="gutter-vertical" style={containerStyle}>
				<div>class: hidden-lt-xl</div>
				<div className="hidden-lt-xl">Target</div>
			</div>
			<div style={containerStyle}>
				<div>class: hidden-lt-2xl</div>
				<div className="hidden-lt-2xl">Target</div>
			</div>
		</Scope>
	);
}

example.story = {
	name: 'Hidden Version 2',
};

export default example;
