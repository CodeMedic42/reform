// @ts-nocheck
export default {
	title: 'Styles/Overlays',
	component: null,
};

export { default as spinner } from './stories/overlay/spinner';
export { default as spinnerFixed } from './stories/overlay/spinner-fixed';
