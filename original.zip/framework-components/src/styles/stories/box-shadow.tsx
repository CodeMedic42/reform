// @ts-nocheck
import React from 'react';
import Scope from '../../../.storybook/components/scope';

function boxWithShadow(dp) {
	return (
		<span
			className={`box-shadow-${dp}dp`}
			style={{
				width: '100px',
				height: '100px',
				display: 'inline-block',
				margin: '30px',
				borderRadius: '4px',
			}}
		>
			<p
				className="ai-text"
				style={{
					paddingLeft: '28px',
					marginTop: '40px',
				}}
			>
				{`${dp} dp`}
			</p>
		</span>
	);
}

function example() {
	return (
		<Scope title="Box Shadow DP Sizes">
			<div>
				{boxWithShadow(1)}
				{boxWithShadow(2)}
				{boxWithShadow(3)}
				{boxWithShadow(4)}
				{boxWithShadow(6)}
				{boxWithShadow(8)}
				{boxWithShadow(9)}
				{boxWithShadow(12)}
				{boxWithShadow(16)}
				{boxWithShadow(24)}
			</div>
		</Scope>
	);
}

example.story = {
	name: 'Basic',
};

export default example;
