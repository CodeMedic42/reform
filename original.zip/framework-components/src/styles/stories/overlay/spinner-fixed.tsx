// @ts-nocheck
import React from 'react';
import Scope from '../../../../.storybook/components/scope';

function example() {
	return (
		<Scope
			title="Spinner"
			jsxViewEnabled={false}
			specimenViewStyle={{ minHeight: '100px' }}
		>
			<div className="is-loading-fixed" />
			<button type="button">Just try and click me</button>
		</Scope>
	);
}

example.story = {
	name: 'Spinner Fixed',
};

export default example;
