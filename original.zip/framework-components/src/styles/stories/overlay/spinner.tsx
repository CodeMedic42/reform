// @ts-nocheck
import React from 'react';
import classnames from 'classnames';
import map from 'lodash-es/map';
import Scope from '../../../../.storybook/components/scope';

function renderColorScope(color) {
	return (
		<Scope
			key={color}
			title="Spinner"
			jsxViewEnabled={false}
			specimenViewStyle={{ minHeight: '100px' }}
		>
			<div className={classnames('is-loading', color)}>
				<button type="button">Just try and click me</button>
			</div>
		</Scope>
	);
}

function example() {
	return (
		<>
			{map(
				[
					null,
					'primary',
					'secondary',
					'info',
					'success',
					'warn',
					'danger',
				],
				(color) => renderColorScope(color),
			)}
		</>
	);
}

example.story = {
	name: 'Spinner',
};

export default example;
