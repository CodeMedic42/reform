// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isNaN from 'lodash-es/isNaN';

function februaryDays(year) {
	if (year % 4 !== 0) {
		return 28;
	}

	if (year % 100 !== 0) {
		return 29;
	}

	if (year % 400 !== 0) {
		return 28;
	}

	return 29;
}

export function getMaxDays(month, year) {
	if (isNil(month)) {
		return 31;
	}

	switch (month) {
		case 2:
			if (isNil(year)) {
				return 29;
			}
			return februaryDays(year);
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		default:
			return 31;
	}
}

export default function dateValidator(value, message) {
	if (isNil(value) || !isNaN(value.getTime())) {
		return null;
	}

	return message || 'Invalid Date';
}
