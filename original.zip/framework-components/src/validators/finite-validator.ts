// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';
import isFinite from 'lodash-es/isFinite';

export default function finiteValidator(value, message) {
	if (isNil(value) || isFinite(value)) {
		return null;
	}

	let text = message;

	if (isNil(text)) {
		text = 'Not valid';
	} else if (!isString(text)) {
		text = text();
	}

	return text;
}
