// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isNaN from 'lodash-es/isNaN';
import isString from 'lodash-es/isString';
import getDateParts from '@audacious/web-common/utilities/getDateParts';

export default function maxDateValidator(value, maxDate, message) {
	if (isNil(value)) {
		return null;
	}

	const valueTime = value.getTime();
	if (isNaN(valueTime) || valueTime <= maxDate.getTime()) {
		return null;
	}

	let text = message;

	if (isNil(text)) {
		const { day, month, year } = getDateParts(maxDate);

		text = `Max Date ${month}/${day}/${year}`;
	} else if (!isString(text)) {
		text = text(maxDate);
	}

	return text;
}
