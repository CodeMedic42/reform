// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';

export default function maxLengthValidator(value, maxLength, message) {
	if (isNil(value) || value.length <= maxLength) {
		return null;
	}

	let text = message;

	if (isNil(text)) {
		text = `Max Length ${maxLength}`;
	} else if (!isString(text)) {
		text = text(maxLength);
	}

	return text;
}
