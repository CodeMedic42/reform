// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';
import isFinite from 'lodash-es/isFinite';

export default function maxValidator(value, max, message) {
	if (!isFinite(value) || value <= max) {
		return null;
	}

	let text = message;

	if (isNil(text)) {
		text = `Max ${max}`;
	} else if (!isString(text)) {
		text = text(max);
	}

	return text;
}
