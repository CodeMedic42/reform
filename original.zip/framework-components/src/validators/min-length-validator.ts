// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';

export default function minLengthValidator(value, minLength, message) {
	if (isNil(value) || value.length >= minLength) {
		return null;
	}

	let text = message;

	if (isNil(text)) {
		text = `Min Length ${minLength}`;
	} else if (!isString(text)) {
		text = text(minLength);
	}

	return text;
}
