// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';
import isFinite from 'lodash-es/isFinite';

export default function minValidator(value, min, message) {
	if (!isFinite(value) || value >= min) {
		return null;
	}

	let text = message;

	if (isNil(text)) {
		text = `Min ${min}`;
	} else if (!isString(text)) {
		text = text(min);
	}

	return text;
}
