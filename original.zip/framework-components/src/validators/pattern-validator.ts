// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';

export default function patternValidator(value, pattern, message) {
	if (isNil(value) || pattern.test(value)) {
		return null;
	}

	let text = message;

	if (isNil(text)) {
		text = `Value must match pattern ${pattern}`;
	} else if (!isString(text)) {
		text = text(pattern);
	}

	return text;
}
