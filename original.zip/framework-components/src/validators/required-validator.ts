// @ts-nocheck
import isNil from 'lodash-es/isNil';

export default function requiredValidator(value, message) {
	if (!isNil(value)) {
		return null;
	}

	return message || 'Required';
}
