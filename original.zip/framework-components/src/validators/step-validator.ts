// @ts-nocheck
import isNil from 'lodash-es/isNil';
import isString from 'lodash-es/isString';

// Step is an attribute on an html input element
// It manages the the amount by which the toggles on the element increase or decrease the value.
// This validators verifies that a given numeric value is evenly divisible by this step value.
// A step could be any number
// A step of 1 means that the value is an integer
// A step of 2 means that value is always even
// A step of 1.5 means that the value is either a whole number or a whole number plus half.
export default function stepValidator(value, step, message) {
	if (isNil(value) || value % step === 0) {
		return null;
	}

	let text = message;

	if (isNil(text)) {
		if (step === 1) {
			text = `Must be an integer`;
		} else {
			text = `Divisible by ${step}`;
		}
	} else if (!isString(text)) {
		text = text(step);
	}

	return text;
}
